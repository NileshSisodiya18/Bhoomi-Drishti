import {
  DashboardSummary,
  Project,
  AlertItem,
  WhatIfRequest,
  WhatIfResponse,
  SystemStatus,
  SourceStatusItem,
  SyncRunResponse,
  ProjectHistoryItem,
  DataSourceItem,
  FileInspectionResult,
  DataValidationErrorItem,
  AuditLogItem,
  DatabaseOverview,
  ConnectionTestResult,
  DataModeType,
  SourceTestResult
} from '../types.ts';

const API_BASE = '/api';

/**
 * High-Reliability BhoomiDrishti API Client
 * Connects directly to backend SQLite & ML engine.
 * Never silently falls back to synthetic mock data on error;
 * provides explicit, actionable failure states for UI retry components.
 */
export const api = {
  async getDashboardSummary(): Promise<DashboardSummary> {
    const res = await fetch(`${API_BASE}/dashboard/summary`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve dashboard summary (HTTP ${res.status}). Please verify server availability and retry.`);
    }
    return await res.json();
  },

  async getProjects(params?: {
    search?: string;
    risk?: string;
    state?: string;
    district?: string;
    stage?: string;
    page?: number;
    pageSize?: number;
  }): Promise<Project[]> {
    const url = new URL(`${window.location.origin}${API_BASE}/projects`);
    if (params?.search) url.searchParams.set('search', params.search);
    if (params?.risk) url.searchParams.set('risk', params.risk);
    if (params?.state) url.searchParams.set('state', params.state);
    if (params?.district) url.searchParams.set('district', params.district);
    if (params?.stage) url.searchParams.set('stage', params.stage);
    if (params?.page) url.searchParams.set('page', String(params.page));
    url.searchParams.set('pageSize', String(params?.pageSize || 100));

    const res = await fetch(url.toString());
    if (!res.ok) {
      throw new Error(`Unable to retrieve current project data (HTTP ${res.status}). Backend service may be initializing.`);
    }
    const data = await res.json();
    return Array.isArray(data) ? data : (data.items || []);
  },

  async getProjectById(id: string): Promise<Project> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve project '${id}' (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async updateProject(id: string, fields: Partial<Project>): Promise<{ success: boolean; project?: Project }> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fields)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to update project (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async getProjectHistory(projectId: string): Promise<ProjectHistoryItem[]> {
    const res = await fetch(`${API_BASE}/projects/${encodeURIComponent(projectId)}/history`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve project audit trail (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getAlerts(status?: string): Promise<AlertItem[]> {
    const url = status ? `${API_BASE}/alerts?status=${encodeURIComponent(status)}` : `${API_BASE}/alerts`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Unable to retrieve statutory alerts (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async acknowledgeAlert(id: string): Promise<AlertItem> {
    const res = await fetch(`${API_BASE}/alerts/${encodeURIComponent(id)}/acknowledge`, {
      method: 'POST'
    });
    if (!res.ok) {
      throw new Error(`Unable to acknowledge alert (HTTP ${res.status}).`);
    }
    const data = await res.json();
    return data.alert || data;
  },

  async getRiskMap(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/risk-map`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve GIS corridor coordinates (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async runWhatIf(payload: WhatIfRequest): Promise<WhatIfResponse> {
    const res = await fetch(`${API_BASE}/scenarios/what-if`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      throw new Error(`Simulation engine error (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getSystemStatus(): Promise<SystemStatus> {
    const res = await fetch(`${API_BASE}/system/status`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve system telemetry (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getSourcesStatus(): Promise<SourceStatusItem[]> {
    const res = await fetch(`${API_BASE}/system/source-status`);
    if (!res.ok) {
      throw new Error(`Unable to retrieve government source status (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getDataSources(): Promise<DataSourceItem[]> {
    const res = await fetch(`${API_BASE}/data-sources`);
    if (!res.ok) {
      throw new Error(`Unable to load registered data sources (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async updateDataSource(id: string, update: Partial<DataSourceItem>): Promise<DataSourceItem> {
    const res = await fetch(`${API_BASE}/data-sources/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to update data source config (HTTP ${res.status})`);
    }
    const data = await res.json();
    return data.dataSource;
  },

  async testDataSource(id: string): Promise<ConnectionTestResult> {
    const res = await fetch(`${API_BASE}/data-sources/${encodeURIComponent(id)}/test`, {
      method: 'POST'
    });
    if (!res.ok) {
      throw new Error(`Connection probe failed with HTTP ${res.status}`);
    }
    return await res.json();
  },

  async inspectFile(content: string, fileType: string, fileName?: string): Promise<FileInspectionResult> {
    const res = await fetch(`${API_BASE}/data/inspect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `File inspection failed (HTTP ${res.status})`);
    }
    return await res.json();
  },

  async importMappedFile(
    content: string,
    fileType: string,
    columnMapping?: Record<string, string>,
    fileName?: string
  ): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/data/import-mapped`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, columnMapping, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Import failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async triggerSync(source: 'BhoomiRashi' | 'LACRRIS'): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Sync failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async importFile(content: string, fileType: 'csv' | 'xlsx' | 'xls' | 'json', fileName?: string): Promise<SyncRunResponse> {
    const res = await fetch(`${API_BASE}/data/import`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, fileType, fileName })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Import failed with HTTP ${res.status}`);
    }
    const data = await res.json();
    return data.summary;
  },

  async getSyncHistory(): Promise<SyncRunResponse[]> {
    const res = await fetch(`${API_BASE}/sync/history`);
    if (!res.ok) {
      throw new Error(`Unable to fetch synchronization history (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getValidationErrors(syncId?: string, limit = 50): Promise<DataValidationErrorItem[]> {
    const url = syncId ? `${API_BASE}/validation-errors?syncId=${encodeURIComponent(syncId)}&limit=${limit}` : `${API_BASE}/validation-errors?limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Unable to fetch validation errors (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getAuditLogs(limit = 50): Promise<AuditLogItem[]> {
    const res = await fetch(`${API_BASE}/audit-logs?limit=${limit}`);
    if (!res.ok) {
      throw new Error(`Unable to fetch audit logs (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async getDatabaseOverview(): Promise<DatabaseOverview> {
    const res = await fetch(`${API_BASE}/database/overview`);
    if (!res.ok) {
      throw new Error(`Unable to fetch database overview (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  async setDataMode(mode: DataModeType): Promise<{ success: boolean; mode: string }> {
    const res = await fetch(`${API_BASE}/system/data-mode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode })
    });
    if (!res.ok) {
      throw new Error(`Failed to set data mode (HTTP ${res.status}).`);
    }
    return await res.json();
  },

  getExportDownloadUrl(type: 'all' | 'high_risk' | 'alerts' | 'audit_logs', format: 'csv' | 'json'): string {
    return `${API_BASE}/export?type=${type}&format=${format}`;
  },

  // ==========================================================
  // PHASE 1 DATA HUB CLIENT API
  // ==========================================================
  datahub: {
    async getProjects(): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/projects`);
      if (!res.ok) throw new Error(`Failed to fetch Data Hub projects (${res.status})`);
      return await res.json();
    },

    async getProjectById(sourceProjectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(sourceProjectId)}`);
      if (!res.ok) throw new Error(`Project ${sourceProjectId} not found in Data Hub`);
      return await res.json();
    },

    async getProjectHistory(sourceProjectId: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/${encodeURIComponent(sourceProjectId)}/history`);
      if (!res.ok) throw new Error(`Failed to fetch project history (${res.status})`);
      return await res.json();
    },

    async getRecentChanges(limit = 30): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/changes?limit=${limit}`);
      if (!res.ok) throw new Error(`Failed to fetch changes (${res.status})`);
      return await res.json();
    },

    async getSyncStatus(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sync-status`);
      if (!res.ok) throw new Error(`Failed to fetch sync status (${res.status})`);
      return await res.json();
    },

    async getSyncRuns(limit = 15): Promise<any[]> {
      const res = await fetch(`${API_BASE}/datahub/sync-runs?limit=${limit}`);
      if (!res.ok) throw new Error(`Failed to fetch sync runs (${res.status})`);
      return await res.json();
    },

    async triggerSync(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/sync`, { method: 'POST' });
      if (!res.ok) throw new Error(`Sync trigger failed (${res.status})`);
      return await res.json();
    },

    async registerProject(projectId: string, projectName?: string): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, projectName })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Registration failed (${res.status})`);
      }
      return await res.json();
    },

    async importProjectIds(content: string, format: 'csv' | 'txt' | 'json' = 'csv'): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/projects/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, format })
      });
      if (!res.ok) throw new Error(`Import failed (${res.status})`);
      return await res.json();
    },

    async getSourceStatus(): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/source-status`);
      if (!res.ok) throw new Error(`Failed to fetch source status (${res.status})`);
      return await res.json();
    },

    async testSource(projectId?: string): Promise<SourceTestResult> {
      const res = await fetch(`${API_BASE}/datahub/source/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId })
      });
      if (!res.ok) throw new Error(`Test connection failed (${res.status})`);
      return await res.json();
    },

    async toggleFixture60940(enabled?: boolean): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/test-fixture/toggle-60940`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled })
      });
      if (!res.ok) throw new Error(`Toggle fixture failed (${res.status})`);
      return await res.json();
    },

    async updateConfig(intervalMinutes: number): Promise<any> {
      const res = await fetch(`${API_BASE}/datahub/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intervalMinutes })
      });
      if (!res.ok) throw new Error(`Update config failed (${res.status})`);
      return await res.json();
    },

    getExportUrl(format: 'csv' | 'json' = 'csv'): string {
      return `${API_BASE}/datahub/export?format=${format}`;
    }
  }
};

