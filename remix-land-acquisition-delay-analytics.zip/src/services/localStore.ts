import { INITIAL_PROJECTS, INITIAL_ALERTS } from '../server/dataset.ts';
import { runWhatIfScenario as execWhatIf } from '../server/predictionService.ts';
import { DashboardSummary, Project, AlertItem, WhatIfRequest, WhatIfResponse } from '../types.ts';

let localProjects: Project[] = [...INITIAL_PROJECTS];
let localAlerts: AlertItem[] = [...INITIAL_ALERTS];

export function getLocalDashboardSummary(): DashboardSummary {
  const highRisk = localProjects.filter(p => p.riskLevel === 'HIGH');
  const mediumRisk = localProjects.filter(p => p.riskLevel === 'MEDIUM');
  const onTrack = localProjects.filter(p => p.riskLevel === 'LOW');

  const totalLandReq = localProjects.reduce((sum, p) => sum + p.totalLandRequiredHa, 0);
  const totalLandAcq = localProjects.reduce((sum, p) => sum + p.landAcquiredHa, 0);
  const avgProgress = totalLandReq > 0 ? Math.round((totalLandAcq / totalLandReq) * 100) : 0;

  const highRiskProjects = [...localProjects]
    .sort((a, b) => b.delayProbability - a.delayProbability)
    .slice(0, 5);

  return {
    totalProjects: localProjects.length,
    highRiskCount: highRisk.length,
    mediumRiskCount: mediumRisk.length,
    onTrackCount: onTrack.length,
    totalLandRequiredHa: Math.round(totalLandReq),
    totalLandAcquiredHa: Math.round(totalLandAcq),
    avgAcquisitionProgress: avgProgress,
    highRiskProjects,
    recentAlerts: localAlerts.slice(0, 4)
  };
}

export function getLocalProjects(params?: {
  search?: string;
  risk?: string;
  state?: string;
  district?: string;
  stage?: string;
}): Project[] {
  let filtered = [...localProjects];

  if (params?.search) {
    const q = params.search.toLowerCase().trim();
    filtered = filtered.filter(
      p =>
        p.name.toLowerCase().includes(q) ||
        p.district.toLowerCase().includes(q) ||
        p.state.toLowerCase().includes(q) ||
        p.talukOrTehsil.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q)
    );
  }

  if (params?.risk && params.risk !== 'ALL') {
    filtered = filtered.filter(p => p.riskLevel === params.risk?.toUpperCase());
  }

  if (params?.state && params.state !== 'ALL') {
    filtered = filtered.filter(p => p.state === params.state);
  }

  if (params?.stage && params.stage !== 'ALL') {
    filtered = filtered.filter(p => p.currentStage === params.stage);
  }

  return filtered;
}

export function getLocalProjectById(id: string): Project | undefined {
  return localProjects.find(p => p.id === id);
}

export function getLocalAlerts(): AlertItem[] {
  return localAlerts;
}

export function acknowledgeLocalAlert(id: string): AlertItem | undefined {
  const alert = localAlerts.find(a => a.id === id);
  if (alert) {
    alert.status = 'Acknowledged';
  }
  return alert;
}

export function getLocalRiskMapData() {
  return localProjects.map(p => ({
    id: p.id,
    name: p.name,
    location: `${p.district}, ${p.state}`,
    coordinates: p.coordinates,
    riskLevel: p.riskLevel,
    delayProbability: p.delayProbability,
    mainIssue: p.mainIssue,
    currentStage: p.currentStage,
    landAcquiredHa: p.landAcquiredHa,
    totalLandRequiredHa: p.totalLandRequiredHa
  }));
}

export function runLocalWhatIf(request: WhatIfRequest): WhatIfResponse {
  const p = getLocalProjectById(request.projectId);
  return execWhatIf(request, p);
}
