import React from 'react';
import { Menu, RefreshCw, Bell, Cpu, UserCheck } from 'lucide-react';
import { NavView } from './Sidebar.tsx';
import { GovernmentEmblem } from './common/GovernmentEmblem.tsx';

interface NavbarProps {
  currentView: NavView;
  projectName?: string;
  onOpenMobileSidebar: () => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
  onOpenModelInfo?: () => void;
  unreadAlertsCount?: number;
  onNavigateToAlerts?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  projectName,
  onOpenMobileSidebar,
  onRefresh,
  isRefreshing = false,
  onOpenModelInfo,
  unreadAlertsCount = 0,
  onNavigateToAlerts
}) => {
  const getViewTitle = () => {
    switch (currentView) {
      case 'dashboard':
        return 'Executive Monitoring Dashboard';
      case 'projects':
        return 'National Corridor Projects Directory';
      case 'project-details':
        return projectName ? `Project Review: ${projectName}` : 'Project Intelligence Review';
      case 'data-sync':
        return 'Data Hub & Statutory BhoomiRashi Ingestion';
      case 'map':
        return 'Geographic Risk & Spatial Corridor Grid';
      case 'alerts':
        return 'Early Warning & Escalation Center';
      case 'what-if':
        return 'What-if Scenario & Policy Simulator';
      case 'reports':
        return 'Statutory & Executive Reports Hub';
      default:
        return 'Land Acquisition Monitoring & Delay Prediction System';
    }
  };

  return (
    <header className="sticky top-0 z-30 gov-glass px-4 lg:px-7 py-2.5 flex items-center justify-between transition-all">
      <div className="flex items-center gap-3 min-w-0">
        {/* Mobile menu trigger */}
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Open navigation sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Institutional Title & Hierarchy */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="hidden sm:block lg:hidden">
            <GovernmentEmblem size={28} />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wider truncate flex items-center gap-1.5">
              <span>Government of India</span>
              <span className="text-slate-300">•</span>
              <span className="text-slate-700 font-semibold">Ministry of Road Transport & Highways (MoRTH)</span>
            </div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 leading-tight truncate">
              {getViewTitle()}
            </h1>
          </div>
        </div>
      </div>

      {/* Right Controls: Notifications, ML Inspector, Refresh, User Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* ML Model Explanation Quick Trigger */}
        {onOpenModelInfo && (
          <button
            onClick={onOpenModelInfo}
            className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-2xs cursor-pointer"
            title="Inspect Random Forest ML Model Parameters & Shapley Weights"
          >
            <Cpu className="w-3.5 h-3.5 text-[#1E3A5F]" />
            <span className="hidden xl:inline">ML Model ⓘ</span>
          </button>
        )}

        {/* Live Refresh Trigger */}
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50 shadow-2xs cursor-pointer"
          title="Query live backend state & refresh statutory records"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 ${
              isRefreshing ? 'animate-spin text-blue-700' : 'text-slate-500'
            }`}
          />
          <span className="hidden sm:inline">Refresh</span>
        </button>

        {/* Notification Bell */}
        {onNavigateToAlerts && (
          <button
            onClick={onNavigateToAlerts}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200 cursor-pointer"
            title={`${unreadAlertsCount} active statutory escalations`}
            aria-label="View alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white" />
            )}
          </button>
        )}

        {/* Officer Profile Badge */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
          <div className="w-7 h-7 rounded-full bg-[#0F2027] text-white flex items-center justify-center text-xs font-bold shadow-2xs">
            <UserCheck className="w-3.5 h-3.5 text-amber-300" />
          </div>
          <div className="hidden lg:block text-left text-xs leading-tight">
            <p className="font-semibold text-slate-800">User</p>
            <p className="text-[10px] text-slate-500">User Portal</p>
          </div>
        </div>
      </div>
    </header>
  );
};
