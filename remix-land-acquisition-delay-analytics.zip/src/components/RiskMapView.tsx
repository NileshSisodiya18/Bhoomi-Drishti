import React, { useEffect, useRef, useState } from 'react';
import { Project, RiskLevel } from '../types.ts';
import { RiskBadge, StageStatusBadge } from './StatusBadge.tsx';
import {
  ArrowRight,
  MapPin,
  AlertCircle,
  Info,
  Layers,
  Search,
  ChevronDown,
  ChevronUp,
  Building2,
  Navigation,
  ShieldCheck,
  TrendingDown,
  Eye
} from 'lucide-react';
import L from 'leaflet';

interface RiskMapViewProps {
  projects: Project[];
  onSelectProject: (id: string) => void;
}

export const RiskMapView: React.FC<RiskMapViewProps> = ({
  projects,
  onSelectProject
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const markersRef = useRef<L.CircleMarker[]>([]);
  const corridorLinesRef = useRef<L.Polyline[]>([]);

  const [selectedRisk, setSelectedRisk] = useState<string>('ALL');
  const [selectedState, setSelectedState] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [basemapStyle, setBasemapStyle] = useState<'streets' | 'light'>('light');
  const [statsExpanded, setStatsExpanded] = useState<boolean>(true);
  const [drawerOpen, setDrawerOpen] = useState<boolean>(true);
  const [activeProject, setActiveProject] = useState<Project | null>(
    projects.find(p => p.riskLevel === 'HIGH') || projects[0] || null
  );

  // Unique states
  const states = ['ALL', ...Array.from(new Set(projects.map(p => p.state))).sort()];

  // Compute National corridor stats
  const totalLand = projects.reduce((acc, p) => acc + (p.totalLandRequiredHa || 0), 0);
  const acquiredLand = projects.reduce((acc, p) => acc + (p.landAcquiredHa || 0), 0);
  const highRiskCount = projects.filter(p => p.riskLevel === 'HIGH').length;
  const mediumRiskCount = projects.filter(p => p.riskLevel === 'MEDIUM').length;

  const mappedCount = projects.filter(
    p => p.coordinates && typeof p.coordinates.lat === 'number' && typeof p.coordinates.lng === 'number' && !isNaN(p.coordinates.lat)
  ).length;
  const unmappedCount = projects.length - mappedCount;

  const filteredProjects = projects.filter(p => {
    const matchesRisk = selectedRisk === 'ALL' || p.riskLevel === selectedRisk;
    const matchesState = selectedState === 'ALL' || p.state === selectedState;
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !query ||
      p.name.toLowerCase().includes(query) ||
      p.district.toLowerCase().includes(query) ||
      p.state.toLowerCase().includes(query) ||
      (p.highwayNumber && p.highwayNumber.toLowerCase().includes(query));
    return matchesRisk && matchesState && matchesSearch;
  });

  // Basemap URLs
  const basemaps = {
    light: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    streets: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Center over central India
      const map = L.map(mapContainerRef.current, {
        center: [21.8, 78.9],
        zoom: 5,
        zoomControl: false,
        scrollWheelZoom: true
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      const layer = L.tileLayer(basemaps[basemapStyle], {
        attribution: '&copy; OpenStreetMap contributors & CARTO',
        maxZoom: 18
      }).addTo(map);

      tileLayerRef.current = layer;
      mapInstanceRef.current = map;
    }
  }, []);

  // Update Tile Layer on basemap change
  useEffect(() => {
    if (mapInstanceRef.current && tileLayerRef.current) {
      tileLayerRef.current.setUrl(basemaps[basemapStyle]);
    }
  }, [basemapStyle]);

  // Update Markers and Corridor Polylines when filter or projects change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear previous markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    // Clear previous corridor lines
    corridorLinesRef.current.forEach(l => l.remove());
    corridorLinesRef.current = [];

    // Group projects by corridor to draw corridor route lines if >1 project shares corridor
    const corridorGroups: { [key: string]: Project[] } = {};
    projects.forEach(p => {
      const hw = p.highwayNumber || 'Other';
      if (!corridorGroups[hw]) corridorGroups[hw] = [];
      corridorGroups[hw].push(p);
    });

    Object.entries(corridorGroups).forEach(([hw, projs]) => {
      if (projs.length > 1 && hw !== 'Other') {
        const sorted = [...projs].sort((a, b) => a.coordinates.lat - b.coordinates.lat);
        const latLngs = sorted.map(p => [p.coordinates.lat, p.coordinates.lng] as [number, number]);
        const hasHigh = projs.some(p => p.riskLevel === 'HIGH');
        const hasMed = projs.some(p => p.riskLevel === 'MEDIUM');
        const lineColor = hasHigh ? '#dc2626' : hasMed ? '#d97706' : '#2563eb';

        const polyline = L.polyline(latLngs, {
          color: lineColor,
          weight: 3,
          dashArray: '4, 6',
          opacity: 0.65
        }).addTo(map);

        corridorLinesRef.current.push(polyline);
      }
    });

    // Add Circle Markers for each filtered project
    filteredProjects.forEach(proj => {
      let color = '#059669'; // Emerald for LOW
      let fillColor = '#10b981';

      if (proj.riskLevel === 'HIGH') {
        color = '#b91c1c'; // Dark Red
        fillColor = '#ef4444';
      } else if (proj.riskLevel === 'MEDIUM') {
        color = '#d97706'; // Amber
        fillColor = '#f59e0b';
      }

      const marker = L.circleMarker([proj.coordinates.lat, proj.coordinates.lng], {
        radius: proj.riskLevel === 'HIGH' ? 11 : 9,
        fillColor: fillColor,
        color: color,
        weight: 2.5,
        opacity: 1,
        fillOpacity: 0.85
      }).addTo(map);

      // Tooltip
      marker.bindTooltip(
        `<div style="font-family: inherit; font-size: 11px; padding: 2px;">
          <strong style="color: #0f172a;">${proj.name}</strong><br/>
          <span style="color: #64748b;">${proj.district}, ${proj.state}</span><br/>
          <strong>Risk: ${proj.riskLevel} (${proj.delayProbability}%)</strong>
        </div>`,
        { direction: 'top', offset: [0, -6] }
      );

      marker.on('click', () => {
        setActiveProject(proj);
      });

      markersRef.current.push(marker);
    });
  }, [filteredProjects, projects]);

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Navigation className="w-6 h-6 text-blue-900" />
            <span>National GIS Risk Command Center</span>
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Geographic corridor distribution, statutory bottleneck monitoring, and DGPS alignment surveys
          </p>
        </div>

        {/* Basemap Toggle & Fit */}
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-xs font-semibold shadow-2xs">
            <button
              onClick={() => setBasemapStyle('light')}
              className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                basemapStyle === 'light' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Administrative Light
            </button>
            <button
              onClick={() => setBasemapStyle('streets')}
              className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                basemapStyle === 'streets' ? 'bg-blue-900 text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              OpenStreetMap
            </button>
          </div>
        </div>
      </div>

      {/* Collapsible National Corridor Statistics Strip */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="p-3.5 sm:px-5 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-slate-600" />
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              National Corridor Health Summary
            </span>
          </div>
          <button
            onClick={() => setStatsExpanded(!statsExpanded)}
            className="text-xs text-slate-500 hover:text-slate-900 flex items-center gap-1 cursor-pointer font-medium"
          >
            <span>{statsExpanded ? 'Collapse' : 'Expand'}</span>
            {statsExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {statsExpanded && (
          <div className="p-4 sm:px-5 grid grid-cols-2 sm:grid-cols-4 gap-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Monitored Packages</span>
              <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">{projects.length}</div>
              <p className="text-[11px] text-slate-500">Across 14 States</p>
            </div>
            <div className="sm:pl-4 pt-2 sm:pt-0">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">High Risk Alerts</span>
              <div className="text-xl font-bold font-mono text-red-700 mt-0.5">{highRiskCount} packages</div>
              <p className="text-[11px] text-red-600/80">≥70% delay forecast</p>
            </div>
            <div className="sm:pl-4 pt-2 sm:pt-0">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Medium Risk Alerts</span>
              <div className="text-xl font-bold font-mono text-amber-700 mt-0.5">{mediumRiskCount} packages</div>
              <p className="text-[11px] text-amber-600/80">Under monitoring</p>
            </div>
            <div className="sm:pl-4 pt-2 sm:pt-0">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Land Acquired</span>
              <div className="text-xl font-bold font-mono text-emerald-700 mt-0.5">
                {Math.round(acquiredLand)} / {Math.round(totalLand)} <span className="text-xs font-normal">Ha</span>
              </div>
              <p className="text-[11px] text-emerald-600/80">
                {totalLand > 0 ? Math.round((acquiredLand / totalLand) * 100) : 0}% total completed
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Main Map + Inspector Layout (Section 21) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start relative">
        {/* Leaflet Map Box */}
        <div className={`${drawerOpen ? 'lg:col-span-8' : 'lg:col-span-12'} transition-all duration-300 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs h-[600px] relative`}>
          <div ref={mapContainerRef} className="w-full h-full z-10" />

          {/* Floating Top Filter & Control Bar (Section 21) */}
          <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
            <div className="flex flex-wrap items-center gap-2 pointer-events-auto">
              {/* [All States] Dropdown */}
              <select
                value={selectedState}
                onChange={e => setSelectedState(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold bg-white/92 backdrop-blur-md border border-slate-300 rounded-lg shadow-sm text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                <option value="ALL">All States ({projects.length})</option>
                {states.filter(s => s !== 'ALL').map(s => (
                  <option key={s} value={s}>
                    {s} ({projects.filter(p => p.state === s).length})
                  </option>
                ))}
              </select>

              {/* [Search Project...] Input */}
              <div className="relative max-w-[200px] sm:max-w-xs w-full">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search Project..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-white/92 backdrop-blur-md border border-slate-300 rounded-lg shadow-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Risk Pills: [High Risk] [Medium Risk] [Low Risk] */}
              <div className="flex items-center gap-1 bg-white/92 backdrop-blur-md border border-slate-200 rounded-lg p-0.5 text-xs font-semibold shadow-sm">
                <button
                  onClick={() => setSelectedRisk('ALL')}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                    selectedRisk === 'ALL' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setSelectedRisk('HIGH')}
                  className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                    selectedRisk === 'HIGH' ? 'bg-red-700 text-white' : 'text-red-700 hover:bg-red-50'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  High Risk
                </button>
                <button
                  onClick={() => setSelectedRisk('MEDIUM')}
                  className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                    selectedRisk === 'MEDIUM' ? 'bg-amber-600 text-white' : 'text-amber-800 hover:bg-amber-50'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Medium Risk
                </button>
                <button
                  onClick={() => setSelectedRisk('LOW')}
                  className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer ${
                    selectedRisk === 'LOW' ? 'bg-emerald-700 text-white' : 'text-emerald-800 hover:bg-emerald-50'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Low Risk
                </button>
              </div>
            </div>

            {/* Toggle Drawer Button */}
            <button
              onClick={() => setDrawerOpen(!drawerOpen)}
              className="pointer-events-auto px-3 py-1.5 bg-white/92 backdrop-blur-md border border-slate-300 hover:bg-white text-slate-700 rounded-lg text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer ml-auto"
            >
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span>{drawerOpen ? 'Hide Drawer' : 'Show Details Drawer'}</span>
            </button>
          </div>

          {/* Map legend overlay (lightweight translucent card) */}
          <div className="absolute bottom-3 left-3 z-20 bg-white/92 backdrop-blur-md border border-slate-200 rounded-lg p-2.5 text-[11px] shadow-sm space-y-1">
            <div className="font-bold text-slate-700 uppercase tracking-wider mb-1">
              GIS Legend
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 border border-white" />
              <span>High (≥70% probability)</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 border border-white" />
              <span>Medium (35%–69%)</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 border border-white" />
              <span>Low (&lt;35%)</span>
            </div>
            <div className="flex items-center gap-2 text-slate-500 pt-1 border-t border-slate-100">
              <span className="w-3 h-0.5 border-t-2 border-dashed border-red-500" />
              <span>Corridor Alignment Vector</span>
            </div>
          </div>
        </div>

        {/* Selected Project Inspector Card (Collapsible Drawer, 4 cols) */}
        {drawerOpen && (
          <div className="lg:col-span-4 bg-white/95 backdrop-blur-md border border-slate-200 rounded-xl p-5 shadow-2xs flex flex-col justify-between min-h-[600px] transition-all">
            {activeProject ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Project Details Drawer
                  </span>
                  <button
                    onClick={() => setDrawerOpen(false)}
                    className="text-slate-400 hover:text-slate-700 text-xs font-semibold cursor-pointer"
                  >
                    ✕ Close
                  </button>
                </div>
                <div>
                  <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold border border-slate-200">
                    {activeProject.id}
                  </span>
                  <RiskBadge level={activeProject.riskLevel} />
                </div>

                <h3 className="text-base font-bold text-slate-900 tracking-tight mt-2 leading-snug">
                  {activeProject.name}
                </h3>

                <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {activeProject.district}, {activeProject.state}
                  </span>
                  {activeProject.highwayNumber && (
                    <>
                      <span className="text-slate-300">•</span>
                      <span className="font-semibold text-slate-700">{activeProject.highwayNumber}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Delay Probability Card */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Delay Probability
                </div>
                <div
                  className={`text-2xl font-bold mt-0.5 ${
                    activeProject.riskLevel === 'HIGH'
                      ? 'text-red-700'
                      : activeProject.riskLevel === 'MEDIUM'
                      ? 'text-amber-700'
                      : 'text-emerald-700'
                  }`}
                >
                  {activeProject.delayProbability}%
                </div>
                <div className="text-xs text-slate-600 mt-0.5">
                  Statutory variance: <strong>+{activeProject.delayVarianceMonths} months</strong>
                </div>
              </div>

              {/* Primary Impediment */}
              <div className="space-y-1">
                <div className="text-xs font-semibold text-slate-700">Primary Bottleneck:</div>
                <p className="text-xs text-red-800 bg-red-50 p-2.5 rounded-lg border border-red-200 leading-relaxed font-medium">
                  {activeProject.mainIssue}
                </p>
              </div>

              {/* Key Attributes */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-slate-400 text-[10px]">Statutory Stage</div>
                  <div className="font-semibold text-slate-800 truncate mt-0.5">
                    {activeProject.currentStage}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-lg">
                  <div className="text-slate-400 text-[10px]">Land Acquired</div>
                  <div className="font-semibold text-slate-800 mt-0.5">
                    {Math.round(
                      (activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100
                    )}
                    % ({activeProject.landAcquiredHa} Ha)
                  </div>
                </div>
              </div>

              {/* Coordinates strip */}
              <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-[11px] font-mono text-slate-600 flex items-center justify-between">
                <span>DGPS Coordinates:</span>
                <span>
                  {activeProject.coordinates.lat.toFixed(4)}°N, {activeProject.coordinates.lng.toFixed(4)}°E
                </span>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onSelectProject(activeProject.id)}
                className="w-full mt-2 py-2.5 bg-blue-900 hover:bg-blue-950 text-white rounded-lg text-xs font-bold tracking-wide transition-colors flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <span>Open Project Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <MapPin className="w-8 h-8 mb-2 text-slate-300" />
              <p className="text-xs font-medium">Click on any marker on the map to inspect package details.</p>
            </div>
          )}

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400">
            Coordinates sourced from official project alignment surveys (DGPS/GIS).
          </div>
        </div>
        )}
      </div>
    </div>
  );
};
