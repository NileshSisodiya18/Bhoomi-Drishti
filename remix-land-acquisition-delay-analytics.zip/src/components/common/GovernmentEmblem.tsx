import React from 'react';

interface GovernmentEmblemProps {
  className?: string;
  size?: number;
}

export const GovernmentEmblem: React.FC<GovernmentEmblemProps> = ({
  className = 'w-8 h-8',
  size = 32
}) => {
  return (
    <div className={`relative flex items-center justify-center shrink-0 ${className}`}>
      {/* Official styled emblem visual with Lion Capital silhouette & Ashoka Chakra base */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="text-amber-500 drop-shadow-xs"
        aria-label="Government of India Emblem Style Insignia"
      >
        {/* Outer Circular Seal Frame */}
        <circle cx="24" cy="24" r="22" stroke="currentColor" strokeWidth="1.5" strokeOpacity="0.4" fill="#0f2942" />
        <circle cx="24" cy="24" r="19.5" stroke="currentColor" strokeWidth="0.75" strokeOpacity="0.6" strokeDasharray="1.5 1.5" />
        
        {/* Ashoka Lion Silhouette Base */}
        <path
          d="M24 8C21.8 8 20 9.8 20 12C20 13.1 20.4 14.1 21.1 14.8C18.8 15.6 17 17.8 17 20.5C17 21.9 17.5 23.2 18.3 24.2C17.5 25.1 17 26.2 17 27.5C17 29.4 18.2 31 19.8 31.6V33H16V35H32V33H28.2V31.6C29.8 31 31 29.4 31 27.5C31 26.2 30.5 25.1 29.7 24.2C30.5 23.2 31 21.9 31 20.5C31 17.8 29.2 15.6 26.9 14.8C27.6 14.1 28 13.1 28 12C28 9.8 26.2 8 24 8Z"
          fill="currentColor"
          fillOpacity="0.92"
        />
        
        {/* Ashoka Chakra Wheel */}
        <circle cx="24" cy="38.5" r="3.5" stroke="currentColor" strokeWidth="1" fill="#0a192f" />
        <line x1="24" y1="35" x2="24" y2="42" stroke="currentColor" strokeWidth="0.8" />
        <line x1="20.5" y1="38.5" x2="27.5" y2="38.5" stroke="currentColor" strokeWidth="0.8" />
        <line x1="21.5" y1="36" x2="26.5" y2="41" stroke="currentColor" strokeWidth="0.7" />
        <line x1="21.5" y1="41" x2="26.5" y2="36" stroke="currentColor" strokeWidth="0.7" />
        
        {/* Saffron and Green accent dots */}
        <circle cx="13" cy="24" r="1.5" fill="#f97316" />
        <circle cx="35" cy="24" r="1.5" fill="#16a34a" />
      </svg>
    </div>
  );
};
