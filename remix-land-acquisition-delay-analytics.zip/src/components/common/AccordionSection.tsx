import React, { useState } from 'react';
import { ChevronDown, LucideIcon } from 'lucide-react';

interface AccordionSectionProps {
  id?: string;
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  badge?: React.ReactNode;
  summarySnippet?: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
  className?: string;
}

export const AccordionSection: React.FC<AccordionSectionProps> = ({
  id,
  title,
  subtitle,
  icon: Icon,
  badge,
  summarySnippet,
  defaultOpen = false,
  children,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div
      id={id}
      className={`bg-white border border-slate-200/90 rounded-xl overflow-hidden shadow-2xs transition-all duration-200 ${className}`}
    >
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 sm:p-4.5 text-left bg-white hover:bg-slate-50/80 transition-colors focus:outline-hidden focus:bg-slate-50 cursor-pointer group"
        aria-expanded={isOpen}
      >
        <div className="flex items-center gap-3 min-w-0 flex-1">
          {Icon && (
            <div className="w-8 h-8 rounded-lg bg-slate-100/90 flex items-center justify-center text-slate-700 shrink-0 group-hover:bg-blue-50 group-hover:text-blue-900 transition-colors">
              <Icon className="w-4 h-4" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm sm:text-base font-semibold text-slate-900 tracking-tight">
                {title}
              </span>
              {badge}
            </div>
            {subtitle && (
              <p className="text-xs text-slate-500 mt-0.5 truncate">{subtitle}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 ml-3 shrink-0">
          {summarySnippet && (
            <div className="hidden sm:block text-right">
              {summarySnippet}
            </div>
          )}
          <span className="text-xs text-slate-400 font-medium hidden md:inline">
            {isOpen ? 'Hide' : 'View'}
          </span>
          <div
            className={`w-7 h-7 rounded-md flex items-center justify-center text-slate-500 transition-transform duration-200 ${
              isOpen ? 'rotate-180 bg-slate-100 text-slate-800' : 'bg-slate-50 group-hover:bg-slate-100'
            }`}
          >
            <ChevronDown className="w-4 h-4" />
          </div>
        </div>
      </button>

      {isOpen && (
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-white animate-in fade-in duration-200">
          {children}
        </div>
      )}
    </div>
  );
};
