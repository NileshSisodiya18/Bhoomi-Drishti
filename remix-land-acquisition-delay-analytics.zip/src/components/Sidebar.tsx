import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  Database,
  MapPin,
  Bell,
  SlidersHorizontal,
  FileText,
  Settings,
  HelpCircle,
  ShieldCheck,
  X,
  ExternalLink,
  Radio
} from 'lucide-react';
import { GovernmentEmblem } from './common/GovernmentEmblem.tsx';

export type NavView =
  | 'dashboard'
  | 'projects'
  | 'data-sync'
  | 'map'
  | 'alerts'
  | 'what-if'
  | 'reports'
  | 'project-details';

interface SidebarProps {
  currentView: NavView;
  onNavigate: (view: NavView) => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  onOpenModelInfo?: () => void;
  unreadAlertsCount?: number;
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  onOpenSettings,
  onOpenHelp,
  onOpenModelInfo,
  unreadAlertsCount = 0,
  mobileOpen = false,
  onCloseMobile
}) => {
  // Primary Core Navigation (Section 10)
  const primaryNavItems = [
    {
      id: 'dashboard' as NavView,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Executive Portfolio'
    },
    {
      id: 'projects' as NavView,
      label: 'Projects',
      icon: FolderKanban,
      description: 'National Directory'
    },
    {
      id: 'map' as NavView,
      label: 'Risk Map',
      icon: MapPin,
      description: 'Spatial Corridor Grid'
    },
    {
      id: 'alerts' as NavView,
      label: 'Alerts',
      icon: Bell,
      badge: unreadAlertsCount > 0 ? unreadAlertsCount : null,
      description: 'Early Warnings'
    },
    {
      id: 'data-sync' as NavView,
      label: 'Data Hub',
      icon: Database,
      description: 'BhoomiRashi Ingestion'
    }
  ];

  // Secondary Tools
  const secondaryNavItems = [
    {
      id: 'what-if' as NavView,
      label: 'What-if Simulator',
      icon: SlidersHorizontal,
      description: 'Policy Sensitivity'
    },
    {
      id: 'reports' as NavView,
      label: 'Statutory Reports',
      icon: FileText,
      description: 'Executive Summaries'
    }
  ];

  const handleNavClick = (view: NavView) => {
    onNavigate(view);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#0F2027] text-slate-200 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Institutional Branding Header */}
        <div className="p-4 border-b border-slate-800/90 bg-[#07131B] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GovernmentEmblem size={36} />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-[15px] tracking-wider text-white">
                  BHOOMI-DRISHTI
                </span>
              </div>
              <p className="text-[10px] text-slate-300 font-medium tracking-tight">
                Government of India • MoRTH
              </p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={onCloseMobile}
            className="lg:hidden text-slate-400 hover:text-white p-1 rounded-md cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* System Status Ribbon */}
        <div className="px-4 py-2 bg-[#09161C] border-b border-slate-800/60 text-[11px] text-slate-300 font-medium flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Statutory Network Active</span>
          </div>
          <span className="text-[9.5px] uppercase px-1.5 py-0.5 rounded bg-slate-800 text-amber-300/90 font-bold border border-amber-900/40">
            Data Gateway
          </span>
        </div>

        {/* Primary Navigation List */}
        <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
          {/* Main Core Modules */}
          <div className="space-y-1">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1">
              Core Modules
            </div>
            {primaryNavItems.map(item => {
              const Icon = item.icon;
              const isActive =
                currentView === item.id ||
                (item.id === 'projects' && currentView === 'project-details');

              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all group cursor-pointer ${
                    isActive
                      ? 'bg-slate-800/90 text-white font-semibold border-l-3 border-[#C5A059] shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-[#C5A059]' : 'text-slate-400 group-hover:text-slate-200'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge && (
                    <span className="bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full shrink-0">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Analysis & Simulation Tools */}
          <div className="space-y-1 pt-2 border-t border-slate-800/60">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1">
              Analysis & Simulation
            </div>
            {secondaryNavItems.map(item => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group cursor-pointer ${
                    isActive
                      ? 'bg-slate-800/90 text-white font-semibold border-l-3 border-[#C5A059]'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-[#C5A059]' : 'text-slate-400 group-hover:text-slate-200'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </nav>

        {/* Institutional Context & Officer Session Footer */}
        <div className="p-3 border-t border-slate-800/90 bg-[#07131B] space-y-2">
          <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="min-w-0 text-[11px]">
              <p className="font-semibold text-slate-200 truncate">MoRTH Verified Source</p>
              <p className="text-slate-400 text-[10px] leading-tight">
                Authentic BhoomiRashi live synchronizer connected
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 px-1 pt-1">
            <button
              onClick={onOpenHelp}
              className="flex items-center gap-1 hover:text-slate-200 transition-colors cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Guide</span>
            </button>
            <button
              onClick={onOpenSettings}
              className="flex items-center gap-1 hover:text-slate-200 transition-colors cursor-pointer"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Config</span>
            </button>
            <span className="text-[10px] text-slate-500 font-mono">v2.6 Production</span>
          </div>
        </div>
      </aside>
    </>
  );
};
