import React from 'react';
import { X, HelpCircle, BookOpen, ShieldCheck } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-xl space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">User Guide & Reference</h2>
              <p className="text-xs text-slate-500">Government of India • Ministry of Road Transport & Highways</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Core UX Principle */}
        <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 text-xs space-y-1">
          <div className="font-bold text-slate-900">Core Administrative Principle:</div>
          <p className="text-slate-700 leading-relaxed font-semibold">
            “See the problem → Understand the reason → Know what needs attention → Take action.”
          </p>
          <p className="text-[11px] text-slate-500 pt-1">
            Designed specifically for administrative officers without requiring machine learning or data science expertise.
          </p>
        </div>

        {/* 4 User Questions */}
        <div className="space-y-2 text-xs">
          <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
            The 4 Questions BhumiDrishti Answers:
          </div>
          <ol className="list-decimal list-inside space-y-1 text-slate-700">
            <li><strong>Which projects are at risk?</strong> (Dashboard &amp; Projects Directory)</li>
            <li><strong>Why are they at risk?</strong> (Top 3 Main Risk Factors in Project Details)</li>
            <li><strong>Which project needs attention first?</strong> (Projects Needing Attention ranking)</li>
            <li><strong>What action should be considered?</strong> (Statutory Recommended Actions)</li>
          </ol>
        </div>

        {/* Statutory Stages */}
        <div className="space-y-2 text-xs pt-2 border-t border-slate-100">
          <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
            Statutory Acquisition Stages:
          </div>
          <div className="space-y-1 text-slate-600">
            <p><strong>1. Identification:</strong> Alignment survey, preliminary notification under Section 3A / 11.</p>
            <p><strong>2. Verification:</strong> Joint Measurement Survey (JMS) and social impact assessment.</p>
            <p><strong>3. Compensation:</strong> User award declaration, solatium calculation, direct transfer to Khatadars.</p>
            <p><strong>4. Legal / Documentation:</strong> Section 3D declaration, reference court dispute resolution under Sec 64/77.</p>
            <p><strong>5. Possession:</strong> Physical possession memo handover under Section 3E / Section 38.</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold tracking-wide transition-colors"
        >
          Got it
        </button>
      </div>
    </div>
  );
};
