import React, { useState, useEffect } from 'react';
import { Project, WhatIfResponse } from '../types.ts';
import { api } from '../services/apiClient.ts';
import { RiskBadge, DataSourceBadge } from './StatusBadge.tsx';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import {
  SlidersHorizontal,
  Play,
  RotateCcw,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  Scale,
  TreePine,
  CheckCircle2,
  FileSpreadsheet,
  Info,
  MapPin,
  Sparkles,
  Download,
  IndianRupee,
  FileText,
  Building2,
  Check
} from 'lucide-react';

interface WhatIfViewProps {
  projects: Project[];
  initialProjectId?: string;
  onSelectProject?: (id: string) => void;
}

export const WhatIfView: React.FC<WhatIfViewProps> = ({
  projects,
  initialProjectId,
  onSelectProject
}) => {
  const defaultProj =
    (initialProjectId && projects.find(p => p.id === initialProjectId)) ||
    projects.find(p => p.riskLevel === 'HIGH') ||
    projects[0];

  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    defaultProj?.id || ''
  );

  const activeProject = projects.find(p => p.id === selectedProjectId) || defaultProj;

  // Scenario input parameters
  const [compensation, setCompensation] = useState<number>(
    activeProject?.compensationDisbursedPercent || 20
  );
  const [hasStay, setHasStay] = useState<boolean>(
    activeProject?.hasCourtStay || false
  );
  const [docCount, setDocCount] = useState<number>(
    activeProject?.incompleteDocumentsCount || 10
  );
  const [legalCases, setLegalCases] = useState<number>(
    activeProject?.unresolvedLegalCases || 3
  );
  const [forestStage, setForestStage] = useState<string>(
    activeProject?.forestClearanceStage || 'Not Required'
  );

  // Simulation output
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<WhatIfResponse | null>(null);

  // Sync inputs when project selection changes
  useEffect(() => {
    if (activeProject) {
      setCompensation(activeProject.compensationDisbursedPercent);
      setHasStay(activeProject.hasCourtStay);
      setDocCount(activeProject.incompleteDocumentsCount);
      setLegalCases(activeProject.unresolvedLegalCases);
      setForestStage(activeProject.forestClearanceStage);
      setResult(null);
    }
  }, [selectedProjectId]);

  const handleRunSimulation = async () => {
    if (!activeProject) return;
    setLoading(true);
    try {
      const res = await api.runWhatIf({
        projectId: activeProject.id,
        compensationDisbursedPercent: Number(compensation),
        hasCourtStay: hasStay,
        unresolvedLegalCases: Number(legalCases),
        incompleteDocumentsCount: Number(docCount),
        forestClearanceStage: forestStage
      });
      setResult(res);
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    if (!activeProject) return;
    setCompensation(activeProject.compensationDisbursedPercent);
    setHasStay(activeProject.hasCourtStay);
    setDocCount(activeProject.incompleteDocumentsCount);
    setLegalCases(activeProject.unresolvedLegalCases);
    setForestStage(activeProject.forestClearanceStage);
    setResult(null);
  };

  const handleExportBriefing = () => {
    if (!activeProject || !result) return;
    const simR = result.simulatedRisk || result.scenarioRisk;
    const simProb = simR ? simR.delayProbability : 0;
    const simLvl = simR ? simR.riskLevel : 'LOW';
    const simVar = simR ? (simR.delayVarianceMonths ?? 0) : 0;

    const content = `BHOOMIDRISHTI EXECUTIVE WHAT-IF SIMULATION BRIEFING
===================================================
Project: ${activeProject.name} (Package ID: ${activeProject.sourceProjectId || activeProject.id})
Location: ${activeProject.district}, ${activeProject.state}
Corridor: ${activeProject.highwayNumber || 'National Highway'}
Date of Simulation: ${new Date().toLocaleDateString('en-IN')}

BASELINE PARAMETERS:
- Delay Probability: ${activeProject.delayProbability}% (${activeProject.riskLevel})
- Delay Variance: +${activeProject.delayVarianceMonths} months
- Compensation Disbursed: ${activeProject.compensationDisbursedPercent}%
- Court Injunction: ${activeProject.hasCourtStay ? 'ACTIVE' : 'NONE'}
- Revenue Mutation Backlog: ${activeProject.incompleteDocumentsCount} cases
- Forest Clearance: ${activeProject.forestClearanceStage}

SIMULATED COUNTERFACTUAL PARAMETERS:
- Simulated Delay Probability: ${simProb}% (${simLvl})
- Simulated Delay Variance: +${simVar} months
- Adjusted Compensation: ${compensation}%
- Adjusted Court Injunction: ${hasStay ? 'ACTIVE' : 'RESOLVED/VACATED'}
- Adjusted Mutation Backlog: ${docCount} cases
- Adjusted Forest Stage: ${forestStage}

IMPACT FORECAST:
- Net Risk Reduction: ${activeProject.delayProbability - simProb}%
- Schedule Recovery: ${Math.round((activeProject.delayVarianceMonths - simVar) * 10) / 10} months
- Summary: ${result.impactSummary || 'Significant statutory acceleration achievable via targeted executive intervention.'}
`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `WhatIf-Briefing-${activeProject.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!activeProject) {
    return (
      <div className="py-20 text-center text-slate-500">
        <p>No project data available for simulation.</p>
      </div>
    );
  }

  const currentRisk = activeProject.delayProbability;
  const simRisk = result ? (result.simulatedRisk || result.scenarioRisk) : null;
  const simulatedRisk = simRisk ? simRisk.delayProbability : null;
  const riskDelta = simulatedRisk !== null ? simulatedRisk - currentRisk : 0;
  const simVarianceMonths = simRisk ? (simRisk.delayVarianceMonths ?? 0) : 0;
  const delayDelta = result ? Math.round((activeProject.delayVarianceMonths - simVarianceMonths) * 10) / 10 : 0;

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-14">
      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <SlidersHorizontal className="w-6 h-6 text-blue-900" />
              <span>What-If Policy & Scenario Simulator</span>
            </h1>
            <InfoTooltip
              title="Simulation Engine"
              content="Calculates counterfactual delay probability by running adjusted statutory parameters through the calibrated Random Forest ML model."
            />
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Evaluate sensitivity of delay probabilities to targeted administrative interventions before committing field resources.
          </p>
        </div>

        {/* Project Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider shrink-0">
            Package:
          </label>
          <select
            value={selectedProjectId}
            onChange={e => setSelectedProjectId(e.target.value)}
            className="text-xs font-semibold bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-800 shadow-2xs focus:outline-hidden focus:ring-1 focus:ring-blue-500 max-w-xs cursor-pointer"
          >
            {projects.map(p => (
              <option key={p.id} value={p.id}>
                {p.sourceProjectId || p.id} — {p.name.substring(0, 32)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Official Legal Disclaimer Banner (Section 16) */}
      <div className="bg-amber-50/80 border border-amber-200 rounded-lg px-3.5 py-2.5 flex items-center gap-2 text-xs text-amber-900 font-medium">
        <span className="w-2 h-2 rounded-full bg-amber-600 shrink-0" />
        <span>Scenario — does not modify actual project data. Live BhoomiRashi synchronization and statutory records remain unaffected.</span>
      </div>

      {/* Quick Scenario Selector (Section 17) */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            Quick Scenario Presets
          </span>
          <span className="text-[11px] text-slate-500">Click preset to populate inputs immediately</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => setCompensation(90)}
            className="px-3 py-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center"
          >
            <IndianRupee className="w-3 h-3 text-amber-600 shrink-0" />
            <span>Disburse 90% Compensation</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setHasStay(false);
              setLegalCases(0);
            }}
            className="px-3 py-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center"
          >
            <Scale className="w-3 h-3 text-emerald-600 shrink-0" />
            <span>Resolve Court Injunctions</span>
          </button>
          <button
            type="button"
            onClick={() => setForestStage('Stage 2 Approved')}
            className="px-3 py-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center"
          >
            <TreePine className="w-3 h-3 text-emerald-700 shrink-0" />
            <span>Clear Forest Approvals</span>
          </button>
          <button
            type="button"
            onClick={() => setDocCount(0)}
            className="px-3 py-2 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center"
          >
            <FileText className="w-3 h-3 text-blue-600 shrink-0" />
            <span>Clear Mutation Backlog</span>
          </button>
        </div>
      </div>

      {/* Big Headline Metric if Simulation was run */}
      {result && (
        <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-4 sm:p-5 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-fadeIn">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>Counterfactual Delay Projection</span>
            </span>
            <div className="text-lg sm:text-2xl font-extrabold text-emerald-950 tracking-tight">
              Projected Delay: +{activeProject.delayVarianceMonths} mo → +{result.simulatedRisk.delayVarianceMonths} mo ({delayDelta >= 0 ? `-${delayDelta} mo recovery` : `+${Math.abs(delayDelta)} mo delay`})
            </div>
            <p className="text-xs text-emerald-900/90 font-medium">
              Risk score drops from {currentRisk}% ({activeProject.riskLevel}) down to {result.simulatedRisk.delayProbability}% ({result.simulatedRisk.riskLevel}).
            </p>
          </div>

          <button
            onClick={handleExportBriefing}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-2xs shrink-0 self-start sm:self-auto cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Scenario Briefing</span>
          </button>
        </div>
      )}

      {/* 2. Side-by-side: Current Baseline vs What-If Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: CURRENT BASELINE */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Baseline State
              </span>
              <h2 className="text-sm font-bold text-slate-900">CURRENT STATUS</h2>
            </div>
            <DataSourceBadge source={activeProject.source} isSynthetic={activeProject.isSynthetic} />
          </div>

          <div className="space-y-1">
            <h3 className="font-bold text-xs text-slate-900 line-clamp-2">
              {activeProject.name}
            </h3>
            <p className="text-[11px] text-slate-500 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-slate-400" />
              {activeProject.district}, {activeProject.state}
              {activeProject.highwayNumber && ` • ${activeProject.highwayNumber}`}
            </p>
          </div>

          {/* Current Risk Card */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Current Delay Risk
            </span>
            <div
              className={`text-4xl font-extrabold font-mono ${
                activeProject.riskLevel === 'HIGH'
                  ? 'text-red-700'
                  : activeProject.riskLevel === 'MEDIUM'
                  ? 'text-amber-700'
                  : 'text-emerald-700'
              }`}
            >
              {activeProject.delayProbability}%
            </div>
            <div className="pt-1 flex justify-center">
              <RiskBadge level={activeProject.riskLevel} />
            </div>
            <p className="text-[11px] text-slate-500 pt-1 font-medium">
              Statutory Variance: +{activeProject.delayVarianceMonths} months
            </p>
          </div>

          {/* Current Variables List */}
          <div className="space-y-2 pt-2 text-xs border-t border-slate-100">
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Compensation Disbursed</span>
              <span className="font-semibold text-slate-800">
                {activeProject.compensationDisbursedPercent}%
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Court Injunction</span>
              <span
                className={`font-semibold ${
                  activeProject.hasCourtStay ? 'text-red-700' : 'text-slate-700'
                }`}
              >
                {activeProject.hasCourtStay ? 'Active Stay' : 'No Stay'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Incomplete Documents</span>
              <span className="font-semibold text-slate-800">
                {activeProject.incompleteDocumentsCount} records
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500">Unresolved Legal Cases</span>
              <span className="font-semibold text-slate-800">
                {activeProject.unresolvedLegalCases}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Forest Clearance</span>
              <span className="font-semibold text-slate-800">
                {activeProject.forestClearanceStage}
              </span>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: CONTROLS & COMPARISON */}
        <div className="lg:col-span-8 space-y-6">
          {/* Controls Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-5">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900">
                  Simulation Parameters
                </span>
                <h2 className="text-sm font-bold text-slate-900">WHAT-IF: Adjust Statutory Conditions</h2>
              </div>
              <button
                onClick={handleReset}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset to Baseline</span>
              </button>
            </div>

            {/* Parameter Sliders & Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Compensation Slider + Number Input */}
              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-800">
                  <span className="flex items-center gap-1">
                    <IndianRupee className="w-3.5 h-3.5 text-slate-500" />
                    Compensation Disbursed
                  </span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={compensation}
                      onChange={e => setCompensation(Math.min(100, Math.max(0, Number(e.target.value))))}
                      className="w-14 text-right font-mono text-xs font-bold text-blue-900 bg-white border border-slate-300 rounded px-1.5 py-0.5"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={compensation}
                  onChange={e => setCompensation(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Current: {activeProject.compensationDisbursedPercent}%</span>
                  <span>Target: 100%</span>
                </div>
              </div>

              {/* Court Stay Injunction Toggle */}
              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-800">
                  <span className="flex items-center gap-1">
                    <Scale className="w-3.5 h-3.5 text-slate-500" />
                    Court Stay Injunction
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      hasStay ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {hasStay ? 'Stay Active' : 'Stay Vacated'}
                  </span>
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setHasStay(false)}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                      !hasStay
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Vacate Stay (Interlocutory)
                  </button>
                  <button
                    type="button"
                    onClick={() => setHasStay(true)}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                      hasStay
                        ? 'bg-red-700 text-white border-red-700 shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Stay Active
                  </button>
                </div>
              </div>

              {/* Incomplete Documents Slider + Input */}
              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-800">
                  <span className="flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    Pending Mutation Records
                  </span>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="0"
                      max="50"
                      value={docCount}
                      onChange={e => setDocCount(Math.max(0, Number(e.target.value)))}
                      className="w-14 text-right font-mono text-xs font-bold text-slate-900 bg-white border border-slate-300 rounded px-1.5 py-0.5"
                    />
                    <span className="text-[10px] text-slate-500">cases</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  value={docCount}
                  onChange={e => setDocCount(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0 (All Cleared)</span>
                  <span>Baseline: {activeProject.incompleteDocumentsCount}</span>
                </div>
              </div>

              {/* Forest Clearance Dropdown */}
              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2">
                <div className="text-xs font-semibold text-slate-800 flex items-center gap-1">
                  <TreePine className="w-3.5 h-3.5 text-slate-500" />
                  <span>Forest Diversion Clearance Stage</span>
                </div>
                <select
                  value={forestStage}
                  onChange={e => setForestStage(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md font-medium text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500 cursor-pointer"
                >
                  <option value="Not Required">Not Required (Zero Forest Area)</option>
                  <option value="Stage 1 Approved">Stage 1 Approved (In-Principle)</option>
                  <option value="Stage 2 Pending">Stage 2 Pending (Diversion in process)</option>
                  <option value="Stage 2 Approved">Stage 2 Approved (Full Clearance)</option>
                </select>
                <p className="text-[10px] text-slate-400">
                  Parivesh MoEFCC statutory clearance stage
                </p>
              </div>
            </div>

            {/* Run Simulation Button */}
            <div className="pt-2 flex justify-end">
              <button
                onClick={handleRunSimulation}
                disabled={loading}
                className="px-6 py-2.5 bg-blue-900 hover:bg-blue-950 text-white rounded-lg text-xs font-bold transition-all shadow-2xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Play className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : 'fill-white'}`} />
                <span>{loading ? 'Running ML Engine...' : 'Run Simulation'}</span>
              </button>
            </div>
          </div>

          {/* SIMULATION RESULT CARD */}
          {result && (
            <div className="bg-white border border-blue-200 rounded-xl p-5 shadow-2xs space-y-4 animate-fadeIn">
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                    Calculated Counterfactual
                  </span>
                  <h3 className="text-base font-bold text-slate-900">SIMULATION RESULT</h3>
                </div>
                <RiskBadge level={result.simulatedRisk.riskLevel} />
              </div>

              {/* Side-by-side metric comparison (Section 16) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">CURRENT BASELINE</span>
                  <div className="text-2xl font-extrabold text-slate-800 font-mono mt-0.5">
                    {result.currentRisk.delayProbability}%
                  </div>
                  <div className="text-xs text-slate-600 font-medium">
                    Risk: {result.currentRisk.riskLevel}
                  </div>
                  <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                    Compensation: {activeProject.compensationDisbursedPercent}%
                  </div>
                </div>

                <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900">SCENARIO INPUTS</span>
                  <div className="text-2xl font-extrabold text-blue-950 font-mono mt-0.5">
                    {compensation}%
                  </div>
                  <div className="text-xs text-blue-800 font-medium">
                    Simulated Compensation
                  </div>
                  <div className="text-[11px] text-blue-700 pt-1 border-t border-blue-200/60">
                    Stay: {hasStay ? 'Active' : 'Vacated'} • Forest: {forestStage}
                  </div>
                </div>

                <div
                  className={`p-3.5 rounded-xl border space-y-1 ${
                    riskDelta <= 0
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                      : 'bg-red-50 border-red-200 text-red-950'
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider">SIMULATION RESULT</span>
                  <div className="text-2xl font-extrabold font-mono mt-0.5 flex items-center justify-center gap-1">
                    {riskDelta <= 0 ? (
                      <TrendingDown className="w-5 h-5 text-emerald-700" />
                    ) : (
                      <TrendingUp className="w-5 h-5 text-red-700" />
                    )}
                    <span>{simRisk ? simRisk.delayProbability : 0}%</span>
                  </div>
                  <div className="text-xs font-bold">
                    Change: {riskDelta > 0 ? `+${riskDelta}` : riskDelta} percentage points
                  </div>
                  <div className="text-[11px] pt-1 border-t border-emerald-200/60">
                    Schedule: {activeProject.delayVarianceMonths} mo → {simRisk ? (simRisk.delayVarianceMonths ?? 0) : 0} mo
                  </div>
                </div>
              </div>

              {/* Drivers & Insights */}
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1 text-xs">
                <span className="font-semibold text-slate-800">Key Policy Drivers:</span>
                <p className="text-slate-600 leading-relaxed">
                  {result.impactSummary ||
                    (riskDelta < -15
                      ? 'Substantial acceleration achieved through statutory disbursement targets and resolution of interlocutory court stays.'
                      : riskDelta < 0
                      ? 'Moderate improvement. Further acceleration requires mutation completion and Stage-2 forest divergence approval.'
                      : 'Unchanged or elevated risk profile. Prioritize legal and financial compliance.')}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
