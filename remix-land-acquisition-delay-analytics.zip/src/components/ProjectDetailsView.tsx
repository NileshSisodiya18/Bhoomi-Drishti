import React, { useState, useEffect } from 'react';
import { Project, WhatIfResponse, ProjectHistoryItem } from '../types.ts';
import { RiskBadge, DataSourceBadge, StageStatusBadge } from './StatusBadge.tsx';
import { api } from '../services/apiClient.ts';
import { ModelExplanationModal } from './ModelExplanationModal.tsx';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import {
  ArrowLeft,
  MapPin,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  SlidersHorizontal,
  Landmark,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  FileText,
  ExternalLink,
  History,
  Scale,
  Cpu,
  Layers,
  Sparkles,
  TreePine,
  IndianRupee,
  RotateCcw,
  Play,
  Check,
  AlertTriangle
} from 'lucide-react';

interface ProjectDetailsViewProps {
  project: Project;
  onBack: () => void;
  onNavigateToWhatIf?: (projectId: string) => void;
}

export const ProjectDetailsView: React.FC<ProjectDetailsViewProps> = ({
  project,
  onBack,
  onNavigateToWhatIf
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'timeline' | 'risk' | 'whatif'>('overview');
  const [modelModalOpen, setModelModalOpen] = useState(false);
  const [history, setHistory] = useState<ProjectHistoryItem[]>([]);
  const [dataHubProject, setDataHubProject] = useState<any>(null);

  // Embedded What-If state for this specific project
  const [simCompensation, setSimCompensation] = useState<number>(project.compensationDisbursedPercent);
  const [simHasStay, setSimHasStay] = useState<boolean>(project.hasCourtStay);
  const [simDocCount, setSimDocCount] = useState<number>(project.incompleteDocumentsCount);
  const [simLegalCases, setSimLegalCases] = useState<number>(project.unresolvedLegalCases);
  const [simForestStage, setSimForestStage] = useState<string>(project.forestClearanceStage);
  const [simLoading, setSimLoading] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<WhatIfResponse | null>(null);

  // Progressive Disclosure states for Risk & Explainability (Section 14 & 15)
  const [showRiskFactors, setShowRiskFactors] = useState<boolean>(true);
  const [expandedFactor, setExpandedFactor] = useState<number | null>(null);

  const sourcePId =
    project.sourceProjectId ||
    (project.id.startsWith('BhoomiRashi_') ? project.id.replace('BhoomiRashi_', '') : project.id);

  useEffect(() => {
    api.getProjectHistory(project.id).then(setHistory).catch(() => {});
    if (sourcePId) {
      api.datahub.getProjectById(sourcePId).then(setDataHubProject).catch(() => {});
    }
  }, [project.id, sourcePId]);

  // Derived land metrics
  const totalRequired = project.totalLandRequiredHa || 200;
  const acquiredTillNow = project.landAcquiredHa || 0;
  const toBeAcquired = project.pendingLandHa || Math.max(0, totalRequired - acquiredTillNow);
  const progressPct = totalRequired > 0 ? Math.min(100, Math.round((acquiredTillNow / totalRequired) * 100)) : 0;

  const handleRunSimulation = async () => {
    setSimLoading(true);
    try {
      const res = await api.runWhatIf({
        projectId: project.id,
        compensationDisbursedPercent: Number(simCompensation),
        hasCourtStay: simHasStay,
        unresolvedLegalCases: Number(simLegalCases),
        incompleteDocumentsCount: Number(simDocCount),
        forestClearanceStage: simForestStage
      });
      setSimResult(res);
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setSimLoading(false);
    }
  };

  const handleResetSimulation = () => {
    setSimCompensation(project.compensationDisbursedPercent);
    setSimHasStay(project.hasCourtStay);
    setSimDocCount(project.incompleteDocumentsCount);
    setSimLegalCases(project.unresolvedLegalCases);
    setSimForestStage(project.forestClearanceStage);
    setSimResult(null);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-14">
      {/* Back Button */}
      <div>
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors py-1 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Projects Directory</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. TOP HERO BANNER                                                        */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            {/* Top ID & Badges line */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                Package ID: {sourcePId}
              </span>
              <DataSourceBadge source={project.source} isSynthetic={project.isSynthetic} />
              <StageStatusBadge status={project.stageStatus} />
              {project.highwayNumber && (
                <span className="text-xs px-2 py-0.5 rounded font-semibold bg-blue-50 text-blue-800 border border-blue-200">
                  Corridor: {project.highwayNumber}
                </span>
              )}
            </div>

            {/* Official Project Title */}
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
              {project.name}
            </h1>

            {/* Subtitle: Project Number • Location • Implementing Agency */}
            <div className="flex items-center gap-2 text-xs text-slate-600 flex-wrap font-medium">
              <span className="text-slate-900 font-semibold">
                Project No: {project.sourceProjectId ? `NI/2023/${project.sourceProjectId}` : project.id}
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {project.district}, {project.state}
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                {project.agency || 'NHAI / MoRTH'}
              </span>
            </div>
          </div>

          {/* Right Side: Last Synced & External BhoomiRashi Link */}
          <div className="text-left md:text-right shrink-0 space-y-2 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
            <div className="text-xs text-slate-500">
              <span className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                Statutory Data Synchronization
              </span>
              <span className="font-semibold text-slate-800">
                {project.lastUpdated || 'Live Hash Verified'}
              </span>
            </div>

            {project.sourceUrl && (
              <a
                href={project.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-md border border-blue-200 transition-colors"
                title="Open authentic BhoomiRashi record on MoRTH official portal"
              >
                <span>View on BhoomiRashi</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. IMMEDIATE KEY INDICATORS (Section 13 & 14)                            */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-center divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
          {/* 1. Risk & Delay Probability */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                Statutory Delay Risk
              </span>
              <RiskBadge level={project.riskLevel} />
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-3xl font-extrabold font-mono ${
                project.riskLevel === 'HIGH' ? 'text-red-700' : project.riskLevel === 'MEDIUM' ? 'text-amber-700' : 'text-emerald-700'
              }`}>
                {project.delayProbability}%
              </span>
              <span className="text-xs font-semibold text-slate-500">Probability</span>
              <InfoTooltip
                title="Delay Probability"
                content="Forecasted probability that physical possession will exceed target gazette schedule based on statutory velocity."
              />
            </div>
            <div className="text-xs font-medium text-slate-700">
              {project.riskLevel === 'HIGH'
                ? 'Immediate review recommended.'
                : project.riskLevel === 'MEDIUM'
                ? 'Moderate variance — monitoring recommended.'
                : 'Acquisition progressing on schedule.'}
            </div>
          </div>

          {/* 2. Land Acquisition Progress */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              <span>Land Progress</span>
              <span className="font-mono text-slate-700 font-bold">{progressPct}%</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold font-mono text-slate-900">{acquiredTillNow}</span>
              <span className="text-xs text-slate-400">/ {totalRequired} Ha</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  progressPct >= 75 ? 'bg-emerald-600' : progressPct >= 30 ? 'bg-blue-600' : 'bg-amber-500'
                }`}
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <span className="text-[11px] text-slate-500 block">
              {toBeAcquired} Ha pending under 3D/3G
            </span>
          </div>

          {/* 3. Estimated Delay Variance */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Forecasted Delay
            </span>
            <div className="text-2xl font-bold font-mono text-slate-800">
              +{project.delayVarianceMonths} <span className="text-xs font-normal text-slate-500">months</span>
            </div>
            <p className="text-xs text-slate-500">
              Statutory schedule variance based on User velocity
            </p>
          </div>

          {/* 4. Judicial & Environmental Status */}
          <div className="space-y-1.5 sm:pl-4 pt-3 sm:pt-0">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
              Clearance Status
            </span>
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800">
                <Scale className={`w-3.5 h-3.5 ${project.hasCourtStay ? 'text-red-600' : 'text-emerald-600'}`} />
                <span>{project.hasCourtStay ? 'Court Stay Active' : 'Clean Title / No Stays'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <TreePine className="w-3.5 h-3.5 text-slate-400" />
                <span className="truncate">{project.forestClearanceStage || 'Forest: Clear'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Explainability Toggle Button */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span className="font-semibold text-slate-800">Key Delay Factors Identified:</span>
            <span>{project.topRiskFactors?.length || 4} contributing operational factors</span>
          </div>

          <button
            onClick={() => setShowRiskFactors(!showRiskFactors)}
            className="px-3 py-1 text-xs font-semibold text-blue-900 hover:text-blue-950 bg-blue-50 hover:bg-blue-100 rounded-md border border-blue-200 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span>{showRiskFactors ? 'Hide Risk Factors ▲' : 'View Risk Factors ▼'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* EXPLAINABILITY CARD (Section 15): WHY IS THIS PROJECT HIGH RISK?           */}
      {/* ========================================================================= */}
      {showRiskFactors && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight uppercase">
                Why is this project {project.riskLevel} risk?
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Primary statutory bottlenecks causing predicted schedule slippage
              </p>
            </div>
            <span className="text-[11px] font-mono text-slate-400 font-medium">
              ML Attribution Engine
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Factor 1: Compensation Lag */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 1 ? null : 1)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <IndianRupee className="w-3.5 h-3.5 text-amber-600" />
                  1. Compensation Lag
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 1 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-amber-800">
                {100 - project.compensationDisbursedPercent}% remains undisbursed
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Only {project.compensationDisbursedPercent}% of ₹{project.compensationSanctionedCr} Cr disbursed to land owners.
              </p>
              {expandedFactor === 1 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Pending cases: {project.pendingCompensationCases || 12} awards</div>
                  <div>• Deposit balance: ₹{((project.compensationSanctionedCr || 10) * (1 - project.compensationDisbursedPercent / 100)).toFixed(2)} Cr in escrow</div>
                </div>
              )}
            </div>

            {/* Factor 2: Clearance Pending */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 2 ? null : 2)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <TreePine className="w-3.5 h-3.5 text-emerald-700" />
                  2. Clearance Pending
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 2 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-slate-800 truncate">
                {project.forestClearanceStage || 'Stage 2 approval pending'}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {project.forestLandHa || 12.4} Ha of forest land pending final handover by MoEFCC.
              </p>
              {expandedFactor === 2 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Compensatory afforestation site identified</div>
                  <div>• State advisory committee review awaited</div>
                </div>
              )}
            </div>

            {/* Factor 3: Mutation Backlog */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 3 ? null : 3)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  3. Mutation Backlog
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 3 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-slate-800">
                {project.incompleteDocumentsCount || 18} records pending
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Title deeds & revenue khata mutations pending clearance at Tehsil revenue office.
              </p>
              {expandedFactor === 3 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Revenue division: {project.district} Tehsil</div>
                  <div>• Succession certificates pending with Patwari</div>
                </div>
              )}
            </div>

            {/* Factor 4: Reference Litigation */}
            <div
              onClick={() => setExpandedFactor(expandedFactor === 4 ? null : 4)}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Scale className="w-3.5 h-3.5 text-red-600" />
                  4. Reference Litigation
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {expandedFactor === 4 ? '▲' : '▼'}
                </span>
              </div>
              <div className="text-xs font-bold text-red-800">
                {project.hasCourtStay ? 'Active Court Injunction' : `${project.unresolvedLegalCases || 4} cases pending`}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed truncate">
                {project.courtDetails || 'Section 3G compensation determination challenges pending at High Court.'}
              </p>
              {expandedFactor === 4 && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600 space-y-1">
                  <div>• Forum: High Court appellate division</div>
                  <div>• Government counsel instruction: Application for early hearing filed</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. 4-TAB EXECUTIVE NAVIGATION                                              */}
      {/* ========================================================================= */}
      <div className="border-b border-slate-200">
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-0.5">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'overview'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Overview & Breakdown
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'timeline'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Statutory Timeline (3A → 3D → 3G)
          </button>
          <button
            onClick={() => setActiveTab('risk')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'risk'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Risk & Explainability
          </button>
          <button
            onClick={() => setActiveTab('whatif')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'whatif'
                ? 'border-blue-900 text-blue-950 bg-blue-50/50 rounded-t-lg'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-blue-700" />
            <span>What-If Simulation</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW                                                           */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Project Metadata */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-600" />
                  <span>Administrative & Legal Metadata</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Jurisdictional authority and statutory act declarations</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">State & District</span>
                  <div className="font-bold text-slate-900">{project.district}, {project.state}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Corridor Alignment</span>
                  <div className="font-bold text-slate-900">{project.highwayNumber || 'National Highway'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Implementing Agency</span>
                  <div className="font-bold text-slate-900">{project.agency || 'NHAI / MoRTH'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5">
                  <span className="text-slate-400 font-medium">Statutory Act</span>
                  <div className="font-bold text-slate-900">{project.act || 'NH Act 1956'}</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-0.5 col-span-2">
                  <span className="text-slate-400 font-medium">Competent Authority</span>
                  <div className="font-bold text-slate-900">
                    Competent Authority for Land Acquisition, {project.district} Division
                  </div>
                </div>
              </div>

              {/* Judicial Stay Status */}
              <div className={`p-3 rounded-lg border text-xs ${
                project.hasCourtStay
                  ? 'bg-red-50 border-red-200 text-red-900'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <div className="flex items-center gap-1.5 font-bold">
                  <Scale className="w-3.5 h-3.5" />
                  <span>Judicial Status: {project.hasCourtStay ? 'Active Court Injunction' : 'Clean Title / No Stays'}</span>
                </div>
                <p className="mt-1 text-[11px] opacity-90">
                  {project.hasCourtStay
                    ? project.courtDetails || 'Interlocutory court order pending review at High Court registry.'
                    : 'Statutory gazette notifications have cleared limitation period without pending stays.'}
                </p>
              </div>
            </div>

            {/* Right Column: Progress & Classification Visualizer */}
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Layers className="w-4 h-4 text-slate-600" />
                  <span>Acquisition Progress & Land Classification</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Physical land handover and compensation deposit status</p>
              </div>

              {/* Progress Bar Visualizer */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-700">Land Acquired: {acquiredTillNow} / {totalRequired} Ha</span>
                  <span className="text-emerald-700 font-mono font-bold">{progressPct}%</span>
                </div>
                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full transition-all duration-500"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>

              {/* Land Breakdown Pills */}
              <div className="grid grid-cols-3 gap-2.5 text-xs pt-1">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px]">Private Land</span>
                  <div className="font-bold text-slate-900 font-mono">
                    {project.privateLandHa || (totalRequired * 0.75).toFixed(1)} Ha
                  </div>
                  <span className="text-[10px] text-slate-400">Direct User award</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px]">Government Land</span>
                  <div className="font-bold text-slate-900 font-mono">
                    {project.govtLandHa || (totalRequired * 0.15).toFixed(1)} Ha
                  </div>
                  <span className="text-[10px] text-slate-400">Inter-dept transfer</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-0.5">
                  <span className="text-slate-500 text-[11px]">Forest Land</span>
                  <div className="font-bold text-slate-900 font-mono">
                    {project.forestLandHa || (totalRequired * 0.10).toFixed(1)} Ha
                  </div>
                  <span className="text-[10px] text-slate-400">{project.forestClearanceStage}</span>
                </div>
              </div>

              {/* Financial Compensation Progress */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <IndianRupee className="w-3.5 h-3.5 text-slate-600" />
                    <span>Compensation Disbursement Status</span>
                  </span>
                  <span className="font-bold text-blue-900 font-mono">
                    {project.compensationDisbursedPercent}% Disbursed
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>Sanctioned: <strong>₹{project.compensationSanctionedCr} Cr</strong></div>
                  <div>Disbursed: <strong>₹{project.compensationDisbursedCr} Cr</strong></div>
                </div>
              </div>
            </div>
          </div>

          {/* Audit History Log if present */}
          {history.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                <History className="w-4 h-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">Audit & Revision Trail</h3>
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                {history.slice(0, 4).map((h, i) => (
                  <div key={i} className="py-2.5 flex items-center justify-between gap-4">
                    <div>
                      <span className="font-semibold text-slate-800">{h.changeSummary}</span>
                      <span className="text-slate-400 block text-[11px]">Changed by {h.changedBy || 'Live Sync Collector'}</span>
                    </div>
                    <span className="text-slate-400 text-[11px] font-mono shrink-0">
                      {new Date(h.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: STATUTORY TIMELINE                                                 */}
      {/* ========================================================================= */}
      {activeTab === 'timeline' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Vertical Statutory Acquisition Lifecycle
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sequenced milestone flow under National Highways Act 1956 & RFCTLARR Act 2013
            </p>
          </div>

          <div className="relative pl-6 space-y-8 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
            {/* Stage 1: Section 3A */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow-sm">
                <Check className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">1. Intention to Acquire (Section 3A)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Completed
                  </span>
                </div>
                <p className="text-slate-600">Gazette S.O. 412(E) published in official Gazette of India and local vernacular dailies.</p>
                <div className="text-[11px] text-slate-400 font-mono pt-1">
                  Published: {project.section3ADate || '12 Jan 2024'}
                </div>
              </div>
            </div>

            {/* Stage 2: Section 3D */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow-sm">
                <Check className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">2. Declaration of Acquisition (Section 3D)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Completed
                  </span>
                </div>
                <p className="text-slate-600">Objections heard by User; land vested absolutely in Central Government free from encumbrances.</p>
                <div className="text-[11px] text-slate-400 font-mono pt-1">
                  Published: {project.section3DDate || '08 Jul 2024 (Gazette S.O. 1892(E))'}
                </div>
              </div>
            </div>

            {/* Stage 3: Section 3G */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] shadow-sm ring-4 ring-blue-100 animate-pulse">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-blue-50/50 border border-blue-200 rounded-lg p-4 w-full text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-950 text-sm">3. Determination of Compensation (Section 3G)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800 border border-blue-300">
                    Active Stage
                  </span>
                </div>
                <p className="text-slate-700">User hearing compensation claims and determining market valuation under RFCTLARR principles.</p>
                <div className="text-[11px] text-blue-800 font-medium pt-1">
                  Active award claims: {project.pendingCompensationCases || 12} pending determination
                </div>
              </div>
            </div>

            {/* Stage 4: Compensation Deposit (Section 3H) */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center text-[10px]">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1 opacity-80">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">4. Deposit & Disbursement (Section 3H)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-300">
                    Pending Award
                  </span>
                </div>
                <p className="text-slate-600">Disbursement of approved compensation into Aadhaar-linked beneficiary bank accounts.</p>
              </div>
            </div>

            {/* Stage 5: Physical Possession (Section 3E) */}
            <div className="relative flex items-start gap-4">
              <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center text-[10px]">
                <Clock className="w-3 h-3" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 w-full text-xs space-y-1 opacity-80">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">5. Physical Possession & Right of Way (Section 3E)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-300">
                    Pending
                  </span>
                </div>
                <p className="text-slate-600">Handover of vacant land parcels to NHAI concessionaire for civil works mobilization.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: RISK & EXPLAINABILITY                                              */}
      {/* ========================================================================= */}
      {activeTab === 'risk' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  Delay Risk Assessment & Model Explainability
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Calibrated Random Forest model attributions and empirical delay drivers
                </p>
              </div>

              <button
                onClick={() => setModelModalOpen(true)}
                className="px-3 py-1.5 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>Technical Model Card ⓘ</span>
              </button>
            </div>

            {/* Top 3-5 Risk Drivers */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Top Empirical Risk Drivers (SHAP Attributions)
              </h3>
              {project.topRiskFactors && project.topRiskFactors.length > 0 ? (
                project.topRiskFactors.map((rf, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{rf.factor}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
                          HIGH SEVERITY
                        </span>
                      </div>
                      {rf.impactScore && (
                        <span className="font-mono text-slate-600 font-semibold">
                          Relative Impact: {rf.impactScore}%
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{rf.detail}</p>
                  </div>
                ))
              ) : (
                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 text-xs text-slate-600">
                  Default driver: Statutory timeline variance is driven by pending User award settlement.
                </div>
              )}
            </div>

            {/* Recommended Interventions */}
            <div className="pt-3 border-t border-slate-100 space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Recommended Priority Interventions</span>
              </h3>
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-950 flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                  <div>
                    <strong>Expedite User Disbursement:</strong> Coordinate special camp with District Collector in {project.district} to accelerate Aadhaar-linked compensation deposits beyond the current {project.compensationDisbursedPercent}% level.
                  </div>
                </div>
                {project.hasCourtStay && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-950 flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 shrink-0 mt-1.5" />
                    <div>
                      <strong>Vacate Court Injunction:</strong> Instruct government standing counsel to file application for early hearing to vacate interlocutory stay on compensation award.
                    </div>
                  </div>
                )}
                <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0 mt-1.5" />
                  <div>
                    <strong>Resolve Revenue Mutation Backlog:</strong> Depute additional Patwaris to clear {project.incompleteDocumentsCount} pending land mutation documents.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: WHAT-IF SIMULATION (EMBEDDED)                                      */}
      {/* ========================================================================= */}
      {activeTab === 'whatif' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-blue-700" />
                <span>What-If Delay Mitigation Simulator</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Simulate executive interventions on this package and forecast risk reduction in real time
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetSimulation}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Sliders</span>
              </button>
              <button
                onClick={handleRunSimulation}
                disabled={simLoading}
                className="px-4 py-1.5 text-xs font-bold text-white bg-blue-900 hover:bg-blue-950 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{simLoading ? 'Simulating...' : 'Run Simulation'}</span>
              </button>
            </div>
          </div>

          {/* Simulator Controls & Output Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left 7 cols: Controls */}
            <div className="lg:col-span-7 space-y-4">
              {/* Slider 1: Compensation Disbursed */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                    <IndianRupee className="w-3.5 h-3.5 text-slate-500" />
                    Compensation Disbursement Speed
                  </span>
                  <span className="font-bold text-slate-900 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">
                    {simCompensation}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={simCompensation}
                  onChange={e => setSimCompensation(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Current: {project.compensationDisbursedPercent}%</span>
                  <span>Target: 100% (Full Award)</span>
                </div>
              </div>

              {/* Control 2: Judicial Court Stay Toggle */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-slate-500" />
                    Active Judicial Stay / Injunction
                  </span>
                  <p className="text-[11px] text-slate-500">Toggle resolution of court stay on land acquisition</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSimHasStay(!simHasStay)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                    simHasStay ? 'bg-red-600' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                      simHasStay ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Slider 3: Incomplete Documents Backlog */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    Pending Mutation Certificates
                  </span>
                  <span className="font-bold text-slate-900 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">
                    {simDocCount} cases
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={50}
                  step={1}
                  value={simDocCount}
                  onChange={e => setSimDocCount(Number(e.target.value))}
                  className="w-full accent-blue-900 cursor-pointer"
                />
              </div>

              {/* Dropdown 4: Forest Clearance Stage */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                  <TreePine className="w-3.5 h-3.5 text-slate-500" />
                  Forest Land Clearance Stage
                </span>
                <select
                  value={simForestStage}
                  onChange={e => setSimForestStage(e.target.value)}
                  className="w-full text-xs font-medium bg-white border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Approved">Stage 2 (Approved / Diversion Complete)</option>
                  <option value="In Progress">Stage 1 (In-Principle Sanctioned)</option>
                  <option value="Pending Submission">Pending Application Submission</option>
                  <option value="Not Required">Not Required (Zero Forest Area)</option>
                </select>
              </div>
            </div>

            {/* Right 5 cols: Comparison & Outcome Card (Section 16) */}
            <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Simulation Outcome
                </h3>
                <span className="text-[10.5px] font-semibold text-slate-500 bg-slate-200/70 px-2 py-0.5 rounded">
                  Counterfactual ML
                </span>
              </div>

              {/* Compact Disclaimer (Section 16) */}
              <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200/80 text-[11px] text-amber-900 font-medium flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600 shrink-0" />
                <span>Scenario — does not modify actual project data.</span>
              </div>

              {simResult ? (() => {
                const simRisk = simResult.simulatedRisk || simResult.scenarioRisk;
                if (!simRisk) return null;
                const riskDiff = project.delayProbability - simRisk.delayProbability;
                const isImprovement = riskDiff >= 0;
                const monthsRecovered = Math.round((project.delayVarianceMonths - (simRisk.delayVarianceMonths ?? 0)) * 10) / 10;

                return (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    {/* CURRENT vs SCENARIO comparison */}
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      {/* CURRENT */}
                      <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                          CURRENT
                        </span>
                        <div className="text-slate-700">
                          Compensation: <strong className="font-mono">{project.compensationDisbursedPercent}%</strong>
                        </div>
                        <div className="text-slate-700">
                          Risk: <strong className="font-mono text-red-700">{project.delayProbability}%</strong>
                        </div>
                        <div className="text-[10px] text-slate-400 pt-0.5 font-mono">
                          +{project.delayVarianceMonths} mo variance
                        </div>
                      </div>

                      {/* SCENARIO */}
                      <div className="p-3 bg-white rounded-lg border border-blue-200 bg-blue-50/20 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-blue-700 block tracking-wider">
                          SCENARIO
                        </span>
                        <div className="text-slate-700">
                          Compensation: <strong className="font-mono text-blue-900">{simCompensation}%</strong>
                        </div>
                        <div className="text-slate-700">
                          Court Stay: <strong className="font-mono">{simHasStay ? 'Active' : 'Vacated'}</strong>
                        </div>
                        <div className="text-[10px] text-blue-700 pt-0.5 font-mono">
                          {simDocCount} pending docs
                        </div>
                      </div>
                    </div>

                    {/* RESULT */}
                    <div className={`p-4 rounded-xl space-y-2 border ${
                      isImprovement ? 'bg-emerald-50 border-emerald-300' : 'bg-red-50 border-red-300'
                    }`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-[11px] font-bold uppercase tracking-wider ${
                          isImprovement ? 'text-emerald-900' : 'text-red-900'
                        }`}>
                          RESULT
                        </span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded border font-mono ${
                          isImprovement
                            ? 'text-emerald-700 bg-white border-emerald-200'
                            : 'text-red-700 bg-white border-red-200'
                        }`}>
                          Change: {isImprovement ? `-${riskDiff}` : `+${Math.abs(riskDiff)}`} percentage points
                        </span>
                      </div>

                      <div className="flex items-baseline gap-2">
                        <span className={`text-3xl font-extrabold font-mono ${
                          isImprovement ? 'text-emerald-700' : 'text-red-700'
                        }`}>
                          {simRisk.delayProbability}%
                        </span>
                        <span className={`text-xs font-semibold ${
                          isImprovement ? 'text-emerald-800' : 'text-red-800'
                        }`}>
                          Forecasted Delay Risk
                        </span>
                      </div>

                      <p className={`text-[11px] leading-relaxed pt-1 border-t ${
                        isImprovement ? 'text-emerald-900 border-emerald-200/80' : 'text-red-900 border-red-200/80'
                      }`}>
                        {simResult.impactSummary ||
                          (monthsRecovered >= 0
                            ? `Interventions would recover approx ${monthsRecovered} months and de-escalate this project.`
                            : `Adverse scenario would increase estimated delay by approx ${Math.abs(monthsRecovered)} months.`)}
                      </p>
                    </div>
                  </div>
                );
              })() : (
                <div className="py-10 text-center space-y-2 text-slate-400 text-xs">
                  <SlidersHorizontal className="w-8 h-8 mx-auto text-slate-300" />
                  <p className="font-medium text-slate-600">Adjust the parameters on the left and click "Run Simulation".</p>
                  <p className="text-[11px]">The ML decision engine will compute the counterfactual delay curve.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ML Model Explanation Modal */}
      <ModelExplanationModal
        isOpen={modelModalOpen}
        onClose={() => setModelModalOpen(false)}
        project={project}
      />
    </div>
  );
};
