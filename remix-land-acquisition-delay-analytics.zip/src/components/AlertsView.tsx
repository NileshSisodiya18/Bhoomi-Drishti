import React, { useState } from 'react';
import { AlertItem } from '../types.ts';
import {
  AlertTriangle,
  Clock,
  CheckCircle2,
  ArrowRight,
  MapPin,
  CheckCheck,
  Download,
  ShieldAlert,
  SlidersHorizontal,
  Bell,
  Filter
} from 'lucide-react';

interface AlertsViewProps {
  alerts: AlertItem[];
  onSelectProject: (projectId: string) => void;
  onAcknowledge: (alertId: string) => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  alerts,
  onSelectProject,
  onAcknowledge
}) => {
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');

  const highCount = alerts.filter(
    a => a.type.toLowerCase().includes('critical') || a.type.toLowerCase().includes('stay') || a.type.toLowerCase().includes('court') || a.status === 'New'
  ).length;
  const mediumCount = alerts.filter(
    a => (a.type.toLowerCase().includes('compensation') || a.type.toLowerCase().includes('delay') || a.type.toLowerCase().includes('variance')) &&
      !a.type.toLowerCase().includes('court') && !a.type.toLowerCase().includes('stay')
  ).length;
  const lowCount = Math.max(0, alerts.length - highCount - mediumCount);

  const filteredAlerts = alerts.filter(a => {
    if (priorityFilter === 'ALL') return true;
    const isHigh = a.type.toLowerCase().includes('critical') || a.type.toLowerCase().includes('stay') || a.type.toLowerCase().includes('court') || a.status === 'New';
    const isMedium = (a.type.toLowerCase().includes('compensation') || a.type.toLowerCase().includes('delay') || a.type.toLowerCase().includes('variance')) &&
      !a.type.toLowerCase().includes('court') && !a.type.toLowerCase().includes('stay');

    if (priorityFilter === 'HIGH') return isHigh;
    if (priorityFilter === 'MEDIUM') return isMedium;
    if (priorityFilter === 'LOW') return !isHigh && !isMedium;
    return true;
  });

  const newAlertsCount = alerts.filter(a => a.status === 'New').length;

  const handleAcknowledgeAll = () => {
    alerts.filter(a => a.status === 'New').forEach(a => onAcknowledge(a.id));
  };

  const handleExportBriefing = () => {
    const headers = 'ID,Type,Project,Location,Reason,Status,Timestamp\n';
    const rows = filteredAlerts
      .map(
        a =>
          `"${a.id}","${a.type}","${a.projectName}","${a.location}","${a.reason.replace(/"/g, '""')}","${a.status}","${a.timestamp}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `bhoomidrishti-alerts-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header with Executive Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-red-700" />
            <span>Statutory Alerts & Escalations</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Real-time notifications of legal injunctions, disbursement stagnations, and milestone variances
          </p>
        </div>

        {/* Batch Operations */}
        <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
          {newAlertsCount > 0 && (
            <button
              onClick={handleAcknowledgeAll}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold tracking-wide transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5 text-slate-600" />
              <span>Mark All Acknowledged ({newAlertsCount})</span>
            </button>
          )}

          <button
            onClick={handleExportBriefing}
            className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold tracking-wide transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Priority Navigation Tabs (Section 18: [All (8)] [High (3)] [Medium (3)] [Low (2)]) */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto">
        <button
          onClick={() => setPriorityFilter('ALL')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            priorityFilter === 'ALL'
              ? 'bg-blue-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          All ({alerts.length})
        </button>

        <button
          onClick={() => setPriorityFilter('HIGH')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            priorityFilter === 'HIGH'
              ? 'bg-red-700 text-white'
              : 'text-red-700 hover:bg-red-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-red-500" />
          <span>High ({highCount})</span>
        </button>

        <button
          onClick={() => setPriorityFilter('MEDIUM')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            priorityFilter === 'MEDIUM'
              ? 'bg-amber-600 text-white'
              : 'text-amber-800 hover:bg-amber-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-amber-500" />
          <span>Medium ({mediumCount})</span>
        </button>

        <button
          onClick={() => setPriorityFilter('LOW')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            priorityFilter === 'LOW'
              ? 'bg-slate-800 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <span>Low ({lowCount})</span>
        </button>
      </div>

      {/* Alert Cards List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-500">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-600 mb-2" />
            <p className="text-sm font-semibold text-slate-800">No active escalations in this filter.</p>
            <p className="text-xs text-slate-500 mt-0.5">All monitored statutory parameters are within target boundaries.</p>
          </div>
        ) : (
          filteredAlerts.map(alert => {
            const isCritical =
              alert.type.toLowerCase().includes('stay') ||
              alert.type.toLowerCase().includes('court') ||
              alert.type.toLowerCase().includes('critical') ||
              alert.status === 'New';

            // Determine Section tag
            const sectionTag = alert.reason.includes('3G') || alert.reason.includes('disbursement') || alert.reason.includes('Compensation')
              ? 'Section 3G'
              : alert.reason.includes('3D')
              ? 'Section 3D'
              : alert.reason.includes('3A')
              ? 'Section 3A'
              : alert.reason.includes('Forest')
              ? 'Stage 2 Clearance'
              : 'Statutory Review';

            return (
              <div
                key={alert.id}
                className={`bg-white border rounded-xl p-5 shadow-2xs transition-all ${
                  alert.status === 'New'
                    ? 'border-red-200 ring-1 ring-red-100/80 bg-linear-to-r from-red-50/20 to-white'
                    : 'border-slate-200 opacity-90'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    {/* Severity Indicator Icon */}
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                        isCritical
                          ? 'bg-red-100 text-red-700 ring-2 ring-red-200'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>

                    <div className="space-y-1.5">
                      {/* Project Name and Section tag */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-slate-900">
                          {alert.projectName}
                        </span>
                        <span className="text-xs text-slate-300">•</span>
                        <span className="px-2 py-0.5 text-[11px] font-bold bg-slate-100 text-slate-700 rounded border border-slate-200">
                          {sectionTag}
                        </span>
                        <span className="text-xs text-slate-300">•</span>
                        <span className="text-xs text-slate-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {alert.location}
                        </span>
                      </div>

                      {/* Issue Description */}
                      <p className="text-xs text-slate-800 leading-relaxed font-medium">
                        {alert.reason}
                      </p>

                      {/* Recommended Intervention */}
                      <div className="bg-emerald-50/80 border border-emerald-200 p-2.5 rounded-lg text-xs text-emerald-950">
                        <strong>Actionable Guidance:</strong> {alert.recommendedAction}
                      </div>

                      {/* Trigger & Timestamp Footer */}
                      <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1 flex-wrap">
                        <span className="flex items-center gap-1 text-slate-500 font-medium">
                          <Clock className="w-3 h-3" />
                          {alert.timestamp}
                        </span>
                        <span className="text-slate-300">•</span>
                        <span>
                          Risk Shift: <strong className="text-red-700 font-semibold">{alert.riskChange}</strong>
                        </span>
                        <span className="text-slate-300">•</span>
                        <span className="capitalize">
                          Status:{' '}
                          <strong className={alert.status === 'New' ? 'text-red-700 font-bold' : 'text-slate-700'}>
                            {alert.status}
                          </strong>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Actions (Section 18: [Open Project] [Mark Acknowledged]) */}
                  <div className="flex md:flex-col items-center md:items-end gap-2 shrink-0 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
                    <button
                      onClick={() => onSelectProject(alert.projectId)}
                      className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-950 text-white rounded-lg text-xs font-bold tracking-wide transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                    >
                      <span>Open Project</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>

                    {alert.status === 'New' && (
                      <button
                        onClick={() => onAcknowledge(alert.id)}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                      >
                        Mark Acknowledged
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
