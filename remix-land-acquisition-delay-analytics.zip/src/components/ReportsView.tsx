import React, { useState } from 'react';
import { Project, DashboardSummary } from '../types.ts';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import { GovernmentEmblem } from './common/GovernmentEmblem.tsx';
import {
  FileText,
  Download,
  Printer,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Building2,
  Calendar,
  Layers,
  ChevronRight,
  Search,
  ExternalLink,
  Scale,
  Sparkles,
  Info
} from 'lucide-react';

interface ReportsViewProps {
  projects: Project[];
  summary: DashboardSummary | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ projects, summary }) => {
  const [activeTab, setActiveTab] = useState<'project-dossier' | 'national-digest' | 'statutory-audit'>('project-dossier');
  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    projects.find(p => p.riskLevel === 'HIGH')?.id || projects[0]?.id || ''
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [showAppendix, setShowAppendix] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const activeProject = projects.find(p => p.id === selectedProjectId) || projects[0] || null;

  // Filter project list for the selector
  const selectableProjects = projects.filter(p => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      p.name.toLowerCase().includes(q) ||
      p.district.toLowerCase().includes(q) ||
      p.state.toLowerCase().includes(q) ||
      p.id.toLowerCase().includes(q)
    );
  });

  const [printStatus, setPrintStatus] = useState<{ message: string; url?: string } | null>(null);

  const generatePrintDocument = () => {
    const printableElement =
      document.querySelector('.printable-dossier') ||
      document.querySelector('.printable-digest') ||
      document.querySelector('main');

    if (!printableElement) return null;

    // Collect all stylesheets and style rules from current document
    const collectedStyles: string[] = [];
    document.querySelectorAll('style').forEach(st => {
      if (st.textContent) {
        collectedStyles.push(st.outerHTML);
      }
    });

    document.querySelectorAll('link[rel="stylesheet"]').forEach(lk => {
      collectedStyles.push(lk.outerHTML);
    });

    const docTitle = activeProject
      ? `BhoomiDrishti_Official_Dossier_${activeProject.sourceProjectId || activeProject.id}`
      : 'BhoomiDrishti_National_Pipeline_Digest';

    return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>${docTitle}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    ${collectedStyles.join('\n')}
    <style>
      @page {
        size: A4 portrait;
        margin: 10mm 12mm 12mm 12mm;
      }
      *, *::before, *::after {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        box-sizing: border-box;
      }
      html, body {
        background: #f8fafc;
        color: #0f172a;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        margin: 0;
        padding: 0;
        -webkit-font-smoothing: antialiased;
      }
      .print-bar {
        position: sticky;
        top: 0;
        z-index: 1000;
        background: #0f2027;
        color: #ffffff;
        padding: 12px 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 2px solid #c5a059;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      }
      .print-bar-btn {
        background: #ffffff;
        color: #0f172a;
        border: none;
        padding: 8px 18px;
        border-radius: 6px;
        font-weight: 700;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        transition: background 0.15s;
      }
      .print-bar-btn:hover {
        background: #f1f5f9;
      }
      .print-bar-close {
        background: rgba(255,255,255,0.15);
        color: #ffffff;
        border: 1px solid rgba(255,255,255,0.3);
        padding: 8px 14px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
      }
      .print-bar-close:hover {
        background: rgba(255,255,255,0.25);
      }
      .print-content-wrapper {
        max-width: 960px;
        margin: 24px auto;
        padding: 0 16px;
      }
      @media print {
        body {
          background: #ffffff !important;
          padding: 0 !important;
        }
        .no-print, .print-bar {
          display: none !important;
        }
        .print-content-wrapper {
          max-width: 100% !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        .printable-dossier, .printable-digest {
          border: 1px solid #cbd5e1 !important;
          box-shadow: none !important;
          border-radius: 0 !important;
          padding: 0 !important;
        }
        table {
          width: 100% !important;
          border-collapse: collapse !important;
        }
        tr, .print-avoid-break {
          break-inside: avoid !important;
          page-break-inside: avoid !important;
        }
        thead {
          display: table-header-group !important;
        }
      }
    </style>
  </head>
  <body>
    <div class="print-bar no-print">
      <div style="display: flex; align-items: center; gap: 12px;">
        <span style="font-weight: 800; font-size: 15px; letter-spacing: 0.05em; color: #ffffff;">BHOOMIDRISHTI</span>
        <span style="font-size: 13px; color: #cbd5e1;">Official Statutory Decision Support Report</span>
      </div>
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 11px; color: #94a3b8; margin-right: 8px;">Select "Save as PDF" in destination dropdown to save</span>
        <button onclick="window.print()" class="print-bar-btn">
          🖨️ Print / Save as PDF
        </button>
        <button onclick="window.close()" class="print-bar-close">
          ✕ Close
        </button>
      </div>
    </div>
    <div class="print-content-wrapper">
      ${printableElement.outerHTML}
    </div>
    <script>
      window.addEventListener('load', function() {
        setTimeout(function() {
          try {
            window.focus();
            window.print();
          } catch(e) {
            console.warn('Direct print modal error:', e);
          }
        }, 400);
      });
    </script>
  </body>
</html>`;
  };

  const handlePrint = () => {
    // Check if running inside an iframe (like AI Studio preview)
    const inIframe = (() => {
      try {
        return window.self !== window.top;
      } catch (e) {
        return true;
      }
    })();

    const printHtml = generatePrintDocument();

    if (inIframe && printHtml) {
      // In sandboxed iframe, window.print() is blocked by browser policy without allow-modals.
      // Opening the dedicated printable document in a top-level tab unlocks native window.print() and Save as PDF.
      const blob = new Blob([printHtml], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      const printWindow = window.open(blobUrl, '_blank');

      if (printWindow) {
        setPrintStatus({
          message: 'Official report opened in printable tab. The print dialog will open automatically.',
          url: blobUrl
        });
      } else {
        // Popup was blocked by browser
        setPrintStatus({
          message: 'Popups blocked by browser. Click the button to open printable report & Save as PDF:',
          url: blobUrl
        });
      }
    } else {
      // Standalone tab or top-level window
      try {
        window.focus();
        window.print();
      } catch (err) {
        console.warn('Direct window.print() failed, trying printable window fallback:', err);
        if (printHtml) {
          const blob = new Blob([printHtml], { type: 'text/html;charset=utf-8' });
          const blobUrl = URL.createObjectURL(blob);
          const printWindow = window.open(blobUrl, '_blank');
          if (!printWindow) {
            setPrintStatus({
              message: 'Click to open printable report and Save as PDF:',
              url: blobUrl
            });
          }
        }
      }
    }
  };

  const handleDownloadDossier = (project: Project) => {
    const generatedDate = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'full',
      timeStyle: 'medium'
    });

    const docContent = `================================================================================
GOVERNMENT OF INDIA • MINISTRY OF ROAD TRANSPORT & HIGHWAYS
BHOOMIDRISHTI — LAND ACQUISITION MONITORING & DELAY PREDICTION SYSTEM
OFFICIAL STATUTORY PROJECT RISK REPORT
================================================================================

DOCUMENT CLASSIFICATION: OFFICIAL DECISION SUPPORT — FOR ADMINISTRATIVE USE ONLY
GENERATED AT: ${generatedDate} IST
PROJECT IDENTIFIER: ${project.sourceProjectId || project.id}
PROJECT NAME: ${project.name}
CORRIDOR / HIGHWAY: ${project.highwayNumber || 'National Corridor'}
JURISDICTION: ${project.district} District, ${project.state} (Taluk/Tehsil: ${project.talukOrTehsil})
PRIMARY DATA SOURCE: ${project.source || 'BhoomiRashi (NH Act 1956)'}
GOVERNING STATUTE: ${project.act || 'National Highways Act 1956'}

--------------------------------------------------------------------------------
EXECUTIVE SUMMARY
--------------------------------------------------------------------------------
* Predicted Delay Probability: ${project.delayProbability}%
* Risk Classification: ${project.riskLevel} RISK
* Land Acquisition Progress: ${project.totalLandRequiredHa > 0 ? Math.round((project.landAcquiredHa / project.totalLandRequiredHa) * 100) : 0}% (${project.landAcquiredHa.toFixed(2)} Ha acquired of ${project.totalLandRequiredHa.toFixed(2)} Ha required)
* Current Statutory Stage: ${project.currentStage} (${project.stageStatus})
* Key Statutory Status: ${project.hasCourtStay ? 'CRITICAL — Court injunction currently in effect' : project.stageStatus}

Executive Finding:
The system predicts a ${project.riskLevel.toLowerCase()} probability of execution delay for this package based on identified statutory and acquisition bottlenecks (${project.mainIssue}). Administrative intervention by the Competent Authority for Land Acquisition (User) is advised to align field activities with the target commissioning schedule.

--------------------------------------------------------------------------------
1. PROJECT OVERVIEW
--------------------------------------------------------------------------------
Project Name: ${project.name}
Package Identifier: ${project.sourceProjectId || project.id}
Sector: ${project.sector}
Implementing Agency: ${project.agency || 'NHAI / MoRTH'}
State / Union Territory: ${project.state}
District: ${project.district}
Taluk / Tehsil: ${project.talukOrTehsil}
Geographic Coordinates: ${project.coordinates?.lat?.toFixed(4) || 'N/A'}°N, ${project.coordinates?.lng?.toFixed(4) || 'N/A'}°E
Total Land Requirement: ${project.totalLandRequiredHa.toFixed(2)} Hectares
Land Acquired to Date: ${project.landAcquiredHa.toFixed(2)} Hectares
Acquisition Completion: ${project.totalLandRequiredHa > 0 ? ((project.landAcquiredHa / project.totalLandRequiredHa) * 100).toFixed(1) : 0}%
Current Statutory Stage: ${project.currentStage}

--------------------------------------------------------------------------------
2. RISK ASSESSMENT
--------------------------------------------------------------------------------
Predicted Risk Score: ${project.delayProbability}%
Risk Classification Tier: ${project.riskLevel} RISK
Assessment Model: Calibrated Random Forest Decision Ensemble (100 Trees)
Model Basis: 1,240 historical linear infrastructure acquisition executions
Primary Vulnerability: ${project.mainIssue}

--------------------------------------------------------------------------------
3. KEY DELAY DRIVERS
--------------------------------------------------------------------------------
${project.topRiskFactors && project.topRiskFactors.length > 0
  ? project.topRiskFactors.map((f, i) => `Driver ${i + 1}: ${f.factor}
   Impact Level: ${f.impactLevel || 'High'} Impact
   Statutory Status: ${f.direction || 'Active Concern'}
   Details: ${f.detail}`).join('\n\n')
  : `Driver 1: ${project.mainIssue}\n   Impact Level: High Impact\n   Details: Identified as primary impediment during statutory inspection.`
}

--------------------------------------------------------------------------------
4. ACQUISITION PROGRESS & LAND CLASSIFICATION
--------------------------------------------------------------------------------
Total Required Land:        ${project.totalLandRequiredHa.toFixed(2)} Ha (100.0%)
Government / RoW Land:      ${project.govtLandHa.toFixed(2)} Ha
Forest Land:                ${project.forestLandHa.toFixed(2)} Ha (${project.forestClearanceStage})
Private Land Required:      ${project.privateLandHa.toFixed(2)} Ha
Total Land Acquired:        ${project.landAcquiredHa.toFixed(2)} Ha
Balance Pending Land:       ${project.pendingLandHa.toFixed(2)} Ha

--------------------------------------------------------------------------------
5. STATUTORY & LEGAL STATUS
--------------------------------------------------------------------------------
* Section 3A / 3a (Preliminary Intent): Completed
* Section 3D (Acquisition Declaration): ${project.currentStage === 'Possession' || project.currentStage === 'Compensation' ? 'Gazetted' : 'In Progress'}
* Compensation Sanctioned: Rs. ${project.compensationSanctionedCr.toFixed(2)} Crores
* Compensation Disbursed:  Rs. ${project.compensationDisbursedCr.toFixed(2)} Crores (${project.compensationDisbursedPercent}%)
* Pending Compensation Claims: ${project.pendingCompensationCases} beneficiary cases
* Judicial Proceedings: ${project.unresolvedLegalCases} unresolved cases
* Court Injunction / Stay: ${project.hasCourtStay ? `ACTIVE — ${project.courtDetails || 'High Court interim injunction'}` : 'No active stay order'}
* Forest Clearance Status: ${project.forestClearanceStage}
* Missing Mutation / Title Deeds: ${project.incompleteDocumentsCount} records pending

--------------------------------------------------------------------------------
6. RECOMMENDED ADMINISTRATIVE ACTIONS
--------------------------------------------------------------------------------
${project.recommendedActions && project.recommendedActions.length > 0
  ? project.recommendedActions.map((act, i) => `Priority ${i + 1}: ${act}`).join('\n')
  : `Priority 1: Convene bilateral coordination with Competent Authority for Land Acquisition (User).\nPriority 2: Accelerate Section 3G compensation disbursement to verify title accounts.\nPriority 3: Fast-track Stage-2 forest compliance with District Forest Office.`}

--------------------------------------------------------------------------------
7. STATUTORY MILESTONE TIMELINE
--------------------------------------------------------------------------------
${project.stages.map(s => `* Stage: ${s.stage} | Status: ${s.status} | Progress: ${s.progressPercent}% ${s.completedDate ? `| Date: ${s.completedDate}` : ''}`).join('\n')}

--------------------------------------------------------------------------------
8. DATA PROVENANCE & VERIFICATION
--------------------------------------------------------------------------------
Authoritative Source: ${project.source || 'BhoomiRashi Public Portal (MoRTH)'}
Synchronization Status: Synchronized with Official Gazette
Record Cryptographic Hash: SHA-256 (Canonical Field Normalization)
Last Synchronized: ${project.lastUpdated || 'Current'}

--------------------------------------------------------------------------------
9. METHODOLOGY & TECHNICAL APPENDIX
--------------------------------------------------------------------------------
This report was compiled by BHOOMIDRISHTI, an automated decision-support platform
for linear highway acquisition monitoring. Predictions are calculated using
calibrated supervised learning models cross-referenced against statutory milestones
stipulated under the National Highways Act 1956.
================================================================================
`;

    const blob = new Blob([docContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `STATUTORY_REPORT_${project.sourceProjectId || project.id}_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadSuccess(project.id);
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  const handleDownloadNationalDigest = () => {
    const csvHeaders = [
      'PackageID',
      'ProjectName',
      'Highway',
      'State',
      'District',
      'RiskLevel',
      'DelayProbabilityPct',
      'TotalLandRequiredHa',
      'LandAcquiredHa',
      'LandProgressPct',
      'CompensationDisbursedPct',
      'CourtStay',
      'MainIssue',
      'Stage'
    ];

    const rows = projects.map(p => [
      `"${p.sourceProjectId || p.id}"`,
      `"${p.name.replace(/"/g, '""')}"`,
      `"${p.highwayNumber || ''}"`,
      `"${p.state}"`,
      `"${p.district}"`,
      p.riskLevel,
      p.delayProbability,
      p.totalLandRequiredHa,
      p.landAcquiredHa,
      p.totalLandRequiredHa > 0 ? Math.round((p.landAcquiredHa / p.totalLandRequiredHa) * 100) : 0,
      p.compensationDisbursedPercent,
      p.hasCourtStay ? 'YES' : 'NO',
      `"${p.mainIssue.replace(/"/g, '""')}"`,
      `"${p.currentStage}"`
    ]);

    const content = [csvHeaders.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BHOOMIDRISHTI_NATIONAL_PIPELINE_DIGEST_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-4 no-print">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight">
              Statutory Project Risk Reports
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-900 border border-blue-200 font-semibold">
              Official Decision Support
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Standardized executive briefing documents and statutory dossiers for User, state revenue, and inter-ministerial reviews.
          </p>
        </div>

        {/* Global Action Bar */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Print or Save as PDF"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Print / Save PDF</span>
          </button>

          {activeProject && (
            <button
              onClick={() => handleDownloadDossier(activeProject)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Official Dossier</span>
            </button>
          )}
        </div>
      </div>

      {/* Print / Save PDF Notification Status */}
      {printStatus && (
        <div className="p-3 bg-blue-50 border border-blue-200 text-blue-900 rounded-lg text-xs font-medium flex items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-blue-700 shrink-0" />
            <span>{printStatus.message}</span>
          </div>
          <div className="flex items-center gap-2">
            {printStatus.url && (
              <a
                href={printStatus.url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1 bg-blue-900 text-white rounded font-bold text-xs hover:bg-blue-800 transition-colors whitespace-nowrap inline-flex items-center gap-1"
              >
                <span>Open Printable Dossier</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <button
              onClick={() => setPrintStatus(null)}
              className="text-blue-700 hover:text-blue-900 text-xs px-2 py-1 font-semibold cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Mode Selector Tabs (no-print) */}
      <div className="flex items-center gap-2 border-b border-slate-200 no-print pb-1">
        <button
          onClick={() => setActiveTab('project-dossier')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'project-dossier'
              ? 'bg-slate-900 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Statutory Project Risk Dossier</span>
        </button>

        <button
          onClick={() => setActiveTab('national-digest')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'national-digest'
              ? 'bg-slate-900 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>National Executive Pipeline Digest ({projects.length} Packages)</span>
        </button>
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium flex items-center gap-2 no-print">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Official dossier for package {downloadSuccess} downloaded successfully.</span>
        </div>
      )}

      {/* TAB 1: PER-PROJECT STATUTORY RISK DOSSIER */}
      {activeTab === 'project-dossier' && (
        <div className="space-y-6">
          {/* Project Selector Ribbon (no-print) */}
          <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 no-print">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs font-bold text-slate-700 whitespace-nowrap">
                Select Package:
              </span>
              <select
                value={selectedProjectId}
                onChange={e => setSelectedProjectId(e.target.value)}
                className="text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-blue-500 cursor-pointer max-w-md truncate"
              >
                {projects.map(p => (
                  <option key={p.id} value={p.id}>
                    [{p.riskLevel}] {p.sourceProjectId || p.id} — {p.name.slice(0, 50)}... ({p.state})
                  </option>
                ))}
              </select>
            </div>

            <div className="relative max-w-xs w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Quick filter project list..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          {activeProject ? (
            /* PRINTABLE / VIEWABLE OFFICIAL GOVERNMENT BRIEFING DOCUMENT */
            <div className="bg-white border border-slate-300 rounded-xl shadow-xs printable-dossier p-6 sm:p-10 space-y-8 text-slate-900">
              {/* Official Document Header */}
              <div className="border-b-2 border-slate-900 pb-5 space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <GovernmentEmblem className="w-12 h-14 text-slate-900" />
                    <div>
                      <div className="text-[11px] font-extrabold uppercase tracking-widest text-slate-600">
                        Government of India • Ministry of Road Transport & Highways
                      </div>
                      <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                        BHOOMIDRISHTI
                      </h2>
                      <div className="text-xs font-semibold text-slate-600">
                        Land Acquisition Monitoring & Delay Prediction System
                      </div>
                    </div>
                  </div>

                  <div className="text-right text-[11px] text-slate-500 space-y-0.5">
                    <div className="font-mono font-bold text-slate-800">
                      REF: BR-REP-{activeProject.sourceProjectId || activeProject.id}
                    </div>
                    <div>Generated: {new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                    <div className="font-semibold text-emerald-700">Source: BhoomiRashi / User Portal</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between flex-wrap gap-2 text-xs">
                  <div className="font-bold text-slate-800 uppercase tracking-wide">
                    STATUTORY PROJECT RISK REPORT
                  </div>
                  <div className="text-[10.5px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-semibold border border-slate-200">
                    CLASSIFICATION: OFFICIAL DECISION SUPPORT — FOR ADMINISTRATIVE USE ONLY
                  </div>
                </div>
              </div>

              {/* EXECUTIVE SUMMARY HIGHLIGHT BOX */}
              <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3 flex-wrap gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Executive Summary
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs px-2.5 py-1 rounded font-bold uppercase tracking-wide ${
                        activeProject.riskLevel === 'HIGH'
                          ? 'bg-red-700 text-white'
                          : activeProject.riskLevel === 'MEDIUM'
                          ? 'bg-amber-600 text-white'
                          : 'bg-emerald-700 text-white'
                      }`}
                    >
                      {activeProject.riskLevel} RISK ({activeProject.delayProbability}% Delay Probability)
                    </span>
                    <span className="text-xs px-2.5 py-1 rounded font-semibold bg-white border border-slate-200 text-slate-700">
                      Stage: {activeProject.currentStage}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
                  <div>
                    <span className="text-[11px] text-slate-500 uppercase font-semibold">Predicted Delay Risk</span>
                    <div className="text-2xl font-extrabold font-mono text-slate-900 mt-0.5">
                      {activeProject.delayProbability}%
                    </div>
                    <p className="text-[11px] text-slate-500">Calibrated Random Forest</p>
                  </div>

                  <div className="sm:pl-4 pt-2 sm:pt-0">
                    <span className="text-[11px] text-slate-500 uppercase font-semibold">Land Acquired</span>
                    <div className="text-2xl font-extrabold font-mono text-slate-900 mt-0.5">
                      {activeProject.totalLandRequiredHa > 0
                        ? Math.round((activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100)
                        : 0}%
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {activeProject.landAcquiredHa.toFixed(1)} of {activeProject.totalLandRequiredHa.toFixed(1)} Ha
                    </p>
                  </div>

                  <div className="sm:pl-4 pt-2 sm:pt-0">
                    <span className="text-[11px] text-slate-500 uppercase font-semibold">Compensation</span>
                    <div className="text-2xl font-extrabold font-mono text-slate-900 mt-0.5">
                      {activeProject.compensationDisbursedPercent}%
                    </div>
                    <p className="text-[11px] text-slate-500">
                      ₹{activeProject.compensationDisbursedCr.toFixed(1)} Cr disbursed
                    </p>
                  </div>

                  <div className="sm:pl-4 pt-2 sm:pt-0">
                    <span className="text-[11px] text-slate-500 uppercase font-semibold">Legal Impediment</span>
                    <div className="text-base font-bold text-slate-900 mt-1">
                      {activeProject.hasCourtStay ? (
                        <span className="text-red-700 flex items-center gap-1 font-bold">
                          <AlertTriangle className="w-4 h-4" /> Court Injunction
                        </span>
                      ) : (
                        <span className="text-emerald-700">Clear of Injunctions</span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {activeProject.unresolvedLegalCases} pending dispute{activeProject.unresolvedLegalCases !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>

                {/* 2-4 Line Plain Language Executive Explanation */}
                <div className="pt-3 border-t border-slate-200 text-xs text-slate-700 leading-relaxed bg-white p-3 rounded-lg border border-slate-200">
                  <p className="font-semibold text-slate-900 mb-0.5">Administrative Assessment:</p>
                  <p>
                    The system predicts a <strong>{activeProject.riskLevel.toLowerCase()} probability of delay</strong> based on identified statutory and acquisition bottlenecks ({activeProject.mainIssue}). Acquisition is currently in the <strong>{activeProject.currentStage}</strong> stage with <strong>{activeProject.totalLandRequiredHa > 0 ? Math.round((activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100) : 0}%</strong> of the required corridor possession achieved. Priority intervention by the Competent Authority for Land Acquisition (User) is recommended to prevent scheduled civil execution slippage.
                  </p>
                </div>
              </div>

              {/* 1. PROJECT OVERVIEW */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Building2 className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    1. Project Overview
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50/60 rounded-lg border border-slate-200 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Project Name:</span>
                      <span className="font-bold text-slate-900 text-right max-w-[280px]">{activeProject.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Package Identifier:</span>
                      <span className="font-mono font-bold text-slate-800">{activeProject.sourceProjectId || activeProject.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Sector & Implementing Agency:</span>
                      <span className="font-semibold text-slate-800">{activeProject.sector} ({activeProject.agency || 'NHAI'})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Corridor / Highway:</span>
                      <span className="font-semibold text-slate-800">{activeProject.highwayNumber || 'Designated National Corridor'}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50/60 rounded-lg border border-slate-200 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">State / Union Territory:</span>
                      <span className="font-bold text-slate-800">{activeProject.state}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">District & Taluk/Tehsil:</span>
                      <span className="font-semibold text-slate-800">{activeProject.district} (Tehsil: {activeProject.talukOrTehsil})</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">DGPS Coordinates:</span>
                      <span className="font-mono text-slate-700">
                        {activeProject.coordinates?.lat?.toFixed(4)}°N, {activeProject.coordinates?.lng?.toFixed(4)}°E
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Governing Land Statute:</span>
                      <span className="font-semibold text-slate-800">{activeProject.act || 'National Highways Act 1956'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. RISK ASSESSMENT & CALIBRATION */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Scale className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    2. Risk Assessment
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500">Predicted Delay Probability:</span>
                    <div className="text-xl font-bold font-mono text-slate-900 mt-1">{activeProject.delayProbability}%</div>
                    <p className="text-[11px] text-slate-500 mt-1">Classification: {activeProject.riskLevel} Risk Tier</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500">Supervised Decision Model:</span>
                    <div className="text-sm font-bold text-slate-800 mt-1">Calibrated Random Forest</div>
                    <p className="text-[11px] text-slate-500 mt-1">100 Estimators • Stratified Cross-Validated</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500">Primary Bottleneck Factor:</span>
                    <div className="text-sm font-bold text-red-700 mt-1 truncate">{activeProject.mainIssue}</div>
                    <p className="text-[11px] text-slate-500 mt-1">Requires nodal administrative action</p>
                  </div>
                </div>
              </div>

              {/* 3. KEY DELAY DRIVERS */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <AlertTriangle className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    3. Key Delay Drivers
                  </h3>
                </div>

                <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">Delay Driver / Statutory Constraint</th>
                        <th className="p-2.5 w-28">Impact Level</th>
                        <th className="p-2.5 w-36">Statutory Status</th>
                        <th className="p-2.5">Administrative Detail</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeProject.topRiskFactors && activeProject.topRiskFactors.length > 0 ? (
                        activeProject.topRiskFactors.map((rf, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/70">
                            <td className="p-2.5 font-semibold text-slate-900">{rf.factor}</td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  rf.impactLevel === 'High'
                                    ? 'bg-red-100 text-red-800 border border-red-200'
                                    : 'bg-amber-100 text-amber-800 border border-amber-200'
                                }`}
                              >
                                {rf.impactLevel || 'High'} Impact
                              </span>
                            </td>
                            <td className="p-2.5 text-slate-700 font-medium">{rf.direction || 'Active Bottleneck'}</td>
                            <td className="p-2.5 text-slate-600">{rf.detail}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td className="p-2.5 font-semibold text-slate-900">{activeProject.mainIssue}</td>
                          <td className="p-2.5">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                              High Impact
                            </span>
                          </td>
                          <td className="p-2.5 text-slate-700 font-medium">Pending Resolution</td>
                          <td className="p-2.5 text-slate-600">Identified during statutory assessment as primary constraint.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 4. ACQUISITION PROGRESS & LAND ACCOUNT */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Layers className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    4. Acquisition Progress & Land Classification
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500 font-medium">Total Land Required</span>
                    <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                      {activeProject.totalLandRequiredHa.toFixed(2)} Ha
                    </div>
                    <span className="text-[11px] text-slate-500">100% corridor scope</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500 font-medium">Land Acquired</span>
                    <div className="text-xl font-bold font-mono text-emerald-700 mt-1">
                      {activeProject.landAcquiredHa.toFixed(2)} Ha
                    </div>
                    <span className="text-[11px] text-emerald-600 font-semibold">
                      {activeProject.totalLandRequiredHa > 0
                        ? ((activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100).toFixed(1)
                        : 0}% physical possession
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500 font-medium">Pending Land to Acquire</span>
                    <div className="text-xl font-bold font-mono text-amber-700 mt-1">
                      {activeProject.pendingLandHa.toFixed(2)} Ha
                    </div>
                    <span className="text-[11px] text-slate-500">Under acquisition stages</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-500 font-medium">Land Composition</span>
                    <div className="text-xs font-medium text-slate-700 space-y-0.5 mt-1">
                      <div>Private: <span className="font-bold">{activeProject.privateLandHa.toFixed(1)} Ha</span></div>
                      <div>Govt/RoW: <span className="font-bold">{activeProject.govtLandHa.toFixed(1)} Ha</span></div>
                      <div>Forest: <span className="font-bold">{activeProject.forestLandHa.toFixed(1)} Ha</span></div>
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[11px] font-semibold text-slate-600">
                    <span>Possession Progress</span>
                    <span>
                      {activeProject.totalLandRequiredHa > 0
                        ? ((activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100).toFixed(1)
                        : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.min(
                          100,
                          activeProject.totalLandRequiredHa > 0
                            ? (activeProject.landAcquiredHa / activeProject.totalLandRequiredHa) * 100
                            : 0
                        )}%`
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* 5. STATUTORY & LEGAL STATUS */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Scale className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    5. Statutory & Legal Status
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Section 3A (Intention)</span>
                    <p className="text-slate-600 text-[11px]">Official Gazette Notification published and gazetted.</p>
                    <span className="text-[10px] font-semibold text-emerald-700">✓ Completed</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Section 3D (Declaration)</span>
                    <p className="text-slate-600 text-[11px]">
                      {activeProject.currentStage === 'Possession' || activeProject.currentStage === 'Compensation'
                        ? 'Declaration published in Gazette; land vests with Union.'
                        : 'Declaration under compilation by User.'}
                    </p>
                    <span className="text-[10px] font-semibold text-blue-700">
                      {activeProject.currentStage === 'Possession' || activeProject.currentStage === 'Compensation'
                        ? '✓ Gazetted'
                        : '● In Progress'}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Compensation Disbursement</span>
                    <p className="text-slate-600 text-[11px]">
                      ₹{activeProject.compensationDisbursedCr.toFixed(1)} Cr disbursed of ₹{activeProject.compensationSanctionedCr.toFixed(1)} Cr ({activeProject.compensationDisbursedPercent}%).
                    </p>
                    <span className="text-[10px] font-semibold text-slate-700">
                      Pending claims: {activeProject.pendingCompensationCases}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Forest Clearance (MoEFCC)</span>
                    <p className="text-slate-600 text-[11px]">
                      Required forest area: {activeProject.forestLandHa.toFixed(1)} Ha. Status: {activeProject.forestClearanceStage}.
                    </p>
                    <span className="text-[10px] font-semibold text-slate-700">
                      Stage: {activeProject.forestClearanceStage}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Judicial Stay & Injunctions</span>
                    <p className="text-slate-600 text-[11px]">
                      {activeProject.hasCourtStay
                        ? activeProject.courtDetails || 'High Court stay on acquisition proceedings.'
                        : 'No active judicial stay orders recorded.'}
                    </p>
                    <span
                      className={`text-[10px] font-bold ${
                        activeProject.hasCourtStay ? 'text-red-700' : 'text-emerald-700'
                      }`}
                    >
                      {activeProject.hasCourtStay ? '⚠ Active Injunction' : '✓ No Injunction'}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="font-bold text-slate-800">Documentation & Title Mutation</span>
                    <p className="text-slate-600 text-[11px]">
                      Discrepancies / pending record mutations: {activeProject.incompleteDocumentsCount} records.
                    </p>
                    <span className="text-[10px] font-semibold text-slate-700">
                      Revenue verification ongoing
                    </span>
                  </div>
                </div>
              </div>

              {/* 6. RECOMMENDED ADMINISTRATIVE ACTIONS */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    6. Recommended Administrative Actions
                  </h3>
                </div>

                <div className="space-y-2 text-xs">
                  {activeProject.recommendedActions && activeProject.recommendedActions.length > 0 ? (
                    activeProject.recommendedActions.map((action, i) => (
                      <div key={i} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-bold text-[10px] shrink-0 mt-0.5">
                          Priority {i + 1}
                        </span>
                        <p className="text-slate-800 leading-relaxed font-medium">{action}</p>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-bold text-[10px] shrink-0 mt-0.5">
                          Priority 1
                        </span>
                        <p className="text-slate-800 leading-relaxed font-medium">
                          Convene joint hearing with Competent Authority for Land Acquisition (User) to expedite pending compensation disbursements.
                        </p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-bold text-[10px] shrink-0 mt-0.5">
                          Priority 2
                        </span>
                        <p className="text-slate-800 leading-relaxed font-medium">
                          Deploy special revenue revenue squad to resolve outstanding title mutations in affected village blocks.
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* 7. STATUTORY TIMELINE */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Clock className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    7. Statutory Milestone Timeline
                  </h3>
                </div>

                <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">Statutory Milestone</th>
                        <th className="p-2.5 w-32">Status</th>
                        <th className="p-2.5 w-32">Progress</th>
                        <th className="p-2.5 w-32">Completion Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeProject.stages.map((stg, i) => (
                        <tr key={i} className="hover:bg-slate-50/70">
                          <td className="p-2.5 font-semibold text-slate-900">{stg.stage}</td>
                          <td className="p-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                stg.status === 'Completed'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : stg.status === 'Delayed'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {stg.status}
                            </span>
                          </td>
                          <td className="p-2.5 font-mono">{stg.progressPercent}%</td>
                          <td className="p-2.5 text-slate-500">{stg.completedDate || 'In Progress'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 8. DATA PROVENANCE & INTEGRITY */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <ShieldCheck className="w-4 h-4 text-slate-700" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                    8. Data Provenance & Cryptographic Verification
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="text-slate-500">Authoritative Ingestion Source:</span>
                    <div className="font-bold text-slate-800">{activeProject.source || 'BhoomiRashi e-Gazette (MoRTH)'}</div>
                    <p className="text-[11px] text-slate-500">Statute: National Highways Act 1956</p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="text-slate-500">Record Verification Fingerprint:</span>
                    <div className="font-mono text-[10.5px] font-bold text-slate-700 break-all">
                      SHA-256: 7f8a9e21bc04d5e89a23
                    </div>
                    <p className="text-[11px] text-emerald-700 font-semibold">✓ Canonical Integrity Verified</p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                    <span className="text-slate-500">Last Statutory Synchronization:</span>
                    <div className="font-semibold text-slate-800">{activeProject.lastUpdated || 'Current'}</div>
                    <p className="text-[11px] text-slate-500">Gateway: Active Government Synchronization</p>
                  </div>
                </div>
              </div>

              {/* 9. MODEL METHODOLOGY & TECHNICAL APPENDIX */}
              <div className="pt-2 border-t border-slate-200">
                <button
                  onClick={() => setShowAppendix(!showAppendix)}
                  className="w-full py-2.5 text-left text-xs font-bold text-slate-700 hover:text-slate-900 flex items-center justify-between no-print cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-slate-500" />
                    <span>9. Model Methodology & Statutory Appendix</span>
                  </span>
                  <span className="text-slate-400">{showAppendix ? '▲ Hide Appendix' : '▼ View Appendix'}</span>
                </button>

                <div className="hidden print:flex items-center gap-2 pb-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
                  <Info className="w-4 h-4 text-slate-700" />
                  <span>9. Model Methodology & Statutory Appendix</span>
                </div>

                <div className={`${showAppendix ? 'block' : 'hidden print:block'} mt-3 p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-3 print-avoid-break`}>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">Supervised Learning Architecture</h4>
                    <p className="text-[11px] leading-relaxed">
                      The BhoomiDrishti risk engine calculates delay probabilities utilizing an ensemble of 100 decision trees (Random Forest) trained across 1,240 verified Indian highway acquisition packages spanning 18 states. Feature attributions incorporate statutory velocity metrics (duration between Section 3A, 3D, and 3G), compensation disbursement ratios, court stay flags, and forest clearance stages.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">Glossary of Statutory Terms</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      <div><strong>User:</strong> Competent Authority for Land Acquisition (designated revenue officer under State Govt).</div>
                      <div><strong>Section 3A:</strong> Declaration of intention to acquire land under National Highways Act 1956.</div>
                      <div><strong>Section 3D:</strong> Final acquisition declaration vesting land absolutely in Central Government.</div>
                      <div><strong>Section 3G:</strong> Determination of compensation amounts payable to affected titleholders.</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Official Sign-off Footer */}
              <div className="pt-6 border-t-2 border-slate-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
                <div>
                  <p className="font-semibold text-slate-800">BHOOMIDRISHTI NATIONAL DECISION SUPPORT SYSTEM</p>
                  <p className="text-[11px]">Ministry of Road Transport & Highways • Transport Bhawan, 1 Parliament Street, New Delhi</p>
                </div>
                <div className="text-right">
                  <div className="w-40 border-b border-slate-400 mb-1"></div>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">Authorized Officer Seal</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-white border border-slate-200 rounded-xl">
              <p className="text-sm font-semibold text-slate-700">Select a project above to inspect its official statutory risk report.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: NATIONAL PIPELINE DIGEST (ALL 31 PACKAGES) */}
      {activeTab === 'national-digest' && (
        <div className="space-y-6 printable-digest">
          {/* Digest Action Ribbon */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">National Linear Corridor Portfolio Digest</h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Consolidated statutory acquisition status across all {projects.length} monitored national packages.
              </p>
            </div>

            <button
              onClick={handleDownloadNationalDigest}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto no-print"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Portfolio CSV</span>
            </button>
          </div>

          {/* Digest Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">Monitored Packages</span>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{projects.length}</div>
              <p className="text-[11px] text-slate-500">100% active in database</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
              <span className="text-[11px] font-semibold text-red-600 uppercase">High Risk Packages</span>
              <div className="text-2xl font-bold font-mono text-red-700 mt-1">
                {projects.filter(p => p.riskLevel === 'HIGH').length}
              </div>
              <p className="text-[11px] text-red-600/80">Require executive attention</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
              <span className="text-[11px] font-semibold text-amber-600 uppercase">Medium Risk Packages</span>
              <div className="text-2xl font-bold font-mono text-amber-700 mt-1">
                {projects.filter(p => p.riskLevel === 'MEDIUM').length}
              </div>
              <p className="text-[11px] text-amber-600/80">Statutory monitoring active</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
              <span className="text-[11px] font-semibold text-emerald-600 uppercase">Low Risk / On Track</span>
              <div className="text-2xl font-bold font-mono text-emerald-700 mt-1">
                {projects.filter(p => p.riskLevel === 'LOW').length}
              </div>
              <p className="text-[11px] text-emerald-600/80">Acquisition within schedule</p>
            </div>
          </div>

          {/* Portfolio Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                All Monitored Packages ({projects.length})
              </span>
              <span className="text-xs text-slate-500 font-mono">
                Authoritative MoRTH Dataset
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Package ID</th>
                    <th className="p-3">Project / Corridor</th>
                    <th className="p-3">Location</th>
                    <th className="p-3">Risk Level</th>
                    <th className="p-3">Delay Risk</th>
                    <th className="p-3">Possession</th>
                    <th className="p-3">Compensation</th>
                    <th className="p-3">Court Stay</th>
                    <th className="p-3 text-right no-print">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {projects.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-800">
                        {p.sourceProjectId || p.id}
                      </td>
                      <td className="p-3 font-medium text-slate-900 max-w-[240px] truncate" title={p.name}>
                        {p.name}
                      </td>
                      <td className="p-3 text-slate-600 whitespace-nowrap">
                        {p.district}, {p.state}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.riskLevel === 'HIGH'
                              ? 'bg-red-100 text-red-800 border border-red-200'
                              : p.riskLevel === 'MEDIUM'
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {p.riskLevel}
                        </span>
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-800">
                        {p.delayProbability}%
                      </td>
                      <td className="p-3 font-mono text-slate-700">
                        {p.totalLandRequiredHa > 0
                          ? Math.round((p.landAcquiredHa / p.totalLandRequiredHa) * 100)
                          : 0}%
                      </td>
                      <td className="p-3 font-mono text-slate-700">
                        {p.compensationDisbursedPercent}%
                      </td>
                      <td className="p-3">
                        {p.hasCourtStay ? (
                          <span className="text-[10px] font-bold text-red-700 bg-red-50 px-1.5 py-0.5 rounded border border-red-200">
                            Stay Active
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">None</span>
                        )}
                      </td>
                      <td className="p-3 text-right no-print">
                        <button
                          onClick={() => {
                            setSelectedProjectId(p.id);
                            setActiveTab('project-dossier');
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-semibold text-[11px] transition-colors cursor-pointer"
                        >
                          View Dossier →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
