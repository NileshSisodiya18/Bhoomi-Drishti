import React, { useState, useMemo } from 'react';
import { Project, RiskLevel } from '../types.ts';
import { RiskBadge, DataSourceBadge, StageStatusBadge } from './StatusBadge.tsx';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import {
  Search,
  Filter,
  ArrowUpDown,
  ChevronRight,
  ExternalLink,
  MapPin,
  RefreshCw,
  Building2,
  X
} from 'lucide-react';

interface ProjectsViewProps {
  projects: Project[];
  loading: boolean;
  onSelectProject: (id: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  loading,
  onSelectProject
}) => {
  const [search, setSearch] = useState('');
  const [selectedRisk, setSelectedRisk] = useState<string>('ALL');
  const [selectedState, setSelectedState] = useState<string>('ALL');
  const [selectedSource, setSelectedSource] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'risk' | 'name' | 'progress' | 'updated'>('risk');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 12;

  const [filterTrayOpen, setFilterTrayOpen] = useState(false);

  // Distinct states for filter
  const states = useMemo(() => {
    return Array.from(new Set(projects.map(p => p.state))).sort();
  }, [projects]);

  // Distinct sources
  const sources = useMemo(() => {
    const list = new Set<string>();
    projects.forEach(p => {
      if (p.source) list.add(p.source);
    });
    return Array.from(list);
  }, [projects]);

  const filteredProjects = useMemo(() => {
    let result = projects.filter(p => {
      const q = search.toLowerCase().trim();
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.district.toLowerCase().includes(q) ||
        p.state.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q) ||
        (p.sourceProjectId && p.sourceProjectId.toLowerCase().includes(q)) ||
        (p.highwayNumber && p.highwayNumber.toLowerCase().includes(q));

      const matchesRisk =
        selectedRisk === 'ALL' || p.riskLevel === selectedRisk;

      const matchesState =
        selectedState === 'ALL' || p.state === selectedState;

      const matchesSource =
        selectedSource === 'ALL' ||
        (selectedSource === 'LIVE' ? (!p.isSynthetic || p.source === 'BhoomiRashi') : p.source === selectedSource);

      const matchesStatus =
        selectedStatus === 'ALL' || p.stageStatus === selectedStatus;

      return matchesSearch && matchesRisk && matchesState && matchesSource && matchesStatus;
    });

    // Sort
    result.sort((a, b) => {
      let cmp = 0;
      if (sortBy === 'risk') {
        cmp = b.delayProbability - a.delayProbability;
      } else if (sortBy === 'name') {
        cmp = a.name.localeCompare(b.name);
      } else if (sortBy === 'progress') {
        const progA = a.totalLandRequiredHa > 0 ? (a.landAcquiredHa / a.totalLandRequiredHa) : 0;
        const progB = b.totalLandRequiredHa > 0 ? (b.landAcquiredHa / b.totalLandRequiredHa) : 0;
        cmp = progB - progA;
      } else if (sortBy === 'updated') {
        cmp = new Date(b.lastUpdated || 0).getTime() - new Date(a.lastUpdated || 0).getTime();
      }
      return sortOrder === 'asc' ? -cmp : cmp;
    });

    return result;
  }, [projects, search, selectedRisk, selectedState, selectedSource, selectedStatus, sortBy, sortOrder]);

  // Pagination
  const totalPages = Math.ceil(filteredProjects.length / pageSize) || 1;
  const paginatedProjects = filteredProjects.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const resetFilters = () => {
    setSearch('');
    setSelectedRisk('ALL');
    setSelectedState('ALL');
    setSelectedSource('ALL');
    setSelectedStatus('ALL');
    setSortBy('risk');
    setSortOrder('desc');
    setCurrentPage(1);
  };

  const hasAdvancedFilters =
    selectedState !== 'ALL' ||
    selectedSource !== 'ALL' ||
    selectedStatus !== 'ALL';

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight">
            Projects Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Search, filter, and inspect acquisition progress across all active national infrastructure packages.
          </p>
        </div>

        <div className="text-xs font-medium text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-2xs self-start sm:self-auto">
          Monitored Packages: <span className="font-bold text-slate-900 font-mono">{projects.length}</span>
        </div>
      </div>

      {/* SEARCH AND PROGRESSIVE FILTER BAR */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="project-search-input"
              type="text"
              placeholder="Search project, district, state, highway, ID..."
              value={search}
              onChange={e => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-10 pr-9 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:bg-white text-slate-900 placeholder:text-slate-400 transition-all"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Risk Pills & Filter Tray Trigger */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium">
              <button
                onClick={() => { setSelectedRisk('ALL'); setCurrentPage(1); }}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  selectedRisk === 'ALL'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({projects.length})
              </button>
              <button
                onClick={() => { setSelectedRisk('HIGH'); setCurrentPage(1); }}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                  selectedRisk === 'HIGH'
                    ? 'bg-red-700 text-white font-semibold'
                    : 'text-red-700 hover:bg-red-50'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                High Risk
              </button>
              <button
                onClick={() => { setSelectedRisk('MEDIUM'); setCurrentPage(1); }}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                  selectedRisk === 'MEDIUM'
                    ? 'bg-amber-700 text-white font-semibold'
                    : 'text-amber-800 hover:bg-amber-50'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                Medium
              </button>
              <button
                onClick={() => { setSelectedRisk('LOW'); setCurrentPage(1); }}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                  selectedRisk === 'LOW'
                    ? 'bg-emerald-700 text-white font-semibold'
                    : 'text-emerald-800 hover:bg-emerald-50'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                On Track
              </button>
            </div>

            {/* Advanced Filters Button */}
            <button
              onClick={() => setFilterTrayOpen(!filterTrayOpen)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                filterTrayOpen || hasAdvancedFilters
                  ? 'bg-blue-50 border-blue-300 text-blue-900'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters {filterTrayOpen ? '▲' : '▼'}</span>
              {hasAdvancedFilters && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
            </button>
          </div>
        </div>

        {/* Collapsible Advanced Filters Tray */}
        {filterTrayOpen && (
          <div className="pt-3 border-t border-slate-100 flex items-center gap-3 flex-wrap text-xs animate-in fade-in duration-150">
            {/* State Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">State:</span>
              <select
                value={selectedState}
                onChange={e => {
                  setSelectedState(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 font-medium"
              >
                <option value="ALL">All States ({states.length})</option>
                {states.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Data Source Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Source:</span>
              <select
                value={selectedSource}
                onChange={e => {
                  setSelectedSource(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 font-medium"
              >
                <option value="ALL">All Sources</option>
                <option value="LIVE">Live BhoomiRashi Portal</option>
                {sources.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Stage Status Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Status:</span>
              <select
                value={selectedStatus}
                onChange={e => {
                  setSelectedStatus(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 font-medium"
              >
                <option value="ALL">All Statuses</option>
                <option value="In Progress">In Progress</option>
                <option value="Delayed">Delayed</option>
                <option value="Completed">Completed</option>
              </select>
            </div>

            {/* Sort Order */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Sort:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 font-medium"
              >
                <option value="risk">Delay Probability</option>
                <option value="name">Project Name</option>
                <option value="progress">Land Acquired %</option>
                <option value="updated">Last Synchronized</option>
              </select>
              <button
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="p-1 border border-slate-200 rounded bg-slate-50 hover:bg-slate-100 text-slate-600 cursor-pointer"
                title={`Order: ${sortOrder.toUpperCase()}`}
              >
                <ArrowUpDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Reset Filters */}
            <button
              onClick={resetFilters}
              className="text-slate-600 hover:text-red-700 font-semibold ml-auto cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* TABLE / LIST VIEW */}
      {loading ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <div className="inline-block w-8 h-8 border-3 border-slate-200 border-t-blue-600 rounded-full animate-spin mb-3" />
          <p className="text-xs font-semibold text-slate-700">Loading statutory project records...</p>
        </div>
      ) : filteredProjects.length === 0 ? (
        /* Empty State */
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No projects match your filters</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search keywords, clear specific filter dropdowns, or reset all criteria.
          </p>
          <button
            onClick={resetFilters}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
          {/* Result counter bar */}
          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>
              Showing <span className="font-bold text-slate-800">{paginatedProjects.length}</span> of{' '}
              <span className="font-bold text-slate-800">{filteredProjects.length}</span> projects
            </span>
            <span className="text-[11px] text-slate-400">Page {currentPage} of {totalPages}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/50">
                  <th className="py-3 px-4">Project Name & ID</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Land Progress (Ha)</th>
                  <th className="py-3 px-4">
                    <span className="flex items-center gap-1">
                      Risk Level
                      <InfoTooltip content="Delay probability forecasted by ML model based on statutory velocity." />
                    </span>
                  </th>
                  <th className="py-3 px-4">Source</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {paginatedProjects.map(project => {
                  const progressPct =
                    project.totalLandRequiredHa > 0
                      ? Math.min(100, Math.round((project.landAcquiredHa / project.totalLandRequiredHa) * 100))
                      : 0;

                  return (
                    <tr
                      key={project.id}
                      onClick={() => onSelectProject(project.id)}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    >
                      {/* Project Name & ID */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="font-semibold text-slate-900 group-hover:text-blue-700 transition-colors truncate">
                          {project.name}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[10.5px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded font-medium">
                            {project.sourceProjectId || project.id}
                          </span>
                          {project.highwayNumber && (
                            <span className="text-[10.5px] font-medium text-slate-500">
                              {project.highwayNumber}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Location */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="font-medium text-slate-800">{project.district}</div>
                        <div className="text-[11px] text-slate-500">{project.state}</div>
                      </td>

                      {/* Land Progress */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                          <span className="font-semibold text-slate-800">{project.landAcquiredHa} Ha</span>
                          <span className="text-slate-400">/ {project.totalLandRequiredHa} Ha</span>
                        </div>
                        <div className="w-28 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              progressPct >= 75
                                ? 'bg-emerald-600'
                                : progressPct >= 30
                                ? 'bg-blue-600'
                                : 'bg-amber-500'
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">{progressPct}% acquired</span>
                      </td>

                      {/* Risk Level */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <RiskBadge level={project.riskLevel} />
                          <span className="font-mono text-xs font-bold text-slate-700">
                            {project.delayProbability}%
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5 truncate max-w-[120px]">
                          {project.mainIssue}
                        </span>
                      </td>

                      {/* Source */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <DataSourceBadge source={project.source} isSynthetic={project.isSynthetic} />
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <StageStatusBadge status={project.stageStatus} />
                      </td>

                      {/* Action */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            onSelectProject(project.id);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-md border border-blue-200 transition-colors inline-flex items-center gap-1"
                        >
                          <span>View Details</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination bar */}
          {totalPages > 1 && (
            <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 disabled:opacity-50"
              >
                Previous
              </button>

              <div className="text-xs text-slate-600 font-medium">
                Page <span className="font-bold">{currentPage}</span> of{' '}
                <span className="font-bold">{totalPages}</span>
              </div>

              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 disabled:opacity-50"
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
