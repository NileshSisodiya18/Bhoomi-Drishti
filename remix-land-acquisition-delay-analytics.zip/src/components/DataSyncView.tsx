import React, { useState, useEffect } from 'react';
import {
  Database,
  RefreshCw,
  UploadCloud,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Clock,
  ShieldCheck,
  FileSpreadsheet,
  Layers,
  ArrowRight,
  Info,
  Sliders,
  Download,
  Search,
  FileText,
  Check,
  X,
  Activity,
  Wifi,
  AlertCircle,
  HardDrive,
  Settings,
  ChevronRight
} from 'lucide-react';
import { api } from '../services/apiClient.ts';
import {
  DataSourceItem,
  SyncRunResponse,
  FileInspectionResult,
  DataValidationErrorItem,
  AuditLogItem,
  DatabaseOverview,
  ConnectionTestResult
} from '../types.ts';

interface DataSyncViewProps {
  onSyncComplete?: () => void;
}

type TabType = 'sources' | 'import' | 'validation' | 'history' | 'audit' | 'overview';

export const DataSyncView: React.FC<DataSyncViewProps> = ({ onSyncComplete }) => {
  const [activeTab, setActiveTab] = useState<TabType>('sources');
  const [dataSources, setDataSources] = useState<DataSourceItem[]>([]);
  const [history, setHistory] = useState<SyncRunResponse[]>([]);
  const [validationErrors, setValidationErrors] = useState<DataValidationErrorItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [overview, setOverview] = useState<DatabaseOverview | null>(null);

  // Loading & Action states
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, ConnectionTestResult>>({});
  const [testingSourceId, setTestingSourceId] = useState<string | null>(null);
  const [syncResult, setSyncResult] = useState<SyncRunResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // File import state
  const [importContent, setImportContent] = useState('');
  const [importFileName, setImportFileName] = useState('');
  const [importType, setImportType] = useState<'csv' | 'xlsx' | 'xls' | 'json'>('csv');
  const [isInspecting, setIsInspecting] = useState(false);
  const [inspectionResult, setInspectionResult] = useState<FileInspectionResult | null>(null);
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({});
  const [isImporting, setIsImporting] = useState(false);

  // Edit Source Modal state
  const [editingSource, setEditingSource] = useState<DataSourceItem | null>(null);
  const [editForm, setEditForm] = useState<{
    baseUrl: string;
    apiEndpoint: string;
    syncIntervalMinutes: number;
    enabled: boolean;
    apiKey: string;
  }>({
    baseUrl: '',
    apiEndpoint: '',
    syncIntervalMinutes: 60,
    enabled: true,
    apiKey: ''
  });

  // Canonical fields for mapping
  const CANONICAL_FIELDS: { key: string; label: string; required?: boolean }[] = [
    { key: 'name', label: 'Project Name / Package Title', required: true },
    { key: 'state', label: 'State Name', required: true },
    { key: 'district', label: 'District Name', required: true },
    { key: 'sector', label: 'Sector (Highways / Railways / Metro)' },
    { key: 'act', label: 'Governing Act (NH Act / RFCTLARR)' },
    { key: 'totalLandRequiredHa', label: 'Total Land Required (Hectares)' },
    { key: 'landAcquiredHa', label: 'Land Acquired (Hectares)' },
    { key: 'compensationSanctionedCr', label: 'Compensation Sanctioned (₹ Cr)' },
    { key: 'compensationDisbursedCr', label: 'Compensation Disbursed (₹ Cr)' },
    { key: 'currentStage', label: 'Current Acquisition Stage' },
    { key: 'hasCourtStay', label: 'Court Stay / Litigation Status' }
  ];

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setIsLoading(true);
    try {
      const [sourcesRes, histRes, errorsRes, auditRes, overviewRes] = await Promise.all([
        api.getDataSources().catch(() => []),
        api.getSyncHistory().catch(() => []),
        api.getValidationErrors(undefined, 50).catch(() => []),
        api.getAuditLogs(50).catch(() => []),
        api.getDatabaseOverview().catch(() => null)
      ]);

      setDataSources(sourcesRes);
      setHistory(histRes);
      setValidationErrors(errorsRes);
      setAuditLogs(auditRes);
      setOverview(overviewRes);
    } catch (err: any) {
      console.error('Error loading data sync info:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestConnection = async (sourceId: string) => {
    setTestingSourceId(sourceId);
    setErrorMsg(null);
    try {
      const res = await api.testDataSource(sourceId);
      setTestResults(prev => ({ ...prev, [sourceId]: res }));
      if (res.success) {
        setSuccessMsg(`Connection to ${sourceId} verified (${res.latencyMs}ms latency).`);
      } else {
        setErrorMsg(`Probe warning for ${sourceId}: ${res.message}`);
      }
    } catch (err: any) {
      setErrorMsg(err.message || `Failed to probe connection to ${sourceId}`);
    } finally {
      setTestingSourceId(null);
    }
  };

  const handleTriggerSync = async (sourceName: 'BhoomiRashi' | 'LACRRIS') => {
    setIsSyncing(sourceName);
    setErrorMsg(null);
    setSuccessMsg(null);
    setSyncResult(null);

    try {
      const summary = await api.triggerSync(sourceName);
      setSyncResult(summary);
      setSuccessMsg(`Successfully synchronized with ${sourceName}`);
      await loadAllData();
      if (onSyncComplete) onSyncComplete();
    } catch (err: any) {
      setErrorMsg(err.message || `Failed to sync with ${sourceName}`);
    } finally {
      setIsSyncing(null);
    }
  };

  const handleOpenEditSource = (source: DataSourceItem) => {
    setEditingSource(source);
    setEditForm({
      baseUrl: source.baseUrl || '',
      apiEndpoint: source.apiEndpoint || '',
      syncIntervalMinutes: source.syncIntervalMinutes || 60,
      enabled: source.enabled,
      apiKey: source.apiKey || ''
    });
  };

  const handleSaveSourceConfig = async () => {
    if (!editingSource) return;
    try {
      await api.updateDataSource(editingSource.id, {
        baseUrl: editForm.baseUrl,
        apiEndpoint: editForm.apiEndpoint,
        syncIntervalMinutes: editForm.syncIntervalMinutes,
        enabled: editForm.enabled,
        apiKey: editForm.apiKey
      });
      setSuccessMsg(`Configuration updated for ${editingSource.name}`);
      setEditingSource(null);
      await loadAllData();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update data source configuration');
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const resolvedType = (ext === 'xlsx' || ext === 'xls') ? ext as any : ext === 'json' ? 'json' : 'csv';
    setImportType(resolvedType);

    if (resolvedType === 'xlsx' || resolvedType === 'xls') {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = (event.target?.result as string).split(',')[1] || '';
        setImportContent(base64);
        await runFileInspection(base64, resolvedType, file.name);
      };
      reader.readAsDataURL(file);
    } else {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const text = event.target?.result as string;
        setImportContent(text);
        await runFileInspection(text, resolvedType, file.name);
      };
      reader.readAsText(file);
    }
  };

  const runFileInspection = async (content: string, type: string, fileName: string) => {
    setIsInspecting(true);
    setErrorMsg(null);
    try {
      const result = await api.inspectFile(content, type, fileName);
      setInspectionResult(result);
      setColumnMapping(result.suggestedMapping || {});
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to inspect file structure');
    } finally {
      setIsInspecting(false);
    }
  };

  const handleImportSubmit = async () => {
    if (!importContent) {
      setErrorMsg('Please select or paste an official CSV, Excel, or JSON dataset first.');
      return;
    }

    setIsImporting(true);
    setErrorMsg(null);
    setSyncResult(null);

    try {
      const summary = await api.importMappedFile(
        importContent,
        importType,
        columnMapping,
        importFileName || 'official_import'
      );
      setSyncResult(summary);
      setSuccessMsg(`Import successful: ${summary.recordsInserted} inserted, ${summary.recordsUpdated} updated.`);
      setImportContent('');
      setImportFileName('');
      setInspectionResult(null);
      await loadAllData();
      if (onSyncComplete) onSyncComplete();
    } catch (err: any) {
      setErrorMsg(err.message || 'File import failed. Please verify format and mappings.');
    } finally {
      setIsImporting(false);
    }
  };

  const loadSampleCsv = async () => {
    const sample = `Project Name,State,District,Sector,Act,Total Land Required (Ha),Land Acquired (Ha),Compensation Sanctioned (Cr),Compensation Disbursed (Cr),Disbursed %,Court Stay,Current Stage\n` +
      `"Nagpur-Hyderabad Economic Corridor Package 3",Maharashtra,Nagpur,National Highways,National Highways Act 1956,380.5,290.0,420.0,380.0,90,No,Possession\n` +
      `"Bengaluru Suburban Rail Corridor 2",Karnataka,Bengaluru Urban,Railways,RFCTLARR Act 2013,125.0,65.0,850.0,340.0,40,Yes,Compensation\n` +
      `"Ahmedabad Dholera Expressway Section II",Gujarat,Ahmedabad,National Highways,National Highways Act 1956,410.0,370.0,610.0,580.0,95,No,Possession`;
    setImportContent(sample);
    setImportFileName('morth_nhai_official_template.csv');
    setImportType('csv');
    await runFileInspection(sample, 'csv', 'morth_nhai_official_template.csv');
  };

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 text-[11px] font-semibold bg-emerald-100 text-emerald-800 rounded-md">
              Statutory Provenance Engine
            </span>
            <span className="text-xs text-slate-500">Government of India MoRTH, DoLR & NHAI Architecture</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Data Sources & Ingestion Pipeline
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-3xl">
            BhoomiDrishti ingests official statutory records with cryptographic record hashing (SHA-256), multi-format parsing (CSV / XLSX / JSON), schema validation, and audit logging.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => loadAllData()}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <a
            href={api.getExportDownloadUrl('all', 'csv')}
            download
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </a>
        </div>
      </div>

      {/* Global Alerts / Feedback */}
      {successMsg && (
        <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-700 hover:text-emerald-900 text-xs font-bold">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-xl border border-red-200 bg-red-50 text-red-800 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg(null)} className="text-red-700 hover:text-red-900 text-xs font-bold">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {syncResult && (
        <div className={`p-4 rounded-xl border flex items-start gap-3 ${
          syncResult.status === 'SUCCESS' ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}>
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="flex-1 text-sm">
            <div className="font-bold">
              {syncResult.source} Ingestion Completed ({syncResult.status})
            </div>
            <div className="mt-1 text-xs opacity-90 grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono">
              <div>Received: <span className="font-bold">{syncResult.recordsReceived}</span></div>
              <div>Valid: <span className="font-bold">{syncResult.recordsValid}</span></div>
              <div>Inserted: <span className="font-bold text-emerald-700">+{syncResult.recordsInserted}</span></div>
              <div>Updated: <span className="font-bold text-indigo-700">~{syncResult.recordsUpdated}</span></div>
              <div>Duration: <span className="font-bold">{syncResult.durationMs}ms</span></div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-slate-200 flex gap-2 overflow-x-auto pb-px">
        {[
          { id: 'sources', label: 'Registered Sources', icon: Activity, count: dataSources.length },
          { id: 'import', label: 'File Ingestion & Mapping', icon: UploadCloud },
          { id: 'validation', label: 'Quality & Validation Errors', icon: AlertCircle, count: validationErrors.length },
          { id: 'history', label: 'Sync Run History', icon: Clock, count: history.length },
          { id: 'audit', label: 'Provenance Audit Trail', icon: ShieldCheck, count: auditLogs.length },
          { id: 'overview', label: 'Database Storage Stats', icon: Database }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
                isActive
                  ? 'border-indigo-600 text-indigo-600 bg-indigo-50/50 rounded-t-lg'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && tab.count > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  isActive ? 'bg-indigo-200 text-indigo-900 font-bold' : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: REGISTERED SOURCES */}
      {activeTab === 'sources' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {dataSources.map((source) => {
              const probe = testResults[source.id];
              const isTesting = testingSourceId === source.id;
              const isSyncingThis = isSyncing === source.id;

              return (
                <div
                  key={source.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-sm ${
                          source.id === 'BhoomiRashi' ? 'bg-orange-100 text-orange-700' :
                          source.id === 'LACRRIS' ? 'bg-blue-100 text-blue-700' :
                          source.id === 'PM_GatiShakti' ? 'bg-purple-100 text-purple-700' :
                          'bg-emerald-100 text-emerald-700'
                        }`}>
                          {source.id.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <h3 className="text-base font-bold text-slate-900">{source.name}</h3>
                          <p className="text-xs text-slate-500">{source.type} Integration</p>
                        </div>
                      </div>
                      <span className={`px-2.5 py-1 text-xs font-semibold rounded-full flex items-center gap-1.5 ${
                        source.enabled
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${source.enabled ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`}></span>
                        {source.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {source.description}
                    </p>

                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1.5 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>Endpoint URL:</span>
                        <span className="font-mono text-[11px] text-slate-800 truncate max-w-[200px]" title={source.baseUrl}>
                          {source.baseUrl || 'Configured internal'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Poll Interval:</span>
                        <span className="font-medium text-slate-800">Every {source.syncIntervalMinutes} mins</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Records Synchronized:</span>
                        <span className="font-semibold text-slate-900">{source.recordsReceived || 0}</span>
                      </div>
                      {source.lastSuccessfulSync && (
                        <div className="flex justify-between text-slate-600">
                          <span>Last Sync:</span>
                          <span className="text-slate-700 font-mono text-[11px]">
                            {new Date(source.lastSuccessfulSync).toLocaleString('en-IN')}
                          </span>
                        </div>
                      )}
                    </div>

                    {probe && (
                      <div className={`p-2.5 rounded-lg text-xs flex items-center justify-between border ${
                        probe.success ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800'
                      }`}>
                        <div className="flex items-center gap-1.5 font-medium">
                          {probe.success ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertTriangle className="w-3.5 h-3.5 text-red-600" />}
                          <span>{probe.message}</span>
                        </div>
                        <span className="font-mono text-[10px] font-bold">{probe.latencyMs}ms</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleTestConnection(source.id)}
                        disabled={isTesting}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                      >
                        <Wifi className={`w-3.5 h-3.5 ${isTesting ? 'animate-pulse text-indigo-600' : ''}`} />
                        {isTesting ? 'Testing...' : 'Test Probe'}
                      </button>
                      <button
                        onClick={() => handleOpenEditSource(source)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-slate-600 hover:text-slate-900 text-xs font-medium rounded-lg hover:bg-slate-100 transition-colors"
                        title="Configure source settings"
                      >
                        <Settings className="w-3.5 h-3.5" />
                        Configure
                      </button>
                    </div>

                    {(source.id === 'BhoomiRashi' || source.id === 'LACRRIS') && (
                      <button
                        onClick={() => handleTriggerSync(source.id as any)}
                        disabled={isSyncingThis}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingThis ? 'animate-spin' : ''}`} />
                        {isSyncingThis ? 'Syncing...' : 'Sync Now'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Edit Source Config Modal */}
          {editingSource && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Settings className="w-5 h-5 text-slate-700" />
                    Configure {editingSource.name}
                  </h3>
                  <button onClick={() => setEditingSource(null)} className="text-slate-400 hover:text-slate-600">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Base API URL</label>
                    <input
                      type="text"
                      value={editForm.baseUrl}
                      onChange={e => setEditForm(prev => ({ ...prev, baseUrl: e.target.value }))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">API Endpoint Path</label>
                    <input
                      type="text"
                      value={editForm.apiEndpoint}
                      onChange={e => setEditForm(prev => ({ ...prev, apiEndpoint: e.target.value }))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Poll Interval (Minutes)</label>
                    <input
                      type="number"
                      min={5}
                      max={1440}
                      value={editForm.syncIntervalMinutes}
                      onChange={e => setEditForm(prev => ({ ...prev, syncIntervalMinutes: parseInt(e.target.value, 10) || 60 }))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">API Authorization Key / Token</label>
                    <input
                      type="password"
                      value={editForm.apiKey}
                      onChange={e => setEditForm(prev => ({ ...prev, apiKey: e.target.value }))}
                      placeholder="Optional bearer token or API key"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <input
                      type="checkbox"
                      id="enabled-checkbox"
                      checked={editForm.enabled}
                      onChange={e => setEditForm(prev => ({ ...prev, enabled: e.target.checked }))}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <label htmlFor="enabled-checkbox" className="font-semibold text-slate-700 cursor-pointer">
                      Enable Automated Background Synchronization
                    </label>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                  <button
                    onClick={() => setEditingSource(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveSourceConfig}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: FILE INGESTION & SCHEMA MAPPING */}
      {activeTab === 'import' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <UploadCloud className="w-5 h-5 text-indigo-600" />
                Multi-Format Dataset Ingestion (CSV / XLSX / XLS / JSON)
              </h3>
              <p className="text-xs text-slate-500">
                Upload district-level spreadsheets or official gazettes. Columns are dynamically parsed and mapped to the canonical BhoomiDrishti schema.
              </p>
            </div>
            <button
              onClick={loadSampleCsv}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold underline self-start sm:self-auto"
            >
              Load Sample MoRTH Template
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* File Picker & Rules */}
            <div className="lg:col-span-1 space-y-4">
              <div className="border-2 border-dashed border-slate-200 hover:border-indigo-400 rounded-xl p-6 text-center transition-colors bg-slate-50/50">
                <input
                  type="file"
                  id="multi-file-upload-input"
                  accept=".csv,.xlsx,.xls,.json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <label htmlFor="multi-file-upload-input" className="cursor-pointer block">
                  <FileSpreadsheet className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <span className="text-xs font-semibold text-indigo-600 hover:underline block">
                    Click to select CSV, Excel or JSON
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-1">
                    Supports .xlsx, .xls, .csv, and .json
                  </span>
                </label>
                {importFileName && (
                  <div className="mt-3 text-xs bg-indigo-50 text-indigo-800 py-1.5 px-3 rounded-md font-medium truncate flex items-center justify-center gap-1.5">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{importFileName}</span>
                  </div>
                )}
              </div>

              <div className="space-y-2 text-xs text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Validation Rules & Integrity:
                </div>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600 leading-relaxed">
                  <li>Acquired land cannot exceed total required land.</li>
                  <li>Compensation disbursed cannot exceed sanctioned compensation.</li>
                  <li>SHA-256 fingerprinting prevents redundant database writes.</li>
                  <li>Geocoding centroid resolution auto-places projects in target district.</li>
                  <li>ML Delay Risk score automatically computed on ingestion.</li>
                </ul>
              </div>
            </div>

            {/* Column Mapping & Preview */}
            <div className="lg:col-span-2 space-y-4">
              {isInspecting ? (
                <div className="py-12 text-center text-xs text-slate-500">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-600" />
                  Inspecting spreadsheet headers and rows...
                </div>
              ) : inspectionResult ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                    <div>
                      <span className="font-bold text-slate-800">{inspectionResult.fileName}</span>
                      <span className="text-slate-500 ml-2 font-mono">({inspectionResult.totalRows} records found)</span>
                    </div>
                    <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-semibold rounded text-[10px]">
                      {inspectionResult.fileType.toUpperCase()} Format
                    </span>
                  </div>

                  {/* Mapping Selectors */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                      Schema Column Mapping (Source → Canonical Model)
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs max-h-60 overflow-y-auto">
                      {CANONICAL_FIELDS.map(f => (
                        <div key={f.key} className="flex flex-col gap-1">
                          <label className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                            {f.label}
                            {f.required && <span className="text-red-500 font-bold">*</span>}
                          </label>
                          <select
                            value={columnMapping[f.key] || ''}
                            onChange={e => setColumnMapping(prev => ({ ...prev, [f.key]: e.target.value }))}
                            className="w-full px-2 py-1.5 text-xs bg-white border border-slate-300 rounded font-medium focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                          >
                            <option value="">-- Do not map --</option>
                            {inspectionResult.detectedColumns.map(col => (
                              <option key={col} value={col}>
                                {col}
                              </option>
                            ))}
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Sample 3 Rows Preview */}
                  {inspectionResult.sampleRows.length > 0 && (
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 mb-1.5">Sample Rows Preview:</h4>
                      <div className="overflow-x-auto border border-slate-200 rounded-lg">
                        <table className="w-full text-left text-[11px]">
                          <thead>
                            <tr className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                              {inspectionResult.detectedColumns.slice(0, 6).map(c => (
                                <th key={c} className="py-1.5 px-2.5 truncate max-w-[120px]">{c}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-slate-600 font-mono">
                            {inspectionResult.sampleRows.slice(0, 3).map((r, i) => (
                              <tr key={i}>
                                {inspectionResult.detectedColumns.slice(0, 6).map(c => (
                                  <td key={c} className="py-1.5 px-2.5 truncate max-w-[120px]">{String(r[c] ?? '')}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      onClick={() => {
                        setImportContent('');
                        setImportFileName('');
                        setInspectionResult(null);
                      }}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleImportSubmit}
                      disabled={isImporting}
                      className="inline-flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
                    >
                      {isImporting ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Ingesting & Validating...
                        </>
                      ) : (
                        <>
                          <UploadCloud className="w-3.5 h-3.5" />
                          Confirm & Ingest Mapped Dataset
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span className="font-semibold text-slate-700">Direct CSV / JSON Text Paste</span>
                  </div>
                  <textarea
                    value={importContent}
                    onChange={(e) => {
                      setImportContent(e.target.value);
                      if (e.target.value.length > 30) {
                        runFileInspection(e.target.value, importType, 'pasted_text.csv');
                      }
                    }}
                    placeholder="Paste official CSV rows or JSON array here to inspect and map..."
                    rows={8}
                    className="w-full font-mono text-xs p-3 bg-slate-900 text-emerald-400 rounded-lg border border-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                  <div className="flex justify-end">
                    <button
                      onClick={() => runFileInspection(importContent, importType, 'manual_paste.csv')}
                      disabled={!importContent}
                      className="px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs"
                    >
                      Inspect Pasted Payload
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: VALIDATION ERRORS */}
      {activeTab === 'validation' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600" />
                Data Quality & Validation Error Log
              </h3>
              <p className="text-xs text-slate-500">
                Any records failing statutory business rules (e.g. negative compensation, land overflow) are safely logged here without halting valid records.
              </p>
            </div>
          </div>

          {validationErrors.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-xl border border-slate-100">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <div className="text-sm font-bold text-slate-800">No Validation Errors Logged</div>
              <p className="text-xs text-slate-500 mt-1">All processed records satisfy statutory schema and consistency constraints.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                    <th className="py-2.5 px-3">Row #</th>
                    <th className="py-2.5 px-3">Source</th>
                    <th className="py-2.5 px-3">Project / ID</th>
                    <th className="py-2.5 px-3">Field</th>
                    <th className="py-2.5 px-3">Severity</th>
                    <th className="py-2.5 px-3">Error Message</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {validationErrors.map((err, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">{err.rowNumber}</td>
                      <td className="py-2.5 px-3 font-medium">{err.source}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-800">{err.projectIdentifier || 'Unknown'}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-indigo-700 font-semibold">{err.fieldName}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          err.severity === 'ERROR' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {err.severity}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{err.errorMessage}</td>
                      <td className="py-2.5 px-3 text-slate-500 text-[11px] font-mono">
                        {err.createdAt ? new Date(err.createdAt).toLocaleTimeString('en-IN') : 'Recent'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SYNC RUN HISTORY */}
      {activeTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-5 h-5 text-slate-700" />
                Synchronization & Ingestion Run Log
              </h3>
              <p className="text-xs text-slate-500">
                Persistent history of all automated API synchronizations and official dataset imports.
              </p>
            </div>
          </div>

          {history.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              No synchronization history recorded yet. Trigger a sync above to log runs.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                    <th className="py-2.5 px-3">Run ID</th>
                    <th className="py-2.5 px-3">Source</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Valid / Total</th>
                    <th className="py-2.5 px-3">Inserted</th>
                    <th className="py-2.5 px-3">Updated</th>
                    <th className="py-2.5 px-3">Duration</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {history.map((h) => (
                    <tr key={h.syncId} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-mono text-[11px] font-medium text-slate-900">{h.syncId}</td>
                      <td className="py-2.5 px-3 font-semibold">{h.source}</td>
                      <td className="py-2.5 px-3 text-slate-500">{new Date(h.startedAt).toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          h.status === 'SUCCESS' ? 'bg-emerald-100 text-emerald-800' :
                          h.status === 'PARTIAL' ? 'bg-amber-100 text-amber-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {h.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">{h.recordsValid} / {h.recordsReceived}</td>
                      <td className="py-2.5 px-3 text-emerald-700 font-semibold">+{h.recordsInserted}</td>
                      <td className="py-2.5 px-3 text-indigo-700 font-semibold">~{h.recordsUpdated}</td>
                      <td className="py-2.5 px-3 text-slate-500 font-mono">{h.durationMs}ms</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-slate-700" />
                Immutable System Audit Trail
              </h3>
              <p className="text-xs text-slate-500">
                Every record update, compensation change, and dataset ingestion is recorded with an audit fingerprint for statutory accountability.
              </p>
            </div>
          </div>

          {auditLogs.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              No audit records generated yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">User / System</th>
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Entity Type</th>
                    <th className="py-2.5 px-3">Entity ID</th>
                    <th className="py-2.5 px-3">Mutation Summary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                        {new Date(log.timestamp).toLocaleString('en-IN')}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">{log.userId}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-800">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{log.entityType}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-800">{log.entityId}</td>
                      <td className="py-2.5 px-3 text-slate-500 text-[11px] max-w-xs truncate font-mono">
                        {log.newValue ? log.newValue.slice(0, 60) + '...' : 'Recorded'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: DATABASE OVERVIEW & EXPORTS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">Total Project Records</span>
                <Database className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 mt-2">
                {overview?.totalProjects ?? dataSources.reduce((acc, s) => acc + (s.recordsReceived || 0), 0)}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Live in SQLite store</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">Storage Engine</span>
                <HardDrive className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-base font-bold text-slate-900 mt-2 truncate">
                {overview?.storageEngine || 'Node SQLite (WAL Mode)'}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">ACID Compliant</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">Active Sources</span>
                <Activity className="w-4 h-4 text-orange-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 mt-2">
                {dataSources.filter(s => s.enabled).length} / {dataSources.length}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">MoRTH & DoLR Connected</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">Total Audit Logs</span>
                <ShieldCheck className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 mt-2">
                {auditLogs.length}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Recorded mutations</span>
            </div>
          </div>

          {/* Export Options Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Download className="w-5 h-5 text-indigo-600" />
              Official Dataset Export Facilities
            </h3>
            <p className="text-xs text-slate-500">
              Download complete or targeted subsets of land acquisition project intelligence for inter-ministerial review or statistical analysis.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
              <a
                href={api.getExportDownloadUrl('all', 'csv')}
                download
                className="p-3 rounded-lg border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/50 transition-all text-left block"
              >
                <div className="font-bold text-xs text-slate-900">All Projects (CSV)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Complete corridor records</div>
              </a>

              <a
                href={api.getExportDownloadUrl('all', 'json')}
                download
                className="p-3 rounded-lg border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/50 transition-all text-left block"
              >
                <div className="font-bold text-xs text-slate-900">All Projects (JSON)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Full nested schema</div>
              </a>

              <a
                href={api.getExportDownloadUrl('high_risk', 'csv')}
                download
                className="p-3 rounded-lg border border-slate-200 hover:border-red-400 hover:bg-red-50/50 transition-all text-left block"
              >
                <div className="font-bold text-xs text-red-900">High Risk Corridors (CSV)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Critical bottleneck projects</div>
              </a>

              <a
                href={api.getExportDownloadUrl('audit_logs', 'csv')}
                download
                className="p-3 rounded-lg border border-slate-200 hover:border-slate-400 hover:bg-slate-50 transition-all text-left block"
              >
                <div className="font-bold text-xs text-slate-900">Audit Logs (CSV)</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Provenance change trail</div>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Statutory Architecture Statement */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start gap-3">
        <Info className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-semibold text-slate-800">Compliance & Integrity Statement</div>
          <p className="text-[11px] leading-relaxed">
            BhoomiRashi and LACRRIS are separate Government of India systems governed by distinct statutory regimes.
            BhoomiRashi operates under the National Highways Act 1956 for MoRTH/NHAI, while LACRRIS operates under the RFCTLARR Act 2013 under DoLR.
            BhoomiDrishti ingests data via normalized canonical schemas, ensuring full traceability to official gazettes and orders with cryptographic verification.
          </p>
        </div>
      </div>
    </div>
  );
};
