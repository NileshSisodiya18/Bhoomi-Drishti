import React from 'react';
import { RiskLevel, StageStatus } from '../types.ts';

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
  showDot?: boolean;
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, className = '', showDot = true }) => {
  let colorClasses = '';
  let dotClass = '';
  let label = '';

  switch (level) {
    case 'HIGH':
      colorClasses = 'bg-red-50 text-red-700 border-red-200';
      dotClass = 'bg-red-600';
      label = 'HIGH RISK';
      break;
    case 'MEDIUM':
      colorClasses = 'bg-amber-50 text-amber-800 border-amber-200';
      dotClass = 'bg-amber-600';
      label = 'MEDIUM RISK';
      break;
    case 'LOW':
      colorClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200';
      dotClass = 'bg-emerald-600';
      label = 'LOW RISK';
      break;
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border tracking-wide uppercase ${colorClasses} ${className}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${dotClass}`} />}
      {label}
    </span>
  );
};

export const DataSourceBadge: React.FC<{
  source?: string;
  isSynthetic?: boolean;
  className?: string;
}> = ({ source, isSynthetic, className = '' }) => {
  if (isSynthetic === false || source === 'BhoomiRashi') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 tracking-wide uppercase shadow-2xs ${className}`}
        title="Live statutory data synchronized directly from MoRTH BhoomiRashi portal"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
        LIVE DATA
      </span>
    );
  }

  if (source === 'LACRRIS') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200 tracking-wide uppercase ${className}`}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
        LACRRIS
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-600 border border-slate-200 tracking-wide uppercase ${className}`}
      title="Illustrative SIH decision-support prototype dataset"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
      DEMO
    </span>
  );
};

export const StageStatusBadge: React.FC<{ status: StageStatus; className?: string }> = ({
  status,
  className = ''
}) => {
  let classes = '';
  switch (status) {
    case 'Completed':
      classes = 'bg-slate-100 text-slate-700 border-slate-300';
      break;
    case 'In Progress':
      classes = 'bg-blue-50 text-blue-700 border-blue-200';
      break;
    case 'Delayed':
      classes = 'bg-rose-50 text-rose-700 border-rose-200';
      break;
    case 'Pending':
      classes = 'bg-slate-50 text-slate-500 border-slate-200';
      break;
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${classes} ${className}`}>
      {status}
    </span>
  );
};

