import React, { useState, useEffect } from 'react';
import { X, Sliders, Bell, Database, Check, Cpu, Award } from 'lucide-react';
import { api } from '../services/apiClient.ts';
import { SystemStatus } from '../types.ts';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [status, setStatus] = useState<SystemStatus | null>(null);

  useEffect(() => {
    if (isOpen) {
      api.getSystemStatus().then(setStatus).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">System Architecture & Settings</h2>
              <p className="text-xs text-slate-500">Thresholds, database & predictive model</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Risk Thresholds */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Delay Risk Thresholds
          </label>
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2.5 bg-red-50/70 border border-red-200 rounded-lg">
              <span className="font-semibold text-red-800">High Risk Level</span>
              <span className="font-mono font-bold text-red-700">≥ 70% probability</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg">
              <span className="font-semibold text-amber-800">Medium Risk Level</span>
              <span className="font-mono font-bold text-amber-700">35% – 69% probability</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-lg">
              <span className="font-semibold text-emerald-800">On Track / Low Risk</span>
              <span className="font-mono font-bold text-emerald-700">&lt; 35% probability</span>
            </div>
          </div>
        </div>

        {/* ML Model Engine */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Predictive Model Engine
          </label>
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs text-slate-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-indigo-600" />
                <span className="font-semibold text-slate-900">{status?.modelType || 'Random Forest Classifier'}</span>
              </div>
              <span className="font-mono text-[11px] bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded font-medium">
                {status?.modelVersion || 'v1.2-RF'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-200/60 text-center">
              <div className="bg-white p-1.5 rounded border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Accuracy</div>
                <div className="text-xs font-bold text-slate-900">{((status?.modelAccuracy ?? 0.88) * 100).toFixed(1)}%</div>
              </div>
              <div className="bg-white p-1.5 rounded border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">F1 Score</div>
                <div className="text-xs font-bold text-slate-900">{((status?.modelF1 ?? 0.85) * 100).toFixed(1)}%</div>
              </div>
              <div className="bg-white p-1.5 rounded border border-slate-200">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">ROC-AUC</div>
                <div className="text-xs font-bold text-slate-900">{(status?.modelRocAuc ?? 0.883).toFixed(3)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Database & Data Source */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Data Storage & Provenance
          </label>
          <div className="flex items-start gap-2.5 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <Database className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <div className="font-semibold text-slate-900">
                {status?.database || 'SQLite (Ready for PostgreSQL/PostGIS)'}
              </div>
              <div className="text-[11px] text-slate-500">
                {status?.dataSource || 'Illustrative prototype dataset'} • {status?.totalProjects ?? 18} projects indexed
              </div>
            </div>
          </div>
        </div>

        {/* Administrative Escalation */}
        <div className="flex items-center justify-between text-xs text-slate-700 p-2 bg-slate-50 rounded-lg border border-slate-200">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-slate-500" />
            <span>Escalate Court Stays via Notification</span>
          </div>
          <span className="text-emerald-700 font-bold flex items-center gap-1">
            <Check className="w-3.5 h-3.5" /> Enabled
          </span>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold tracking-wide transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};
