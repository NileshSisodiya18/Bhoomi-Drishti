import React, { useState } from 'react';
import { DashboardSummary, Project } from '../types.ts';
import { RiskBadge, DataSourceBadge } from './StatusBadge.tsx';
import { InfoTooltip } from './common/InfoTooltip.tsx';
import { AccordionSection } from './common/AccordionSection.tsx';
import {
  ArrowRight,
  AlertTriangle,
  Clock,
  MapPin,
  Building2,
  Scale,
  IndianRupee,
  TreePine,
  FileWarning,
  Layers,
  CheckCircle2,
  ShieldAlert,
  ChevronRight,
  TrendingUp,
  Activity,
  Database
} from 'lucide-react';

interface DashboardViewProps {
  summary: DashboardSummary | null;
  loading: boolean;
  onSelectProject: (projectId: string) => void;
  onViewAllAlerts: () => void;
  onViewAllProjects: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summary,
  loading,
  onSelectProject,
  onViewAllAlerts,
  onViewAllProjects
}) => {
  const [selectedStateFilter, setSelectedStateFilter] = useState<string>('ALL');
  const [bottlenecksOpen, setBottlenecksOpen] = useState<boolean>(true);

  if (loading || !summary) {
    return (
      <div className="space-y-6 max-w-7xl mx-auto pb-12 animate-pulse">
        {/* Header skeleton */}
        <div className="h-8 w-64 bg-slate-200 rounded-md mb-2" />
        <div className="h-4 w-96 bg-slate-200 rounded-md mb-6" />

        {/* 5 KPI cards skeleton */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-xl p-4" />
          ))}
        </div>

        {/* Two-column skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
          <div className="lg:col-span-5 h-72 bg-white border border-slate-200 rounded-xl" />
          <div className="lg:col-span-7 h-72 bg-white border border-slate-200 rounded-xl" />
        </div>
      </div>
    );
  }

  // Derive counts & rates
  const total = summary.totalProjects || 1;
  const highCount = summary.highRiskCount || 0;
  const mediumCount = summary.mediumRiskCount || 0;
  const lowCount = summary.onTrackCount || 0;
  const attentionCount = summary.highRiskProjects?.length || highCount;

  const highPct = Math.round((highCount / total) * 100);
  const mediumPct = Math.round((mediumCount / total) * 100);
  const lowPct = Math.max(0, 100 - highPct - mediumPct);

  // States breakdown
  const states = summary.stateBreakdown || [];
  const filteredStates = selectedStateFilter === 'ALL'
    ? states
    : states.filter(s => s.state === selectedStateFilter);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Executive Top Header (Section 11) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight">
              BHOOMI-DRISHTI
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-900 border border-blue-200 font-semibold">
              MoRTH • Live Grid
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              Decision Support System
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 font-medium">
            Land Acquisition Monitoring & Delay Prediction System
          </p>
        </div>

        {/* Freshness & Action Indicator */}
        <div className="flex items-center gap-2 text-xs text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-2xs self-start sm:self-auto">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-medium text-slate-700">Statutory Data: Synchronized</span>
          <InfoTooltip
            title="Data Freshness"
            content="Active project statistics are synchronized with authentic MoRTH BhoomiRashi and state revenue records."
          />
        </div>
      </div>

      {/* 2. Compact 5-KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Projects */}
        <div
          id="kpi-total-projects"
          className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>Total Projects</span>
            <InfoTooltip content="Total national highway and infrastructure acquisition packages monitored." />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono">
              {summary.totalProjects}
            </span>
            <span className="text-xs text-slate-500 font-medium">packages</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 truncate">
            {summary.totalLandRequiredHa?.toLocaleString()} Ha required
          </p>
        </div>

        {/* High Risk */}
        <div
          id="kpi-high-risk"
          className="bg-white border border-red-200/80 rounded-xl p-4 shadow-2xs hover:border-red-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-red-700 uppercase tracking-wider">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
              High Risk
            </span>
            <InfoTooltip content="Projects with delay probability ≥ 70% or active court injunctions." />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-red-700 font-mono">
              {highCount}
            </span>
            <span className="text-xs text-red-600 font-medium">({highPct}%)</span>
          </div>
          <p className="text-[11px] text-red-600/80 mt-1 truncate font-medium">
            Immediate review needed
          </p>
        </div>

        {/* Medium Risk */}
        <div
          id="kpi-medium-risk"
          className="bg-white border border-amber-200/80 rounded-xl p-4 shadow-2xs hover:border-amber-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-amber-800 uppercase tracking-wider">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
              Medium Risk
            </span>
            <InfoTooltip content="Projects with delay probability between 40% and 69%." />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-amber-800 font-mono">
              {mediumCount}
            </span>
            <span className="text-xs text-amber-700 font-medium">({mediumPct}%)</span>
          </div>
          <p className="text-[11px] text-amber-700 mt-1 truncate">
            Clearance tracking active
          </p>
        </div>

        {/* Low Risk / On Track */}
        <div
          id="kpi-low-risk"
          className="bg-white border border-emerald-200/80 rounded-xl p-4 shadow-2xs hover:border-emerald-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-emerald-800 uppercase tracking-wider">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
              Low Risk
            </span>
            <InfoTooltip content="Projects proceeding within statutory milestone schedules (< 40% delay risk)." />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-800 font-mono">
              {lowCount}
            </span>
            <span className="text-xs text-emerald-700 font-medium">({lowPct}%)</span>
          </div>
          <p className="text-[11px] text-emerald-700 mt-1 truncate">
            Normal progression
          </p>
        </div>

        {/* Projects Requiring Attention */}
        <div
          id="kpi-attention"
          className="bg-white border border-blue-200/80 rounded-xl p-4 shadow-2xs hover:border-blue-300 transition-colors col-span-2 sm:col-span-1"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-blue-900 uppercase tracking-wider">
            <span>Action Queue</span>
            <InfoTooltip content="Projects with pending court stays, >50% undisbursed funds, or stage clearances." />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-bold text-blue-900 font-mono">
              {attentionCount}
            </span>
            <span className="text-xs text-blue-700 font-medium">critical</span>
          </div>
          <p className="text-[11px] text-blue-800 mt-1 truncate font-medium">
            Priority intervention
          </p>
        </div>
      </div>

      {/* 3. Main Analytical Grid: Risk Distribution & Priority Interventions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT: Risk Distribution Visualizer */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <span>National Risk Distribution</span>
                <InfoTooltip
                  title="Risk Model Distribution"
                  content="Ensemble risk categorization across the monitored national corridor portfolio."
                />
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Calculated by calibrated Random Forest model</p>
            </div>
          </div>

          {/* Segmented Risk Progress Bar */}
          <div className="space-y-2">
            <div className="h-4 w-full bg-slate-100 rounded-md overflow-hidden flex shadow-inner">
              <div
                style={{ width: `${highPct}%` }}
                className="bg-red-600 transition-all duration-500"
                title={`High Risk: ${highCount} (${highPct}%)`}
              />
              <div
                style={{ width: `${mediumPct}%` }}
                className="bg-amber-500 transition-all duration-500"
                title={`Medium Risk: ${mediumCount} (${mediumPct}%)`}
              />
              <div
                style={{ width: `${lowPct}%` }}
                className="bg-emerald-600 transition-all duration-500"
                title={`Low Risk: ${lowCount} (${lowPct}%)`}
              />
            </div>

            {/* Legend with percentages */}
            <div className="grid grid-cols-3 gap-2 text-xs pt-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-red-600 shrink-0" />
                <span className="font-semibold text-slate-700">{highCount} High</span>
                <span className="text-slate-400">({highPct}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500 shrink-0" />
                <span className="font-semibold text-slate-700">{mediumCount} Med</span>
                <span className="text-slate-400">({mediumPct}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-600 shrink-0" />
                <span className="font-semibold text-slate-700">{lowCount} Low</span>
                <span className="text-slate-400">({lowPct}%)</span>
              </div>
            </div>
          </div>

          {/* Systemic Bottleneck Breakdown */}
          <div className="pt-2 border-t border-slate-100 space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Primary Bottleneck Triggers
              </h3>
              <button
                onClick={() => setBottlenecksOpen(!bottlenecksOpen)}
                className="text-xs text-slate-500 hover:text-slate-800 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>{bottlenecksOpen ? 'Collapse' : 'Expand'}</span>
                <span>{bottlenecksOpen ? '▲' : '▼'}</span>
              </button>
            </div>

            {bottlenecksOpen && (
              <div className="space-y-2 text-xs animate-in fade-in duration-150">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="flex items-center gap-2 text-slate-700 font-medium">
                    <IndianRupee className="w-3.5 h-3.5 text-amber-600" />
                    Compensation Disbursement Lag (&lt;60%)
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {summary.highRiskProjects.filter(p => p.compensationDisbursedPercent < 60).length} pkgs
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="flex items-center gap-2 text-slate-700 font-medium">
                    <Scale className="w-3.5 h-3.5 text-red-600" />
                    Active Judicial Court Injunction
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {summary.highRiskProjects.filter(p => p.hasCourtStay).length} pkgs
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="flex items-center gap-2 text-slate-700 font-medium">
                    <TreePine className="w-3.5 h-3.5 text-emerald-700" />
                    Forest Diversion Pending (Stage 2)
                  </span>
                  <span className="font-bold text-slate-900 font-mono">
                    {summary.highRiskProjects.filter(p => p.forestClearanceStage.includes('Pending')).length} pkgs
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Projects Requiring Immediate Attention */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span>Projects Requiring Immediate Attention</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
                  Priority Action
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                High-probability delays with active statutory or financial bottlenecks
              </p>
            </div>

            <button
              onClick={onViewAllProjects}
              className="text-xs font-semibold text-blue-900 hover:text-blue-950 flex items-center gap-1 transition-colors"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* List of high-priority projects */}
          <div className="space-y-2.5">
            {summary.highRiskProjects.slice(0, 4).map(proj => (
              <div
                key={proj.id}
                onClick={() => onSelectProject(proj.id)}
                className="p-3.5 rounded-lg border border-slate-200/90 hover:border-blue-400 bg-white hover:bg-slate-50/70 transition-all cursor-pointer group shadow-2xs"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                        {proj.sourceProjectId || proj.id}
                      </span>
                      <DataSourceBadge source={proj.source} isSynthetic={proj.isSynthetic} />
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {proj.district}, {proj.state}
                      </span>
                    </div>

                    <h4 className="text-xs sm:text-sm font-semibold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-1">
                      {proj.name}
                    </h4>

                    <p className="text-xs text-slate-500 flex items-center gap-1.5 line-clamp-1">
                      <span className="font-medium text-red-700">Bottleneck:</span>
                      <span>{proj.mainIssue}</span>
                    </p>
                  </div>

                  {/* Delay Risk Score Badge */}
                  <div className="text-right shrink-0 flex flex-col items-end">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-red-700 font-mono">
                        {proj.delayProbability}%
                      </span>
                      <RiskBadge level={proj.riskLevel} />
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 group-hover:text-blue-600 flex items-center gap-0.5 font-medium">
                      Review <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. State / District Trends Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">
              State & Regional Corridor Trends
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Acquisition distribution across state revenue jurisdictions
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Filter State:</span>
            <select
              value={selectedStateFilter}
              onChange={e => setSelectedStateFilter(e.target.value)}
              className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All States ({states.length})</option>
              {states.map(s => (
                <option key={s.state} value={s.state}>
                  {s.state} ({s.total} pkgs)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* State Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50/60">
                <th className="py-2.5 px-3">State / Jurisdiction</th>
                <th className="py-2.5 px-3 text-center">Total Packages</th>
                <th className="py-2.5 px-3 text-center">High Risk</th>
                <th className="py-2.5 px-3 text-center">Medium Risk</th>
                <th className="py-2.5 px-3 text-center">On Track</th>
                <th className="py-2.5 px-3 text-right">Risk Ratio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredStates.map(s => {
                const stateRiskPct = s.total > 0 ? Math.round(((s.high + s.medium) / s.total) * 100) : 0;
                return (
                  <tr key={s.state} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{s.state}</td>
                    <td className="py-2.5 px-3 text-center font-mono">{s.total}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`font-mono font-semibold ${s.high > 0 ? 'text-red-700' : 'text-slate-400'}`}>
                        {s.high}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`font-mono font-semibold ${s.medium > 0 ? 'text-amber-800' : 'text-slate-400'}`}>
                        {s.medium}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="font-mono font-semibold text-emerald-800">{s.low}</span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`font-mono font-semibold ${stateRiskPct > 50 ? 'text-red-700' : 'text-slate-600'}`}>
                        {stateRiskPct}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 5. Row 3: Two Column Layout: Alerts & Synchronizations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Recent Statutory Alerts & Escalations */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                Recent Statutory Escalations
              </h2>
            </div>
            <button
              onClick={onViewAllAlerts}
              className="text-xs font-semibold text-blue-900 hover:text-blue-950 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span>View All Alerts</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {summary.recentAlerts && summary.recentAlerts.length > 0 ? (
              summary.recentAlerts.slice(0, 3).map(alert => (
                <div
                  key={alert.id}
                  onClick={() => onSelectProject(alert.projectId)}
                  className="p-3 rounded-lg border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-blue-400 cursor-pointer transition-all space-y-1 group"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-red-700">{alert.type}</span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-slate-800 group-hover:text-blue-900 line-clamp-1">
                    {alert.projectName}
                  </p>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{alert.reason}</p>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">
                No active critical escalations reported.
              </div>
            )}
          </div>
        </div>

        {/* Right: Data Synchronization Status & Provenance */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-[#1E3A5F]" />
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                Live BhoomiRashi Ingestion Feed
              </h2>
            </div>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
              Connected
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-0.5">
              <span className="text-[11px] text-slate-500 font-medium">Last Portal Sync</span>
              <div className="text-sm font-bold text-slate-900 font-mono">
                {summary.lastSyncTime ? new Date(summary.lastSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Continuous'}
              </div>
              <p className="text-[10px] text-slate-400">MoRTH Public Service</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-0.5">
              <span className="text-[11px] text-slate-500 font-medium">Synchronized Packages</span>
              <div className="text-sm font-bold text-slate-900 font-mono">
                {summary.totalProjects} packages
              </div>
              <p className="text-[10px] text-emerald-700 font-medium">100% Validated</p>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-blue-50/60 border border-blue-100 text-xs text-slate-700 flex items-center justify-between">
            <div>
              <span className="font-semibold text-blue-950">Statutory Change Detection</span>
              <p className="text-[11px] text-slate-600">SHA-256 field hashing active across gazette notifications.</p>
            </div>
            <button
              onClick={() => onViewAllProjects()}
              className="px-2.5 py-1 bg-white hover:bg-slate-50 text-blue-900 text-xs font-semibold rounded border border-blue-200 transition-colors shrink-0 ml-3 cursor-pointer"
            >
              Inspect Hub
            </button>
          </div>
        </div>
      </div>

      {/* 6. Progressive Disclosure Accordion: Technical Architecture & Provenance */}
      <AccordionSection
        id="dashboard-provenance"
        title="Data Provenance & System Specifications"
        subtitle="Cryptographic verification, API bridge, and statutory decision support parameters"
        icon={Database}
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <span className="font-semibold text-slate-800">Primary Ingestion Source</span>
            <p className="text-slate-600 text-[11px]">
              MoRTH BhoomiRashi Public Portal (Section 3A, 3D, Sanction & User Compensation).
            </p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <span className="font-semibold text-slate-800">Predictive Engine</span>
            <p className="text-slate-600 text-[11px]">
              Random Forest Calibrated Decision Ensemble with SHAP feature attributions.
            </p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <span className="font-semibold text-slate-800">Tamper Evidence</span>
            <p className="text-slate-600 text-[11px]">
              SHA-256 canonical hashing across 17 statutory fields with historical audit logs.
            </p>
          </div>
        </div>
      </AccordionSection>
    </div>
  );
};
