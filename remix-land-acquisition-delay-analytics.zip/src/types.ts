export type RiskLevel = 'HIGH' | 'MEDIUM' | 'LOW';

export type AcquisitionStage =
  | 'Identification'
  | 'Verification'
  | 'Compensation'
  | 'Legal / Documentation'
  | 'Possession';

export type StageStatus = 'Completed' | 'In Progress' | 'Delayed' | 'Pending';

export interface StageProgress {
  stage: AcquisitionStage;
  status: StageStatus;
  progressPercent: number;
  completedDate?: string;
  notes?: string;
}

export interface RiskFactor {
  factor: string;
  impactScore?: number; // 0 to 100
  impactLevel?: 'High' | 'Medium' | 'Low';
  direction?: 'Increases risk' | 'Reduces risk' | 'Neutral';
  detail: string;
}

export interface AttentionItem {
  id: string;
  text: string;
  category: 'Compensation' | 'Legal' | 'Documentation' | 'R&R' | 'Milestone';
  severity: 'high' | 'medium' | 'low';
}

export interface Project {
  id: string;
  name: string;
  sector: 'National Highways' | 'Railways' | 'Metro Rail' | 'Industrial Corridors' | 'Energy & Grid';
  state: string;
  district: string;
  talukOrTehsil: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  currentStage: AcquisitionStage;
  stageStatus: StageStatus;
  riskLevel: RiskLevel;
  delayProbability: number; // 0 to 100 %
  delayVarianceMonths: number; // Forecast delay in months
  mainIssue: string;

  // Land statistics (in Hectares)
  totalLandRequiredHa: number;
  landAcquiredHa: number;
  pendingLandHa: number;
  privateLandHa: number;
  govtLandHa: number;
  forestLandHa: number;

  // Compensation metrics
  compensationSanctionedCr: number;
  compensationDisbursedCr: number;
  compensationDisbursedPercent: number;
  pendingCompensationCases: number;

  // Legal & Documentation
  unresolvedLegalCases: number;
  hasCourtStay: boolean;
  courtDetails?: string;
  incompleteDocumentsCount: number;
  forestClearanceStage: 'Not Required' | 'Stage 1 Approved' | 'Stage 2 Pending' | 'Stage 2 Approved';

  // Progress timeline
  stages: StageProgress[];

  // Explainable AI & Decision Support
  topRiskFactors: RiskFactor[];
  attentionItems: string[];
  recommendedActions: string[];

  lastUpdated: string;
  isSynthetic?: boolean;

  // Authentic Government Source Traceability
  source?: 'BhoomiRashi' | 'LACRRIS' | 'OfficialExport' | 'Demo';
  sourceProjectId?: string;
  sourceUrl?: string;
  act?: string;
  highwayNumber?: string;
  agency?: string;
  sourceLastUpdated?: string;
  ingestedAt?: string;
}

export interface ProjectHistoryItem {
  id: string;
  projectId: string;
  source: string;
  fieldChanged: string;
  oldValue: string;
  newValue: string;
  changedAt: string;
}

export interface SourceStatusItem {
  sourceName: string;
  sourceType: string;
  available: boolean;
  officialUrl: string;
  lastSuccessfulSync: string | null;
  lastAttempt: string | null;
  recordsAvailable: number;
  legalNotice: string;
  error?: string;
}

export interface SyncRunResponse {
  syncId: string;
  source: string;
  startedAt: string;
  completedAt: string;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED';
  recordsReceived: number;
  recordsValid: number;
  recordsInserted: number;
  recordsUpdated: number;
  recordsUnchanged: number;
  recordsFailed: number;
  validationIssuesCount: number;
  errorMessage?: string;
  durationMs: number;
}

export interface DashboardSummary {
  totalProjects: number;
  highRiskCount: number;
  mediumRiskCount: number;
  onTrackCount: number;
  totalLandRequiredHa: number;
  totalLandAcquiredHa: number;
  avgAcquisitionProgress: number;
  highRiskProjects: Project[];
  recentAlerts: AlertItem[];
  stateBreakdown?: { state: string; total: number; high: number; medium: number; low: number }[];
  stageBreakdown?: { stage: string; total: number; delayed: number }[];
  dataFreshness?: string;
  isSyntheticNotice?: string;
}

export interface PaginatedProjects {
  items: Project[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  availableStates: string[];
  availableDistricts: string[];
}

export interface SystemStatus {
  status: string;
  backend: string;
  database: string;
  totalProjects: number;
  dataSource: string;
  lastDataRefresh: string;
  modelVersion: string;
  modelType: string;
  modelAccuracy: number;
  modelF1: number;
  modelRocAuc: number;
}

export interface AlertItem {
  id: string;
  projectId: string;
  projectName: string;
  location: string;
  type: 'Risk Increased' | 'Compensation Delayed' | 'Court Stay Injunction' | 'Milestone Lapsed';
  riskChange: string; // e.g. 'Medium → High'
  reason: string;
  timestamp: string;
  status: 'New' | 'Acknowledged' | 'Resolved';
  recommendedAction: string;
}

export interface WhatIfRequest {
  projectId: string;
  compensationDisbursedPercent?: number;
  unresolvedLegalCases?: number;
  incompleteDocumentsCount?: number;
  hasCourtStay?: boolean;
  forestClearanceStage?: string;
}

export interface WhatIfResponse {
  projectId: string;
  projectName: string;
  currentRisk: {
    delayProbability: number;
    riskLevel: RiskLevel;
    delayVarianceMonths?: number;
  };
  scenarioRisk: {
    delayProbability: number;
    riskLevel: RiskLevel;
    delayVarianceMonths?: number;
  };
  simulatedRisk?: {
    delayProbability: number;
    riskLevel: RiskLevel;
    delayVarianceMonths: number;
  };
  riskChangePercentagePoints: number;
  primaryDrivers: string[];
  impactSummary?: string;
  disclaimer: string;
}

export type DataModeType = 'LIVE_API' | 'SYNCHRONIZED' | 'IMPORTED' | 'DEMO';

export interface DataSourceItem {
  id: string;
  name: string;
  type: 'API' | 'CSV' | 'XLSX' | 'JSON' | 'DATABASE' | 'MANUAL';
  baseUrl?: string;
  apiEndpoint?: string;
  description: string;
  enabled: boolean;
  status: 'CONNECTED' | 'SYNCING' | 'SUCCESS' | 'FAILED' | 'DISABLED' | 'NOT_CONFIGURED';
  authType: 'NONE' | 'API_KEY' | 'BEARER_TOKEN' | 'OAUTH';
  apiKey?: string;
  syncIntervalMinutes: number;
  lastSyncStarted?: string | null;
  lastSyncCompleted?: string | null;
  lastSuccessfulSync?: string | null;
  recordsReceived: number;
  recordsInserted: number;
  recordsUpdated: number;
  recordsUnchanged: number;
  recordsFailed: number;
  errorMessage?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface FileInspectionResult {
  fileName: string;
  fileType: 'csv' | 'xlsx' | 'xls' | 'json';
  totalRows: number;
  detectedColumns: string[];
  sampleRows: Record<string, any>[];
  suggestedMapping: Record<string, string>;
}

export interface DataValidationErrorItem {
  id?: string;
  syncId?: string;
  source: string;
  rowNumber: number;
  projectIdentifier?: string;
  fieldName: string;
  severity: 'ERROR' | 'WARNING';
  errorMessage: string;
  rawValue?: any;
  createdAt?: string;
}

export interface DataValidationReport {
  totalRows: number;
  validCount: number;
  warningsCount: number;
  errorsCount: number;
  errors: DataValidationErrorItem[];
}

export interface DatabaseOverview {
  totalProjects: number;
  totalRecords: number;
  databaseSizeKb: number;
  storageEngine: string;
  activeDataSource: string;
  dataMode: DataModeType;
  lastSuccessfulSync: string | null;
  byState: { state: string; count: number }[];
  byStage: { stage: string; count: number }[];
  byStatus: { status: string; count: number }[];
  byRiskCategory: { riskLevel: string; count: number }[];
}

export interface AuditLogItem {
  id: string;
  userId: string;
  action: string;
  entityType: string;
  entityId: string;
  oldValue?: string | null;
  newValue?: string | null;
  timestamp: string;
}

export interface ConnectionTestResult {
  sourceId?: string;
  sourceName?: string;
  success: boolean;
  httpStatus?: number;
  latencyMs: number;
  message: string;
  endpointTested?: string;
  timestamp?: string;
}

export interface SourceTestResult {
  sourceProjectId: string;
  sourceUrl: string;
  httpStatus: number;
  responseTimeMs: number;
  htmlLength: number;
  canonicalHash: string;
  parsingSuccess: boolean;
  validationSuccess: boolean;
  fieldsExtractedCount: number;
  status: string;
  reason?: string;
  fetchedAt: string;
  extractedSample: {
    projectName?: string;
    projectNumber?: string;
    state?: string;
    district?: string;
    implementingAgency?: string;
    highwayNumber?: string;
    landRequired?: number;
    landAvailable?: number;
    landToBeAcquired?: number;
    landAcquiredTillNow?: number;
    sanctionNumber?: string;
    sanctionDate?: string;
    sanctionAmount?: number;
    notificationsCount?: number;
  };
  note?: string;
  success: boolean;
}

