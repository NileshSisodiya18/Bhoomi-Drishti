import crypto from 'node:crypto';

/**
 * Deterministic Record Hash Generator
 * Evaluates core statutory, spatial, and financial parameters.
 * Produces a stable SHA-256 digest substring (16 hex chars).
 */
export function computeRecordHash(r: {
  name?: string;
  state?: string;
  district?: string;
  totalLandRequiredHa?: number;
  landAcquiredHa?: number;
  currentStage?: string;
  stageStatus?: string;
  compensationDisbursedPercent?: number;
  hasCourtStay?: boolean | number;
  unresolvedLegalCases?: number;
  incompleteDocumentsCount?: number;
  forestClearanceStage?: string;
  sourceLastUpdated?: string;
}): string {
  const parts = [
    (r.name || '').trim().toLowerCase(),
    (r.state || '').trim().toLowerCase(),
    (r.district || '').trim().toLowerCase(),
    Math.round((r.totalLandRequiredHa || 0) * 100) / 100,
    Math.round((r.landAcquiredHa || 0) * 100) / 100,
    (r.currentStage || '').trim(),
    (r.stageStatus || '').trim(),
    Math.round((r.compensationDisbursedPercent || 0) * 10) / 10,
    r.hasCourtStay ? 1 : 0,
    r.unresolvedLegalCases || 0,
    r.incompleteDocumentsCount || 0,
    (r.forestClearanceStage || '').trim(),
    (r.sourceLastUpdated || '').trim()
  ];
  return crypto.createHash('sha256').update(parts.join('|')).digest('hex').substring(0, 16);
}
