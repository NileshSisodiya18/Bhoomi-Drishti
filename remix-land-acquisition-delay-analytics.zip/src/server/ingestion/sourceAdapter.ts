/**
 * Abstract Government Data Source Adapter Interface
 * Enables BhoomiDrishti to support BhoomiRashi, LACRRIS, and Official File Imports
 * under a common normalized interface.
 */

import { CanonicalProjectRecord, GovernmentSourceType, SourceStatusInfo } from './types.ts';

export interface DataSourceFetchOptions {
  state?: string;
  district?: string;
  limit?: number;
  sinceTimestamp?: string;
}

export interface DataSourceFetchResult {
  source: GovernmentSourceType;
  records: Partial<CanonicalProjectRecord>[];
  totalFound: number;
  sourceTimestamp: string;
  isLive: boolean;
  metadata?: Record<string, any>;
}

export interface GovernmentDataSource {
  readonly sourceName: GovernmentSourceType;
  readonly officialPortalUrl: string;

  /**
   * Verify if the government data endpoint or authorized channel is accessible
   */
  testConnection(): Promise<{ connected: boolean; latencyMs: number; message: string }>;

  /**
   * Fetch project records from the configured data source
   */
  fetchProjects(options?: DataSourceFetchOptions): Promise<DataSourceFetchResult>;

  /**
   * Return metadata and availability status of the source
   */
  getSourceInfo(): Promise<SourceStatusInfo>;
}
