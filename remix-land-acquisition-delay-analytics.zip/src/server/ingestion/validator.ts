/**
 * Data Validator for Government Land Acquisition Ingestion
 * Validates mandatory fields, numeric constraints, and coordinate bounds.
 */

import { CanonicalProjectRecord, IngestionValidationResult, ValidationIssue } from './types.ts';

export const DISTRICT_COORDINATES: Record<string, [number, number]> = {
  'Ahmedabad': [23.0225, 72.5714],
  'Surat': [21.1702, 72.8311],
  'Navsari': [20.9467, 72.9520],
  'Vadodara': [22.3072, 73.1812],
  'Nashik': [19.9975, 73.7898],
  'Thane': [19.2183, 72.9781],
  'Ratnagiri': [16.9902, 73.3120],
  'Pune': [18.5204, 73.8567],
  'Nagpur': [21.1458, 79.0882],
  'Aurangabad': [19.8762, 75.3433],
  'Sambhajinagar': [19.8762, 75.3433],
  'Jaipur': [26.9124, 75.7873],
  'Alwar': [27.5530, 76.6346],
  'Ajmer': [26.4499, 74.6399],
  'Bhopal': [23.2599, 77.4126],
  'Indore': [22.7196, 75.8577],
  'Lucknow': [26.8467, 80.9462],
  'Kanpur': [26.4499, 80.3319],
  'Varanasi': [25.3176, 82.9739],
  'Patna': [25.5941, 85.1376],
  'Ranchi': [23.3441, 85.3096],
  'Dhanbad': [23.7957, 86.4304],
  'Raipur': [21.2514, 81.6296],
  'Kolkata': [22.5726, 88.3639],
  'Howrah': [22.5958, 88.2636],
  'Bengaluru': [12.9716, 77.5946],
  'Bangalore': [12.9716, 77.5946],
  'Hassan': [13.0033, 76.1004],
  'Mysuru': [12.2958, 76.6394],
  'Chennai': [13.0827, 80.2707],
  'Kanchipuram': [12.8342, 79.7036],
  'Hyderabad': [17.3850, 78.4867],
  'Visakhapatnam': [17.6868, 83.2185],
  'Bhubaneswar': [20.2961, 85.8245],
  'Cuttack': [20.4625, 85.8828],
  'Dehradun': [30.3165, 78.0322],
  'Haridwar': [29.9457, 78.1642],
  'Gurugram': [28.4595, 77.0266],
  'Faridabad': [28.4089, 77.3178],
  'Sonipat': [28.9931, 77.0151]
};

export function validateCanonicalProject(raw: Partial<CanonicalProjectRecord>): IngestionValidationResult {
  const issues: ValidationIssue[] = [];

  // Required identification
  if (!raw.name || typeof raw.name !== 'string' || raw.name.trim().length === 0) {
    issues.push({ field: 'name', value: raw.name, message: 'Project name is mandatory', severity: 'ERROR' });
  }

  if (!raw.sourceProjectId || typeof raw.sourceProjectId !== 'string' || raw.sourceProjectId.trim().length === 0) {
    issues.push({ field: 'sourceProjectId', value: raw.sourceProjectId, message: 'Source project identifier is mandatory', severity: 'ERROR' });
  }

  if (!raw.state || typeof raw.state !== 'string') {
    issues.push({ field: 'state', value: raw.state, message: 'State is mandatory', severity: 'ERROR' });
  }

  if (!raw.district || typeof raw.district !== 'string') {
    issues.push({ field: 'district', value: raw.district, message: 'District is mandatory', severity: 'ERROR' });
  }

  // Numeric sanity checks
  const totalLand = Number(raw.totalLandRequiredHa);
  if (isNaN(totalLand) || totalLand <= 0) {
    issues.push({ field: 'totalLandRequiredHa', value: raw.totalLandRequiredHa, message: 'Total land required must be a positive number', severity: 'ERROR' });
  }

  const acquiredLand = Number(raw.landAcquiredHa ?? 0);
  if (isNaN(acquiredLand) || acquiredLand < 0) {
    issues.push({ field: 'landAcquiredHa', value: raw.landAcquiredHa, message: 'Acquired land cannot be negative', severity: 'ERROR' });
  } else if (totalLand > 0 && acquiredLand > totalLand * 1.5) {
    issues.push({ field: 'landAcquiredHa', value: acquiredLand, message: 'Acquired land significantly exceeds required corridor extent', severity: 'WARNING' });
  }

  const compSanctioned = Number(raw.compensationSanctionedCr ?? 0);
  const compDisbursed = Number(raw.compensationDisbursedCr ?? 0);

  if (isNaN(compSanctioned) || compSanctioned < 0) {
    issues.push({ field: 'compensationSanctionedCr', value: raw.compensationSanctionedCr, message: 'Sanctioned compensation must be non-negative', severity: 'ERROR' });
  }
  if (isNaN(compDisbursed) || compDisbursed < 0) {
    issues.push({ field: 'compensationDisbursedCr', value: raw.compensationDisbursedCr, message: 'Disbursed compensation must be non-negative', severity: 'ERROR' });
  }

  // Coordinate verification
  let lat = Number(raw.latitude);
  let lng = Number(raw.longitude);
  let isDistrictCentroid = false;

  const isValidIndianCoord = !isNaN(lat) && !isNaN(lng) && lat >= 8.0 && lat <= 37.5 && lng >= 68.0 && lng <= 97.5;

  if (!isValidIndianCoord) {
    const districtKey = Object.keys(DISTRICT_COORDINATES).find(d => 
      raw.district?.toLowerCase().includes(d.toLowerCase())
    );
    if (districtKey) {
      const [cLat, cLng] = DISTRICT_COORDINATES[districtKey];
      lat = cLat;
      lng = cLng;
      isDistrictCentroid = true;
      issues.push({ field: 'coordinates', value: { lat: raw.latitude, lng: raw.longitude }, message: `Resolved coordinates using district centroid for ${raw.district}`, severity: 'WARNING' });
    } else {
      lat = 21.7679;
      lng = 78.8718;
      isDistrictCentroid = true;
      issues.push({ field: 'coordinates', value: { lat: raw.latitude, lng: raw.longitude }, message: 'Coordinates unavailable; approximated to National Geographic Center', severity: 'WARNING' });
    }
  }

  // Calculate percentage
  let disbursedPercent = Number(raw.compensationDisbursedPercent);
  if (isNaN(disbursedPercent) || disbursedPercent < 0) {
    if (compSanctioned > 0) {
      disbursedPercent = Math.min(100, Math.round((compDisbursed / compSanctioned) * 100));
    } else {
      disbursedPercent = 0;
    }
  }

  const hasErrors = issues.some(i => i.severity === 'ERROR');
  if (hasErrors) {
    return { isValid: false, issues };
  }

  const cleanSource = raw.source || 'OfficialExport';
  const cleanSourceId = String(raw.sourceProjectId || raw.id || `PROJ_${Date.now()}`);
  let normalizedId = raw.id;
  if (!normalizedId) {
    const sanitizedSourceId = cleanSourceId.replace(/[^a-zA-Z0-9_-]/g, '_');
    if (sanitizedSourceId.startsWith(`${cleanSource}_`)) {
      normalizedId = sanitizedSourceId;
    } else {
      normalizedId = `${cleanSource}_${sanitizedSourceId}`;
    }
  }

  const record: CanonicalProjectRecord = {
    id: normalizedId,
    source: cleanSource,
    sourceProjectId: cleanSourceId,
    sourceUrl: raw.sourceUrl,
    name: String(raw.name).trim(),
    highwayNumber: raw.highwayNumber ? String(raw.highwayNumber).trim() : undefined,
    state: String(raw.state).trim(),
    district: String(raw.district).trim(),
    talukOrTehsil: raw.talukOrTehsil ? String(raw.talukOrTehsil).trim() : 'District Sub-division',
    agency: raw.agency ? String(raw.agency).trim() : 'NHAI',
    landRequiringBody: raw.landRequiringBody ? String(raw.landRequiringBody).trim() : raw.agency,
    sector: raw.sector ? String(raw.sector).trim() : 'National Highways',
    act: raw.act || 'National Highways Act 1956',
    ruralUrban: raw.ruralUrban || 'Rural',
    totalLandRequiredHa: Math.round(totalLand * 100) / 100,
    landAcquiredHa: Math.round(acquiredLand * 100) / 100,
    privateLandHa: raw.privateLandHa !== undefined ? Number(raw.privateLandHa) : Math.round(totalLand * 0.7 * 100) / 100,
    govtLandHa: raw.govtLandHa !== undefined ? Number(raw.govtLandHa) : Math.round(totalLand * 0.2 * 100) / 100,
    forestLandHa: raw.forestLandHa !== undefined ? Number(raw.forestLandHa) : Math.round(totalLand * 0.1 * 100) / 100,
    compensationSanctionedCr: Math.round(compSanctioned * 100) / 100,
    compensationDisbursedCr: Math.round(compDisbursed * 100) / 100,
    compensationDisbursedPercent: Math.min(100, Math.max(0, Math.round(disbursedPercent))),
    pendingCompensationCases: Math.max(0, Number(raw.pendingCompensationCases ?? (compSanctioned > compDisbursed ? 12 : 0))),
    unresolvedLegalCases: Math.max(0, Number(raw.unresolvedLegalCases ?? (raw.hasCourtStay ? 3 : 0))),
    hasCourtStay: Boolean(raw.hasCourtStay),
    courtDetails: raw.courtDetails ? String(raw.courtDetails) : undefined,
    forestClearanceStage: raw.forestClearanceStage || 'Not Required',
    currentStage: raw.currentStage || 'Compensation',
    stageStatus: raw.stageStatus || (raw.hasCourtStay ? 'Delayed' : 'In Progress'),
    incompleteDocumentsCount: Math.max(0, Number(raw.incompleteDocumentsCount ?? 0)),
    latitude: Math.round(lat * 10000) / 10000,
    longitude: Math.round(lng * 10000) / 10000,
    isDistrictCentroid,
    notificationDate: raw.notificationDate,
    awardDate: raw.awardDate,
    possessionDate: raw.possessionDate,
    sourceLastUpdated: raw.sourceLastUpdated || new Date().toISOString(),
    ingestedAt: raw.ingestedAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isSynthetic: Boolean(raw.isSynthetic ?? false)
  };

  return { isValid: true, record, issues };
}
