/**
 * Central Data Ingestion & Synchronization Service for BhoomiDrishti
 * Coordinates source adapters, validation, normalization, deduplication,
 * idempotent upsert, change history auditing, validation error recording, and ML risk re-scoring.
 */

import { BhoomiRashiAdapter } from './bhoomiRashiAdapter.ts';
import { LACRRISAdapter } from './lacrrisAdapter.ts';
import { FileIngestionAdapter } from './fileIngestionAdapter.ts';
import { validateCanonicalProject } from './validator.ts';
import { 
  CanonicalProjectRecord, 
  GovernmentSourceType, 
  SyncRunSummary, 
  SourceStatusInfo, 
  ProjectHistoryRecord,
  ConnectionTestResult 
} from './types.ts';
import { 
  getDatabase, 
  updateDataSourceSyncStats, 
  insertValidationError, 
  insertAuditLog, 
  getDataSourceById 
} from '../database.ts';
import { predictDelayRisk } from '../mlModel.ts';
import { computeRecordHash } from '../hashUtil.ts';

export class SyncService {
  private static bhoomiRashi = new BhoomiRashiAdapter();
  private static lacrris = new LACRRISAdapter();

  /**
   * Test network/gateway connection to a configured data source
   */
  static async testConnection(sourceId: string): Promise<ConnectionTestResult> {
    const startMs = Date.now();
    const source = getDataSourceById(sourceId);

    if (!source) {
      return {
        sourceId,
        sourceName: sourceId,
        success: false,
        latencyMs: 0,
        message: `Data source with ID '${sourceId}' is not registered.`
      };
    }

    if (source.type === 'MANUAL') {
      return {
        sourceId,
        sourceName: source.name,
        success: true,
        latencyMs: 5,
        message: 'Manual administrative file ingestion portal is operational (supports CSV, XLSX, XLS, and JSON).'
      };
    }

    try {
      if (sourceId === 'bhoomirashi') {
        const info = await this.bhoomiRashi.getSourceInfo();
        const latencyMs = Date.now() - startMs;
        return {
          sourceId,
          sourceName: source.name,
          success: info.available,
          latencyMs,
          message: info.available 
            ? `Successfully established handshake with MoRTH BhoomiRashi Gateway (${info.recordsAvailable} gazette corridors detected).`
            : 'BhoomiRashi gateway returned maintenance status.'
        };
      } else if (sourceId === 'lacrris') {
        const info = await this.lacrris.getSourceInfo();
        const latencyMs = Date.now() - startMs;
        return {
          sourceId,
          sourceName: source.name,
          success: info.available,
          latencyMs,
          message: info.available 
            ? `Successfully connected to DoLR LACRRIS API (${info.recordsAvailable} RFCTLARR compliance feeds detected).`
            : 'LACRRIS gateway returned maintenance status.'
        };
      } else {
        // Custom API test
        if (!source.baseUrl) {
          return {
            sourceId,
            sourceName: source.name,
            success: false,
            latencyMs: Date.now() - startMs,
            message: 'Custom API base URL is not configured. Please enter a valid endpoint URL.'
          };
        }

        const testUrl = `${source.baseUrl.replace(/\/$/, '')}${source.apiEndpoint || ''}`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);

        try {
          const headers: Record<string, string> = { 'Accept': 'application/json' };
          if (source.authType === 'API_KEY' && source.apiKey) {
            headers['Authorization'] = `Bearer ${source.apiKey}`;
          }
          const resp = await fetch(testUrl, { signal: controller.signal, headers });
          clearTimeout(timeout);
          const latencyMs = Date.now() - startMs;
          return {
            sourceId,
            sourceName: source.name,
            success: resp.status < 500,
            latencyMs,
            message: resp.ok 
              ? `Connection verified (HTTP ${resp.status} in ${latencyMs}ms).` 
              : `Endpoint reachable but responded with HTTP ${resp.status}: ${resp.statusText}`
          };
        } catch (fetchErr: any) {
          clearTimeout(timeout);
          return {
            sourceId,
            sourceName: source.name,
            success: false,
            latencyMs: Date.now() - startMs,
            message: `Endpoint unreachable: ${fetchErr.message}`
          };
        }
      }
    } catch (err: any) {
      return {
        sourceId,
        sourceName: source.name,
        success: false,
        latencyMs: Date.now() - startMs,
        message: `Connection test error: ${err.message}`
      };
    }
  }

  /**
   * Run synchronization against an authorized government source
   */
  static async syncWithSource(sourceName: GovernmentSourceType = 'BhoomiRashi'): Promise<SyncRunSummary> {
    const startedAt = new Date().toISOString();
    const syncId = `SYNC_${sourceName.toUpperCase()}_${Date.now()}`;
    const startMs = Date.now();

    const db = getDatabase();

    const sourceId = sourceName === 'BhoomiRashi' ? 'bhoomirashi' : (sourceName === 'LACRRIS' ? 'lacrris' : 'custom_api');

    let rawRecords: Partial<CanonicalProjectRecord>[] = [];
    let sourceTimestamp = startedAt;

    try {
      if (sourceName === 'BhoomiRashi') {
        const result = await this.bhoomiRashi.fetchProjects();
        rawRecords = result.records;
        sourceTimestamp = result.sourceTimestamp;
      } else if (sourceName === 'LACRRIS') {
        const result = await this.lacrris.fetchProjects();
        rawRecords = result.records;
        sourceTimestamp = result.sourceTimestamp;
      } else {
        throw new Error(`Unsupported automated source: ${sourceName}. Use file import for custom datasets.`);
      }

      let recordsValid = 0;
      let recordsInserted = 0;
      let recordsUpdated = 0;
      let recordsUnchanged = 0;
      let recordsFailed = 0;
      let validationIssuesCount = 0;

      for (let idx = 0; idx < rawRecords.length; idx++) {
        const raw = rawRecords[idx];
        const val = validateCanonicalProject(raw);
        validationIssuesCount += val.issues.length;

        if (!val.isValid || !val.record) {
          recordsFailed++;
          // Record validation error in audit table
          for (const issue of val.issues) {
            insertValidationError({
              syncId,
              source: sourceName,
              rowNumber: idx + 1,
              projectIdentifier: raw.sourceProjectId || raw.name,
              fieldName: issue.field,
              severity: issue.severity,
              errorMessage: issue.message,
              rawValue: String(issue.value !== undefined ? issue.value : '')
            });
          }
          continue;
        }

        recordsValid++;
        const record = val.record;

        // Check if project exists by source + sourceProjectId or canonical ID
        const existingStmt = db.prepare(`
          SELECT * FROM projects WHERE (source = ? AND source_project_id = ?) OR id = ?
        `);
        const existing = existingStmt.get(record.source, record.sourceProjectId, record.id) as any;

        // Run ML model to calculate delay probability and risk level
        const mlScore = predictDelayRisk({
          compensationDisbursedPercent: record.compensationDisbursedPercent,
          hasCourtStay: record.hasCourtStay,
          forestClearanceStage: record.forestClearanceStage,
          incompleteDocumentsCount: record.incompleteDocumentsCount,
          unresolvedLegalCases: record.unresolvedLegalCases,
          totalLandRequiredHa: record.totalLandRequiredHa
        });

        // Compute deterministic record hash
        const recHash = computeRecordHash({
          name: record.name,
          state: record.state,
          district: record.district,
          totalLandRequiredHa: record.totalLandRequiredHa,
          landAcquiredHa: record.landAcquiredHa,
          currentStage: record.currentStage,
          stageStatus: record.stageStatus,
          compensationDisbursedPercent: record.compensationDisbursedPercent,
          hasCourtStay: record.hasCourtStay,
          unresolvedLegalCases: record.unresolvedLegalCases,
          incompleteDocumentsCount: record.incompleteDocumentsCount,
          forestClearanceStage: record.forestClearanceStage,
          sourceLastUpdated: record.sourceLastUpdated
        });

        if (!existing) {
          // INSERT new project
          this.insertCanonicalProject(db, record, mlScore, recHash);
          recordsInserted++;

          // Create audit record
          this.recordHistory(db, record.id, record.source, 'STATUS', 'NEW_ENTRY', 'INGESTED');
        } else {
          // Check for changes (Idempotent Update)
          const changes = this.detectFieldChanges(existing, record);

          if (changes.length > 0 || existing.record_hash !== recHash) {
            // Update record
            this.updateCanonicalProject(db, record, mlScore, existing.id, recHash);
            recordsUpdated++;

            // Record changes in audit log
            for (const ch of changes) {
              this.recordHistory(db, existing.id, record.source, ch.field, ch.oldVal, ch.newVal);
            }

            // Check if risk level shifted to trigger dynamic alert
            if (existing.risk_level !== mlScore.riskLevel && mlScore.riskLevel === 'HIGH') {
              this.createRiskAlert(db, record, existing.risk_level, mlScore.riskLevel, mlScore.delayProbability);
            }
          } else {
            recordsUnchanged++;
          }
        }
      }

      const completedAt = new Date().toISOString();
      const durationMs = Date.now() - startMs;

      const summary: SyncRunSummary = {
        syncId,
        source: sourceName,
        startedAt,
        completedAt,
        status: recordsFailed === 0 ? 'SUCCESS' : (recordsValid > 0 ? 'PARTIAL' : 'FAILED'),
        recordsReceived: rawRecords.length,
        recordsValid,
        recordsInserted,
        recordsUpdated,
        recordsUnchanged,
        recordsFailed,
        validationIssuesCount,
        durationMs
      };

      // Record sync run into sync_runs table and update system metadata
      this.recordSyncRun(db, summary);
      this.updateMetadata(db, sourceName, completedAt, summary.status);

      // Update data_sources table status
      updateDataSourceSyncStats(sourceId, {
        status: summary.status,
        recordsReceived: rawRecords.length,
        recordsInserted,
        recordsUpdated,
        recordsUnchanged,
        recordsFailed,
        errorMessage: null,
        startedAt,
        completedAt,
        lastSuccessfulSync: completedAt
      });

      insertAuditLog({
        id: `AUDIT_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId: 'system',
        action: 'SOURCE_SYNC',
        entityType: 'data_source',
        entityId: sourceId,
        newValue: JSON.stringify({ inserted: recordsInserted, updated: recordsUpdated, unchanged: recordsUnchanged, failed: recordsFailed }),
        timestamp: completedAt
      });

      return summary;
    } catch (err: any) {
      const completedAt = new Date().toISOString();
      const summary: SyncRunSummary = {
        syncId,
        source: sourceName,
        startedAt,
        completedAt,
        status: 'FAILED',
        recordsReceived: rawRecords.length,
        recordsValid: 0,
        recordsInserted: 0,
        recordsUpdated: 0,
        recordsUnchanged: 0,
        recordsFailed: rawRecords.length,
        validationIssuesCount: 1,
        errorMessage: err.message,
        durationMs: Date.now() - startMs
      };

      this.recordSyncRun(db, summary);

      updateDataSourceSyncStats(sourceId, {
        status: 'FAILED',
        recordsReceived: rawRecords.length,
        recordsInserted: 0,
        recordsUpdated: 0,
        recordsUnchanged: 0,
        recordsFailed: rawRecords.length,
        errorMessage: err.message,
        startedAt,
        completedAt
      });

      return summary;
    }
  }

  /**
   * Import official records with optional user-specified column mapping
   */
  static async importWithMapping(
    content: string,
    fileType: 'csv' | 'xlsx' | 'xls' | 'json',
    columnMapping?: Record<string, string>,
    fileName = 'upload'
  ): Promise<SyncRunSummary> {
    const startedAt = new Date().toISOString();
    const syncId = `SYNC_FILE_${Date.now()}`;
    const startMs = Date.now();
    const db = getDatabase();

    const parseResult = FileIngestionAdapter.validateAndMap(content, fileType, columnMapping, fileName);

    let recordsInserted = 0;
    let recordsUpdated = 0;
    let recordsUnchanged = 0;
    let recordsFailed = parseResult.rejectedRows.length;

    // Record rejected rows into data_validation_errors table
    for (const rej of parseResult.rejectedRows) {
      insertValidationError({
        syncId,
        source: 'OfficialExport',
        rowNumber: rej.rowIndex,
        projectIdentifier: rej.data?.name || rej.data?.sourceProjectId || `Row ${rej.rowIndex}`,
        fieldName: 'row_validation',
        severity: 'ERROR',
        errorMessage: rej.error,
        rawValue: JSON.stringify(rej.data)
      });
    }

    for (const record of parseResult.validRecords) {
      const existingStmt = db.prepare(`
        SELECT * FROM projects WHERE (source = ? AND source_project_id = ?) OR id = ?
      `);
      const existing = existingStmt.get(record.source, record.sourceProjectId, record.id) as any;

      const mlScore = predictDelayRisk({
        compensationDisbursedPercent: record.compensationDisbursedPercent,
        hasCourtStay: record.hasCourtStay,
        forestClearanceStage: record.forestClearanceStage,
        incompleteDocumentsCount: record.incompleteDocumentsCount,
        unresolvedLegalCases: record.unresolvedLegalCases,
        totalLandRequiredHa: record.totalLandRequiredHa
      });

      const recHash = computeRecordHash({
        name: record.name,
        state: record.state,
        district: record.district,
        totalLandRequiredHa: record.totalLandRequiredHa,
        landAcquiredHa: record.landAcquiredHa,
        currentStage: record.currentStage,
        stageStatus: record.stageStatus,
        compensationDisbursedPercent: record.compensationDisbursedPercent,
        hasCourtStay: record.hasCourtStay,
        unresolvedLegalCases: record.unresolvedLegalCases,
        incompleteDocumentsCount: record.incompleteDocumentsCount,
        forestClearanceStage: record.forestClearanceStage,
        sourceLastUpdated: record.sourceLastUpdated
      });

      if (!existing) {
        this.insertCanonicalProject(db, record, mlScore, recHash);
        recordsInserted++;
        this.recordHistory(db, record.id, record.source, 'STATUS', 'NEW_ENTRY', 'INGESTED');
      } else {
        const changes = this.detectFieldChanges(existing, record);
        if (changes.length > 0 || existing.record_hash !== recHash) {
          this.updateCanonicalProject(db, record, mlScore, existing.id, recHash);
          recordsUpdated++;
          for (const ch of changes) {
            this.recordHistory(db, existing.id, record.source, ch.field, ch.oldVal, ch.newVal);
          }
        } else {
          recordsUnchanged++;
        }
      }
    }

    const completedAt = new Date().toISOString();
    const summary: SyncRunSummary = {
      syncId,
      source: 'OfficialExport',
      startedAt,
      completedAt,
      status: recordsFailed === 0 ? 'SUCCESS' : (recordsInserted + recordsUpdated > 0 ? 'PARTIAL' : 'FAILED'),
      recordsReceived: parseResult.totalRows,
      recordsValid: parseResult.validRecords.length,
      recordsInserted,
      recordsUpdated,
      recordsUnchanged,
      recordsFailed,
      validationIssuesCount: parseResult.rejectedRows.length,
      durationMs: Date.now() - startMs
    };

    this.recordSyncRun(db, summary);
    this.updateMetadata(db, `File Import (${fileName})`, completedAt, summary.status);

    updateDataSourceSyncStats('file_import', {
      status: summary.status,
      recordsReceived: parseResult.totalRows,
      recordsInserted,
      recordsUpdated,
      recordsUnchanged,
      recordsFailed,
      errorMessage: null,
      startedAt,
      completedAt,
      lastSuccessfulSync: completedAt
    });

    insertAuditLog({
      id: `AUDIT_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: 'admin',
      action: 'FILE_IMPORTED',
      entityType: 'file_import',
      entityId: fileName,
      newValue: JSON.stringify({ inserted: recordsInserted, updated: recordsUpdated, unchanged: recordsUnchanged, failed: recordsFailed }),
      timestamp: completedAt
    });

    return summary;
  }

  /**
   * Import official records from file content (backward-compatible)
   */
  static async importFile(content: string, fileType: 'csv' | 'xlsx' | 'xls' | 'json', fileName = 'upload'): Promise<SyncRunSummary> {
    return this.importWithMapping(content, fileType, undefined, fileName);
  }

  /**
   * Return availability and legal notices for all configured government sources
   */
  static async getSourcesStatus(): Promise<SourceStatusInfo[]> {
    const brInfo = await this.bhoomiRashi.getSourceInfo();
    const lacInfo = await this.lacrris.getSourceInfo();

    const db = getDatabase();
    const fileCountStmt = db.prepare("SELECT COUNT(*) as c FROM projects WHERE source = 'OfficialExport'");
    const fileCount = (fileCountStmt.get() as any)?.c || 0;

    const fileInfo: SourceStatusInfo = {
      sourceName: 'OfficialExport',
      sourceType: 'Official File Import',
      available: true,
      officialUrl: 'https://data.gov.in/',
      lastSuccessfulSync: new Date().toISOString(),
      lastAttempt: new Date().toISOString(),
      recordsAvailable: fileCount,
      legalNotice: 'Official GoI CSV / JSON / XLSX reports uploaded through authorized administrator portal.'
    };

    return [brInfo, lacInfo, fileInfo];
  }

  // --- Database Operations Helper Methods ---

  private static insertCanonicalProject(
    db: any, 
    r: CanonicalProjectRecord, 
    ml: { delayProbability: number; riskLevel: string; projectedDelayVarianceMonths?: number },
    recordHash?: string
  ) {
    const pendingLand = Math.max(0, Math.round((r.totalLandRequiredHa - r.landAcquiredHa) * 100) / 100);
    const mainIssue = r.hasCourtStay
      ? (r.courtDetails || 'Judicial injunction on possession/award')
      : (r.compensationDisbursedPercent < 50
        ? `Compensation disbursement bottleneck (${r.compensationDisbursedPercent}%)`
        : (r.incompleteDocumentsCount > 20
          ? `Missing land title records (${r.incompleteDocumentsCount} cases)`
          : (r.forestClearanceStage.includes('Pending')
            ? 'Forest Clearance Stage-2 pending with MoEFCC'
            : 'Statutory process underway')));

    const now = new Date().toISOString();

    const insertStmt = db.prepare(`
      INSERT INTO projects (
        id, name, sector, state, district, taluk_or_tehsil,
        latitude, longitude, current_stage, stage_status,
        risk_level, delay_probability, main_issue,
        total_land_required_ha, land_acquired_ha, pending_land_ha,
        private_land_ha, govt_land_ha, forest_land_ha,
        compensation_sanctioned_cr, compensation_disbursed_cr, compensation_disbursed_percent,
        pending_compensation_cases, unresolved_legal_cases, has_court_stay, court_details,
        incomplete_documents_count, forest_clearance_stage, last_updated, is_synthetic,
        source, source_project_id, source_url, act, highway_number, agency,
        source_last_updated, ingested_at, record_hash, last_synced_at, created_at, updated_at
      ) VALUES (
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?
      )
    `);

    insertStmt.run(
      r.id, r.name, r.sector, r.state, r.district, r.talukOrTehsil || 'Sub-division',
      r.latitude, r.longitude, r.currentStage, r.stageStatus,
      ml.riskLevel, ml.delayProbability, mainIssue,
      r.totalLandRequiredHa, r.landAcquiredHa, pendingLand,
      r.privateLandHa || 0, r.govtLandHa || 0, r.forestLandHa || 0,
      r.compensationSanctionedCr, r.compensationDisbursedCr, r.compensationDisbursedPercent,
      r.pendingCompensationCases, r.unresolvedLegalCases, r.hasCourtStay ? 1 : 0, r.courtDetails || null,
      r.incompleteDocumentsCount, r.forestClearanceStage, r.updatedAt || now, r.isSynthetic ? 1 : 0,
      r.source, r.sourceProjectId, r.sourceUrl || null, r.act, r.highwayNumber || null, r.agency,
      r.sourceLastUpdated || null, r.ingestedAt || now, recordHash || null, now, now, now
    );
  }

  private static updateCanonicalProject(
    db: any, 
    r: CanonicalProjectRecord, 
    ml: { delayProbability: number; riskLevel: string }, 
    existingId: string,
    recordHash?: string
  ) {
    const pendingLand = Math.max(0, Math.round((r.totalLandRequiredHa - r.landAcquiredHa) * 100) / 100);
    const mainIssue = r.hasCourtStay
      ? (r.courtDetails || 'Judicial injunction on possession/award')
      : (r.compensationDisbursedPercent < 50
        ? `Compensation disbursement bottleneck (${r.compensationDisbursedPercent}%)`
        : (r.incompleteDocumentsCount > 20
          ? `Missing land title records (${r.incompleteDocumentsCount} cases)`
          : (r.forestClearanceStage.includes('Pending')
            ? 'Forest Clearance Stage-2 pending with MoEFCC'
            : 'Statutory process underway')));

    const now = new Date().toISOString();

    const updateStmt = db.prepare(`
      UPDATE projects SET
        name = ?, sector = ?, state = ?, district = ?, taluk_or_tehsil = ?,
        latitude = ?, longitude = ?, current_stage = ?, stage_status = ?,
        risk_level = ?, delay_probability = ?, main_issue = ?,
        total_land_required_ha = ?, land_acquired_ha = ?, pending_land_ha = ?,
        private_land_ha = ?, govt_land_ha = ?, forest_land_ha = ?,
        compensation_sanctioned_cr = ?, compensation_disbursed_cr = ?, compensation_disbursed_percent = ?,
        pending_compensation_cases = ?, unresolved_legal_cases = ?, has_court_stay = ?, court_details = ?,
        incomplete_documents_count = ?, forest_clearance_stage = ?, last_updated = ?, is_synthetic = ?,
        source = ?, source_project_id = ?, source_url = ?, act = ?, highway_number = ?, agency = ?,
        source_last_updated = ?, record_hash = ?, last_synced_at = ?, updated_at = ?
      WHERE id = ?
    `);

    updateStmt.run(
      r.name, r.sector, r.state, r.district, r.talukOrTehsil || 'Sub-division',
      r.latitude, r.longitude, r.currentStage, r.stageStatus,
      ml.riskLevel, ml.delayProbability, mainIssue,
      r.totalLandRequiredHa, r.landAcquiredHa, pendingLand,
      r.privateLandHa || 0, r.govtLandHa || 0, r.forestLandHa || 0,
      r.compensationSanctionedCr, r.compensationDisbursedCr, r.compensationDisbursedPercent,
      r.pendingCompensationCases, r.unresolvedLegalCases, r.hasCourtStay ? 1 : 0, r.courtDetails || null,
      r.incompleteDocumentsCount, r.forestClearanceStage, now, r.isSynthetic ? 1 : 0,
      r.source, r.sourceProjectId, r.sourceUrl || null, r.act, r.highwayNumber || null, r.agency,
      r.sourceLastUpdated || null, recordHash || null, now, now,
      existingId
    );
  }

  private static detectFieldChanges(existing: any, incoming: CanonicalProjectRecord): { field: string; oldVal: string; newVal: string }[] {
    const changes: { field: string; oldVal: string; newVal: string }[] = [];

    if (Math.abs(existing.compensation_disbursed_percent - incoming.compensationDisbursedPercent) > 0.1) {
      changes.push({
        field: 'compensation_disbursed_percent',
        oldVal: `${existing.compensation_disbursed_percent}%`,
        newVal: `${incoming.compensationDisbursedPercent}%`
      });
    }

    if (Math.abs(existing.land_acquired_ha - incoming.landAcquiredHa) > 0.5) {
      changes.push({
        field: 'land_acquired_ha',
        oldVal: `${existing.land_acquired_ha} Ha`,
        newVal: `${incoming.landAcquiredHa} Ha`
      });
    }

    const oldStay = existing.has_court_stay === 1;
    if (oldStay !== incoming.hasCourtStay) {
      changes.push({
        field: 'has_court_stay',
        oldVal: oldStay ? 'Active Stay' : 'No Stay',
        newVal: incoming.hasCourtStay ? 'Active Stay' : 'No Stay'
      });
    }

    if (existing.current_stage !== incoming.currentStage) {
      changes.push({
        field: 'current_stage',
        oldVal: existing.current_stage,
        newVal: incoming.currentStage
      });
    }

    return changes;
  }

  private static recordHistory(db: any, projectId: string, source: GovernmentSourceType, field: string, oldVal: string, newVal: string) {
    const id = `HIST_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    try {
      const stmt = db.prepare(`
        INSERT INTO project_history (id, project_id, source, field_changed, old_value, new_value, changed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(id, projectId, source, field, String(oldVal), String(newVal), now);
    } catch (e) {
      console.warn('[SyncService] Failed to record history:', e);
    }
  }

  private static createRiskAlert(db: any, r: CanonicalProjectRecord, oldRisk: string, newRisk: string, prob: number) {
    const id = `ALERT_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();
    try {
      const stmt = db.prepare(`
        INSERT INTO alerts (id, project_id, project_name, location, type, risk_change, reason, timestamp, status, recommended_action)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(
        id,
        r.id,
        r.name,
        `${r.district}, ${r.state}`,
        'Risk Increased',
        `${oldRisk} → ${newRisk}`,
        `Statutory sync detected probability escalation to ${Math.round(prob)}% based on updated compensation/litigation figures.`,
        now,
        'New',
        'Convene District Land Acquisition Committee (DLAC) review and expedite User compensation disbursement.'
      );
    } catch (e) {
      console.warn('[SyncService] Failed to create risk alert:', e);
    }
  }

  private static recordSyncRun(db: any, s: SyncRunSummary) {
    try {
      const stmt = db.prepare(`
        INSERT INTO sync_runs (
          sync_id, source, started_at, completed_at, status,
          records_received, records_valid, records_inserted, records_updated,
          records_unchanged, records_failed, duration_ms, error_message
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(
        s.syncId, s.source, s.startedAt, s.completedAt, s.status,
        s.recordsReceived, s.recordsValid, s.recordsInserted, s.recordsUpdated,
        s.recordsUnchanged, s.recordsFailed, s.durationMs, s.errorMessage || null
      );
    } catch (e) {
      console.warn('[SyncService] Failed to record sync run:', e);
    }
  }

  private static updateMetadata(db: any, source: string, timestamp: string, status: string) {
    try {
      const setStmt = db.prepare("INSERT OR REPLACE INTO system_metadata (key, value) VALUES (?, ?)");
      setStmt.run('last_data_refresh', timestamp);
      setStmt.run('dataset_source', source);
      setStmt.run('last_sync_status', status);
      setStmt.run('last_sync_timestamp', timestamp);
      setStmt.run('last_successful_sync', timestamp);
    } catch (e) {
      console.warn('[SyncService] Failed to update system metadata:', e);
    }
  }
}
