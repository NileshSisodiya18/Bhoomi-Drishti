/**
 * Canonical Data Types for Government Land Acquisition Ingestion
 * Covers BhoomiRashi (MoRTH/NHAI), LACRRIS (DoLR/RFCTLARR), and Official Reports.
 */

export type GovernmentSourceType = 'BhoomiRashi' | 'LACRRIS' | 'OfficialExport' | 'Demo';

export type StatutoryActType = 
  | 'National Highways Act 1956'
  | 'RFCTLARR Act 2013'
  | 'Railways Act 1989';

export interface CanonicalProjectRecord {
  id: string; // Canonical system ID: e.g. BR_NH_48_GJ_04_3D_2024
  source: GovernmentSourceType;
  sourceProjectId: string; // Original ID in government source: e.g. BR/NH-48/GJ-04/3D/2024
  sourceUrl?: string; // Official link to gazette / portal record
  name: string;
  highwayNumber?: string;
  state: string;
  district: string;
  talukOrTehsil?: string;
  agency: string;
  landRequiringBody?: string;
  sector: string;
  act: StatutoryActType;
  ruralUrban?: 'Rural' | 'Urban' | 'Mixed';
  
  totalLandRequiredHa: number;
  landAcquiredHa: number;
  privateLandHa?: number;
  govtLandHa?: number;
  forestLandHa?: number;
  
  compensationSanctionedCr: number;
  compensationDisbursedCr: number;
  compensationDisbursedPercent: number;
  pendingCompensationCases: number;
  
  unresolvedLegalCases: number;
  hasCourtStay: boolean;
  courtDetails?: string;
  forestClearanceStage: string;
  currentStage: string;
  stageStatus: string;
  incompleteDocumentsCount: number;
  
  // Geolocation
  latitude: number;
  longitude: number;
  isDistrictCentroid?: boolean;
  
  // Audit & Timestamps
  notificationDate?: string;
  awardDate?: string;
  possessionDate?: string;
  sourceLastUpdated?: string;
  ingestedAt: string;
  updatedAt: string;
  isSynthetic: boolean;
}

export interface ValidationIssue {
  field: string;
  value: any;
  message: string;
  severity: 'ERROR' | 'WARNING';
}

export interface IngestionValidationResult {
  isValid: boolean;
  record?: CanonicalProjectRecord;
  issues: ValidationIssue[];
}

export interface SyncRunSummary {
  syncId: string;
  source: GovernmentSourceType;
  startedAt: string;
  completedAt: string;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED';
  recordsReceived: number;
  recordsValid: number;
  recordsInserted: number;
  recordsUpdated: number;
  recordsUnchanged: number;
  recordsFailed: number;
  validationIssuesCount: number;
  errorMessage?: string;
  durationMs: number;
}

export interface ProjectHistoryRecord {
  id: string;
  projectId: string;
  source: GovernmentSourceType;
  fieldChanged: string;
  oldValue: string;
  newValue: string;
  changedAt: string;
}

export interface ConnectionTestResult {
  sourceId?: string;
  sourceName?: string;
  success: boolean;
  httpStatus?: number;
  latencyMs: number;
  message: string;
  endpointTested?: string;
  timestamp?: string;
}

export interface SourceStatusInfo {
  sourceName: GovernmentSourceType;
  sourceType: 'Authorized Ingestion & Periodic Sync' | 'Official File Import' | 'Demo';
  available: boolean;
  officialUrl: string;
  lastSuccessfulSync: string | null;
  lastAttempt: string | null;
  recordsAvailable: number;
  legalNotice: string;
  error?: string;
}
