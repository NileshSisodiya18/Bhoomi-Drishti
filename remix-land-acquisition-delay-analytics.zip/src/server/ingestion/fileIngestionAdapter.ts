/**
 * Official File Ingestion Adapter
 * Parses and ingests official Government of India CSV, XLSX, XLS, and JSON datasets
 * with column inspection, interactive field mapping, and strict schema validation.
 */

import * as XLSX from 'xlsx';
import { CanonicalProjectRecord, IngestionValidationResult } from './types.ts';
import { validateCanonicalProject } from './validator.ts';
import { computeRecordHash } from '../hashUtil.ts';

export interface FileInspectionResult {
  fileName: string;
  fileType: 'csv' | 'xlsx' | 'xls' | 'json';
  totalRows: number;
  detectedColumns: string[];
  sampleRows: Record<string, any>[];
  suggestedMapping: Record<string, string>;
}

export interface FileImportResult {
  source: 'OfficialExport';
  fileName: string;
  totalRows: number;
  validRecords: CanonicalProjectRecord[];
  rejectedRows: { rowIndex: number; error: string; data: any }[];
  warnings: string[];
}

export class FileIngestionAdapter {
  /**
   * Extract raw tabular rows from CSV, Excel (XLSX/XLS), or JSON
   */
  static extractRawRows(content: string, fileType: string): { headers: string[]; rows: Record<string, any>[] } {
    const fType = fileType.toLowerCase();

    if (fType === 'json') {
      let parsed: any;
      try {
        parsed = JSON.parse(content);
      } catch (err: any) {
        throw new Error(`Invalid JSON syntax: ${err.message}`);
      }
      if (!Array.isArray(parsed)) {
        if (parsed && Array.isArray(parsed.projects)) {
          parsed = parsed.projects;
        } else if (parsed && Array.isArray(parsed.data)) {
          parsed = parsed.data;
        } else {
          throw new Error('JSON data must be an array of project records');
        }
      }
      const headers: string[] = Array.from(new Set<string>(parsed.flatMap((item: any) => Object.keys(item || {}))));
      return { headers, rows: parsed };
    }

    if (fType === 'xlsx' || fType === 'xls') {
      try {
        // Read either base64 encoded buffer or binary
        let workbook;
        if (content.startsWith('data:') && content.includes('base64,')) {
          const b64 = content.split('base64,')[1];
          workbook = XLSX.read(b64, { type: 'base64' });
        } else {
          workbook = XLSX.read(content, { type: 'binary' });
        }
        const firstSheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[firstSheetName];
        const rawJson = XLSX.utils.sheet_to_json(sheet, { defval: '' }) as Record<string, any>[];
        if (rawJson.length === 0) {
          throw new Error('Excel sheet contains no data rows');
        }
        const headers = Object.keys(rawJson[0]);
        return { headers, rows: rawJson };
      } catch (err: any) {
        throw new Error(`Failed to parse Excel file: ${err.message}`);
      }
    }

    // Default to CSV / TSV
    const lines = content.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) {
      throw new Error('CSV file must contain a header row and at least one data row');
    }

    const headers = this.parseCsvRow(lines[0]);
    const rows: Record<string, any>[] = [];

    for (let i = 1; i < lines.length; i++) {
      const vals = this.parseCsvRow(lines[i]);
      if (vals.length === 0 || vals.every(v => v === '')) continue;
      const rowObj: Record<string, any> = {};
      headers.forEach((h, idx) => {
        rowObj[h] = vals[idx] !== undefined ? vals[idx] : '';
      });
      rows.push(rowObj);
    }

    return { headers, rows };
  }

  /**
   * Inspect file, detect headers, sample rows, and suggest column mapping
   */
  static inspectFile(content: string, fileType: string, fileName = 'dataset'): FileInspectionResult {
    const { headers, rows } = this.extractRawRows(content, fileType);
    const suggestedMapping: Record<string, string> = {};

    headers.forEach(h => {
      const norm = this.normalizeHeader(h);
      if (norm) {
        suggestedMapping[h] = norm;
      }
    });

    const sampleRows = rows.slice(0, 5);

    return {
      fileName,
      fileType: fileType as any,
      totalRows: rows.length,
      detectedColumns: headers,
      sampleRows,
      suggestedMapping
    };
  }

  /**
   * Validate and map raw content using explicit column mapping
   */
  static validateAndMap(
    content: string,
    fileType: string,
    columnMapping?: Record<string, string>,
    fileName = 'official_export'
  ): FileImportResult {
    const { rows } = this.extractRawRows(content, fileType);
    const validRecords: CanonicalProjectRecord[] = [];
    const rejectedRows: { rowIndex: number; error: string; data: any }[] = [];
    const warnings: string[] = [];

    rows.forEach((rawRow, index) => {
      // Map according to provided mapping or default normalization
      const mappedObj: Record<string, any> = {};
      if (columnMapping && Object.keys(columnMapping).length > 0) {
        for (const [srcCol, targetField] of Object.entries(columnMapping)) {
          if (targetField && targetField !== 'IGNORE' && rawRow[srcCol] !== undefined) {
            mappedObj[targetField] = rawRow[srcCol];
          }
        }
      } else {
        // Fallback auto-normalization
        for (const [key, val] of Object.entries(rawRow)) {
          const normKey = this.normalizeHeader(key);
          if (normKey) mappedObj[normKey] = val;
        }
      }

      const candidate = this.mapObjectToCanonical(mappedObj, `IMP_ROW_${index + 1}`);
      const valResult = validateCanonicalProject(candidate);

      if (valResult.isValid && valResult.record) {
        validRecords.push(valResult.record);
      } else {
        rejectedRows.push({
          rowIndex: index + 1,
          error: valResult.issues.map(iss => `${iss.field}: ${iss.message}`).join('; '),
          data: mappedObj
        });
      }
    });

    return {
      source: 'OfficialExport',
      fileName,
      totalRows: rows.length,
      validRecords,
      rejectedRows,
      warnings
    };
  }

  /**
   * Parse CSV content with flexible header normalization
   */
  static parseCsv(csvText: string, fileName = 'official_export.csv'): FileImportResult {
    return this.validateAndMap(csvText, 'csv', undefined, fileName);
  }

  /**
   * Parse JSON data (array of project objects)
   */
  static parseJson(jsonData: any[], fileName = 'official_export.json'): FileImportResult {
    return this.validateAndMap(JSON.stringify(jsonData), 'json', undefined, fileName);
  }

  private static parseCsvRow(row: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < row.length; i++) {
      const char = row[i];
      if (char === '"' || char === "'") {
        inQuotes = !inQuotes;
      } else if ((char === ',' || char === '\t') && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  }

  public static normalizeHeader(h: string): string {
    const clean = h.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (clean.includes('projectname') || clean === 'project' || clean === 'name' || clean === 'title' || clean.includes('corridor')) return 'name';
    if (clean.includes('sourceprojectid') || clean.includes('projectid') || clean === 'id' || clean.includes('gazetteno') || clean.includes('notificationno')) return 'sourceProjectId';
    if (clean.includes('highway') || clean === 'nhno' || clean === 'nh' || clean === 'corridorno') return 'highwayNumber';
    if (clean.includes('state') || clean === 'st') return 'state';
    if (clean.includes('district') || clean === 'dist') return 'district';
    if (clean.includes('taluk') || clean.includes('tehsil') || clean.includes('village')) return 'talukOrTehsil';
    if (clean.includes('agency') || clean.includes('requiringbody') || clean.includes('dept')) return 'agency';
    if (clean.includes('sector')) return 'sector';
    if (clean.includes('act') || clean.includes('law')) return 'act';
    if (clean.includes('rural') || clean.includes('urban') || clean.includes('area_type')) return 'ruralUrban';
    if (clean.includes('total') && (clean.includes('land') || clean.includes('area') || clean.includes('ha') || clean.includes('required'))) return 'totalLandRequiredHa';
    if (clean.includes('acquired') && (clean.includes('land') || clean.includes('ha') || clean.includes('possession'))) return 'landAcquiredHa';
    if (clean.includes('sanction') && clean.includes('comp')) return 'compensationSanctionedCr';
    if (clean.includes('disburs') && clean.includes('comp')) return 'compensationDisbursedCr';
    if (clean.includes('percent') || clean.includes('disbursedpercent')) return 'compensationDisbursedPercent';
    if (clean.includes('court') || clean.includes('stay') || clean.includes('injunction') || clean.includes('litigation')) return 'hasCourtStay';
    if (clean.includes('courtdetail') || clean.includes('casedetail')) return 'courtDetails';
    if (clean.includes('unresolved') || clean.includes('legalcase') || clean.includes('cases')) return 'unresolvedLegalCases';
    if (clean.includes('forest') || clean.includes('environment')) return 'forestClearanceStage';
    if (clean.includes('stage') || clean.includes('currentstage') || clean.includes('section')) return 'currentStage';
    if (clean.includes('incompletedoc') || clean.includes('missingdoc') || clean.includes('pendingdoc')) return 'incompleteDocumentsCount';
    if (clean.includes('lat') || clean.includes('latitude')) return 'latitude';
    if (clean.includes('lng') || clean.includes('lon') || clean.includes('longitude')) return 'longitude';
    return clean;
  }

  private static mapObjectToCanonical(obj: Record<string, any>, fallbackId: string): Partial<CanonicalProjectRecord> {
    const totalLand = parseFloat(obj.totalLandRequiredHa || obj.total_land_required_ha || obj.land_required || '0');
    const landAcquired = parseFloat(obj.landAcquiredHa || obj.land_acquired_ha || obj.land_acquired || '0');
    const compSanctioned = parseFloat(obj.compensationSanctionedCr || obj.compensation_sanctioned_cr || obj.compensation_sanctioned || '0');
    const compDisbursed = parseFloat(obj.compensationDisbursedCr || obj.compensation_disbursed_cr || obj.compensation_disbursed || '0');

    let courtStay = false;
    const rawStay = obj.hasCourtStay ?? obj.has_court_stay ?? obj.court_stay;
    if (typeof rawStay === 'boolean') courtStay = rawStay;
    else if (typeof rawStay === 'string') courtStay = ['yes', 'true', '1', 'stayed', 'stay'].includes(rawStay.toLowerCase());
    else if (typeof rawStay === 'number') courtStay = rawStay > 0;

    const compDisbursedPercent = compSanctioned > 0 
      ? Math.min(100, Math.round((compDisbursed / compSanctioned) * 100))
      : parseFloat(obj.compensationDisbursedPercent || obj.compensation_disbursed_percent || '0');

    const sourceLastUpdated = obj.sourceLastUpdated || obj.last_updated || new Date().toISOString().split('T')[0];

    return {
      source: 'OfficialExport',
      sourceProjectId: String(obj.sourceProjectId || obj.project_id || obj.id || fallbackId),
      name: String(obj.name || obj.project_name || obj.projectName || 'Unspecified Corridor Project'),
      highwayNumber: obj.highwayNumber || obj.highway_number || undefined,
      state: String(obj.state || 'Maharashtra'),
      district: String(obj.district || 'Thane'),
      talukOrTehsil: obj.talukOrTehsil || obj.taluk_or_tehsil || undefined,
      agency: String(obj.agency || 'NHAI'),
      sector: obj.sector || 'National Highways',
      act: obj.act || 'National Highways Act 1956',
      totalLandRequiredHa: isNaN(totalLand) || totalLand <= 0 ? 100 : totalLand,
      landAcquiredHa: isNaN(landAcquired) || landAcquired < 0 ? 0 : landAcquired,
      compensationSanctionedCr: isNaN(compSanctioned) || compSanctioned < 0 ? 0 : compSanctioned,
      compensationDisbursedCr: isNaN(compDisbursed) || compDisbursed < 0 ? 0 : compDisbursed,
      compensationDisbursedPercent: isNaN(compDisbursedPercent) ? 0 : compDisbursedPercent,
      hasCourtStay: courtStay,
      courtDetails: obj.courtDetails || obj.court_details || undefined,
      unresolvedLegalCases: parseInt(obj.unresolvedLegalCases || obj.unresolved_legal_cases || '0', 10) || (courtStay ? 1 : 0),
      forestClearanceStage: obj.forestClearanceStage || obj.forest_clearance_stage || 'Not Required',
      currentStage: obj.currentStage || obj.current_stage || 'Compensation',
      stageStatus: obj.stageStatus || (courtStay ? 'Delayed' : 'In Progress'),
      incompleteDocumentsCount: parseInt(obj.incompleteDocumentsCount || obj.incomplete_documents_count || '0', 10) || 0,
      latitude: parseFloat(obj.latitude || '0'),
      longitude: parseFloat(obj.longitude || '0'),
      sourceLastUpdated,
      isSynthetic: false
    };
  }
}

