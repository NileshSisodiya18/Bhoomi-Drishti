import { Project, RiskLevel, RiskFactor, WhatIfRequest, WhatIfResponse } from '../types.ts';
import { INITIAL_PROJECTS } from './dataset.ts';
import { predictDelayRisk, calculateDelayVarianceMonths } from './mlModel.ts';
import { getProjectById } from './database.ts';

export { calculateDelayVarianceMonths };

/**
 * Domain-grounded scoring model for Land Acquisition Delay Risk.
 * Uses the calibrated Random Forest Decision Ensemble (mlModel.ts) for consistency.
 */
export function calculateDelayScore(inputs: {
  compensationDisbursedPercent: number;
  hasCourtStay: boolean;
  unresolvedLegalCases: number;
  incompleteDocumentsCount: number;
  forestClearanceStage: string;
  totalLandRequiredHa?: number;
  pendingLandRatio?: number;
}): { delayProbability: number; riskLevel: RiskLevel; topFactors: RiskFactor[] } {
  const mlResult = predictDelayRisk({
    compensationDisbursedPercent: Math.max(0, Math.min(100, Number(inputs.compensationDisbursedPercent) || 0)),
    hasCourtStay: Boolean(inputs.hasCourtStay),
    unresolvedLegalCases: Math.max(0, Number(inputs.unresolvedLegalCases) || 0),
    incompleteDocumentsCount: Math.max(0, Number(inputs.incompleteDocumentsCount) || 0),
    forestClearanceStage: inputs.forestClearanceStage || 'Not Required',
    totalLandRequiredHa: inputs.totalLandRequiredHa
  });

  const topFactors: RiskFactor[] = mlResult.featureAttributions.map(fa => ({
    factor: fa.feature,
    impactScore: Math.min(95, Math.max(15, fa.contributionScore * 2)),
    detail: fa.detail
  }));

  if (topFactors.length === 0) {
    topFactors.push({
      factor: 'On-Schedule Milestones',
      impactScore: 15,
      detail: 'All primary statutory milestones and compensation disbursements are on track.'
    });
  }

  return {
    delayProbability: mlResult.delayProbability,
    riskLevel: mlResult.riskLevel,
    topFactors: topFactors.slice(0, 3)
  };
}

/**
 * Executes What-if scenario recalculation
 */
export function runWhatIfScenario(request: WhatIfRequest, existingProject?: Project): WhatIfResponse {
  let project = existingProject;
  if (!project) {
    try {
      project = getProjectById(request.projectId);
    } catch {}
  }
  if (!project) {
    project = INITIAL_PROJECTS.find(p => p.id === request.projectId);
  }

  if (!project) {
    throw new Error(`Project with ID ${request.projectId} not found`);
  }

  // Merge current values with scenario overrides, with strict boundary clamping
  const rawComp = request.compensationDisbursedPercent !== undefined
    ? Number(request.compensationDisbursedPercent)
    : project.compensationDisbursedPercent;
  const clampedComp = isNaN(rawComp) ? project.compensationDisbursedPercent : Math.max(0, Math.min(100, rawComp));

  const rawCases = request.unresolvedLegalCases !== undefined
    ? Number(request.unresolvedLegalCases)
    : project.unresolvedLegalCases;
  const clampedCases = isNaN(rawCases) ? project.unresolvedLegalCases : Math.max(0, Math.round(rawCases));

  const rawDocs = request.incompleteDocumentsCount !== undefined
    ? Number(request.incompleteDocumentsCount)
    : project.incompleteDocumentsCount;
  const clampedDocs = isNaN(rawDocs) ? project.incompleteDocumentsCount : Math.max(0, Math.round(rawDocs));

  const scenarioInputs = {
    compensationDisbursedPercent: clampedComp,
    hasCourtStay: request.hasCourtStay !== undefined ? Boolean(request.hasCourtStay) : project.hasCourtStay,
    unresolvedLegalCases: clampedCases,
    incompleteDocumentsCount: clampedDocs,
    forestClearanceStage: request.forestClearanceStage !== undefined ? request.forestClearanceStage : project.forestClearanceStage,
    totalLandRequiredHa: project.totalLandRequiredHa
  };

  const currentResult = {
    delayProbability: project.delayProbability,
    riskLevel: project.riskLevel
  };

  const scenarioResult = calculateDelayScore(scenarioInputs);
  const riskChange = scenarioResult.delayProbability - currentResult.delayProbability;

  const drivers: string[] = [];
  if (
    request.compensationDisbursedPercent !== undefined &&
    request.compensationDisbursedPercent !== project.compensationDisbursedPercent
  ) {
    const diff = request.compensationDisbursedPercent - project.compensationDisbursedPercent;
    drivers.push(
      `Compensation disbursement ${diff > 0 ? 'increased' : 'decreased'} by ${Math.abs(diff)}%`
    );
  }
  if (request.hasCourtStay !== undefined && request.hasCourtStay !== project.hasCourtStay) {
    drivers.push(
      request.hasCourtStay ? 'Active court stay instituted' : 'High Court stay successfully vacated'
    );
  }
  if (
    request.incompleteDocumentsCount !== undefined &&
    request.incompleteDocumentsCount !== project.incompleteDocumentsCount
  ) {
    drivers.push(
      `Pending documentation count adjusted to ${request.incompleteDocumentsCount}`
    );
  }
  if (
    request.forestClearanceStage !== undefined &&
    request.forestClearanceStage !== project.forestClearanceStage
  ) {
    drivers.push(`Forest clearance updated to ${request.forestClearanceStage}`);
  }

  if (drivers.length === 0) {
    drivers.push('Baseline parameters maintained with no variation.');
  }

  // Calculate baseline schedule variance
  const baselineVariance = (project.delayVarianceMonths && project.delayVarianceMonths > 0)
    ? project.delayVarianceMonths
    : calculateDelayVarianceMonths({
        delayProbability: currentResult.delayProbability,
        hasCourtStay: project.hasCourtStay,
        compensationDisbursedPercent: project.compensationDisbursedPercent,
        incompleteDocumentsCount: project.incompleteDocumentsCount,
        forestClearanceStage: project.forestClearanceStage,
        pendingLandHa: project.pendingLandHa,
        totalLandRequiredHa: project.totalLandRequiredHa
      });

  // Calculate counterfactual scenario schedule variance
  const scenarioVariance = calculateDelayVarianceMonths({
    delayProbability: scenarioResult.delayProbability,
    hasCourtStay: scenarioInputs.hasCourtStay,
    compensationDisbursedPercent: scenarioInputs.compensationDisbursedPercent,
    incompleteDocumentsCount: scenarioInputs.incompleteDocumentsCount,
    forestClearanceStage: scenarioInputs.forestClearanceStage,
    pendingLandHa: project.pendingLandHa,
    totalLandRequiredHa: project.totalLandRequiredHa
  });

  const monthsDiff = Math.round((baselineVariance - scenarioVariance) * 10) / 10;
  let impactSummary = '';
  if (monthsDiff > 0) {
    impactSummary = `Targeted interventions would recover approx ${monthsDiff} months of delay and de-escalate statutory risk by ${Math.abs(riskChange)} percentage points.`;
  } else if (monthsDiff < 0) {
    impactSummary = `Adverse scenario would increase estimated delay by approx ${Math.abs(monthsDiff)} months (+${Math.abs(riskChange)} percentage points).`;
  } else {
    impactSummary = `Simulated parameters maintain current schedule baseline with stable velocity.`;
  }

  const simulatedRiskObj = {
    delayProbability: scenarioResult.delayProbability,
    riskLevel: scenarioResult.riskLevel,
    delayVarianceMonths: scenarioVariance
  };

  return {
    projectId: project.id,
    projectName: project.name,
    currentRisk: {
      delayProbability: currentResult.delayProbability,
      riskLevel: currentResult.riskLevel,
      delayVarianceMonths: baselineVariance
    },
    scenarioRisk: simulatedRiskObj,
    simulatedRisk: simulatedRiskObj,
    riskChangePercentagePoints: riskChange,
    primaryDrivers: drivers,
    impactSummary,
    disclaimer:
      'Model-based scenario estimate for administrative planning only. Does not guarantee real-world outcome.'
  };
}
