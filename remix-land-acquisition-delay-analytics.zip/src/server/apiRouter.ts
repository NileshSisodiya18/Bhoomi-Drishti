import { runWhatIfScenario, calculateDelayScore } from './predictionService.ts';
import { predictDelayRisk, MODEL_METRICS, FEATURE_IMPORTANCES } from './mlModel.ts';
import * as db from './database.ts';
import { SyncService } from './ingestion/syncService.ts';
import { FileIngestionAdapter } from './ingestion/fileIngestionAdapter.ts';
import { DashboardSummary, Project, AlertItem, PaginatedProjects, DataSourceItem, DatabaseOverview, AuditLogItem, DataValidationErrorItem, ConnectionTestResult } from '../types.ts';
import { GovernmentSourceType } from './ingestion/types.ts';

export function getDashboardSummary(): DashboardSummary {
  return db.getDashboardSummary();
}

export function getProjects(params?: {
  search?: string;
  risk?: string;
  state?: string;
  district?: string;
  stage?: string;
  sortBy?: string;
  page?: number;
  pageSize?: number;
}): PaginatedProjects {
  return db.queryProjects(params);
}

export function getProjectById(id: string): Project | undefined {
  return db.getProjectById(id);
}

export function updateProject(id: string, fields: Partial<Project>, userId = 'admin') {
  return db.updateProjectRecord(id, fields, userId);
}

export function getProjectHistory(id: string) {
  return db.getProjectHistory(id);
}

export function getAlerts(status?: string): AlertItem[] {
  return db.getAlerts(status);
}

export function acknowledgeAlert(id: string): AlertItem | undefined {
  return db.acknowledgeAlert(id);
}

export function getRiskMapData() {
  return db.getRiskMapData();
}

export function getSystemStatus() {
  return db.getSystemStatus();
}

export async function getSourcesStatus() {
  return await SyncService.getSourcesStatus();
}

export function getDataSources(): DataSourceItem[] {
  return db.getDataSources();
}

export function getDataSourceById(id: string): DataSourceItem | undefined {
  return db.getDataSourceById(id);
}

export function updateDataSourceConfig(id: string, update: Partial<DataSourceItem>): DataSourceItem | undefined {
  return db.updateDataSourceConfig(id, update);
}

export async function testDataSourceConnection(id: string): Promise<ConnectionTestResult> {
  return await SyncService.testConnection(id);
}

export async function triggerSync(source: GovernmentSourceType = 'BhoomiRashi') {
  return await SyncService.syncWithSource(source);
}

export function inspectFile(content: string, fileType: string, fileName?: string) {
  return FileIngestionAdapter.inspectFile(content, fileType, fileName);
}

export async function importDataWithMapping(content: string, fileType: 'csv' | 'xlsx' | 'xls' | 'json', columnMapping?: Record<string, string>, fileName?: string) {
  return await SyncService.importWithMapping(content, fileType, columnMapping, fileName);
}

export async function importData(content: string, fileType: 'csv' | 'xlsx' | 'xls' | 'json', fileName?: string) {
  return await SyncService.importFile(content, fileType, fileName);
}

export function getValidationErrors(syncId?: string, limit = 50): DataValidationErrorItem[] {
  return db.getValidationErrors(syncId, limit);
}

export function getAuditLogs(limit = 50): AuditLogItem[] {
  return db.getAuditLogs(limit);
}

export function getDatabaseOverview(): DatabaseOverview {
  return db.getDatabaseOverview();
}

export function exportData(type: 'all' | 'high_risk' | 'alerts' | 'audit_logs', format: 'csv' | 'json') {
  return db.exportData(type, format);
}

export function setDataMode(mode: 'DEMO' | 'LIVE_SYNCHRONIZED') {
  db.setSystemMetadata('data_mode', mode);
  return { success: true, mode };
}

export function getSyncHistory(limit = 10) {
  return db.getSyncRuns(limit);
}

export function getModelInfo() {
  return {
    metrics: MODEL_METRICS,
    featureImportances: FEATURE_IMPORTANCES
  };
}

export { runWhatIfScenario, calculateDelayScore, predictDelayRisk, MODEL_METRICS };
export { DataHubApi } from './datahub/api.ts';
export { DataHubScheduler } from './datahub/scheduler.ts';
export { BhoomiRashiCollector } from './datahub/bhoomiRashiCollector.ts';

