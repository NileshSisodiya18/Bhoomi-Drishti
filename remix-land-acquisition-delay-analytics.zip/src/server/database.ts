import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import {
  Project,
  AlertItem,
  DashboardSummary,
  PaginatedProjects,
  SystemStatus,
  RiskFactor,
  DataSourceItem,
  DataValidationErrorItem,
  DataValidationReport,
  DatabaseOverview,
  AuditLogItem,
  DataModeType
} from '../types.ts';
import { computeRecordHash } from './hashUtil.ts';
import { predictDelayRisk, calculateDelayVarianceMonths } from './mlModel.ts';
import { repairDataHubCorruptedProjects } from './datahub/database.ts';
import { DataHubBridge } from './datahub/bridge.ts';

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.resolve(DB_DIR, 'bhoomidrishti.db');

let dbInstance: DatabaseSync | null = null;

export function getDatabase(): DatabaseSync {
  if (!dbInstance) {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    dbInstance = new DatabaseSync(DB_PATH);
    initSchema(dbInstance);
  }
  return dbInstance;
}

function initSchema(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      sector TEXT NOT NULL,
      state TEXT NOT NULL,
      district TEXT NOT NULL,
      taluk_or_tehsil TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      current_stage TEXT NOT NULL,
      stage_status TEXT NOT NULL,
      risk_level TEXT NOT NULL,
      delay_probability REAL NOT NULL,
      main_issue TEXT NOT NULL,
      total_land_required_ha REAL NOT NULL,
      land_acquired_ha REAL NOT NULL,
      pending_land_ha REAL NOT NULL,
      private_land_ha REAL NOT NULL,
      govt_land_ha REAL NOT NULL,
      forest_land_ha REAL NOT NULL,
      compensation_sanctioned_cr REAL NOT NULL,
      compensation_disbursed_cr REAL NOT NULL,
      compensation_disbursed_percent REAL NOT NULL,
      pending_compensation_cases INTEGER NOT NULL,
      unresolved_legal_cases INTEGER NOT NULL,
      has_court_stay INTEGER NOT NULL DEFAULT 0,
      court_details TEXT,
      incomplete_documents_count INTEGER NOT NULL DEFAULT 0,
      forest_clearance_stage TEXT NOT NULL,
      last_updated TEXT NOT NULL,
      is_synthetic INTEGER NOT NULL DEFAULT 1,
      source TEXT DEFAULT 'BhoomiRashi',
      source_project_id TEXT,
      source_url TEXT,
      act TEXT DEFAULT 'National Highways Act 1956',
      highway_number TEXT,
      agency TEXT DEFAULT 'NHAI',
      source_last_updated TEXT,
      ingested_at TEXT,
      record_hash TEXT,
      last_synced_at TEXT,
      created_at TEXT,
      updated_at TEXT,
      dispute_status TEXT,
      documentation_status TEXT,
      rural_urban TEXT DEFAULT 'Rural',
      location_name TEXT,
      affected_families INTEGER DEFAULT 0,
      delay_variance_months REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS project_stages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      stage TEXT NOT NULL,
      status TEXT NOT NULL,
      progress_percent INTEGER NOT NULL,
      completed_date TEXT,
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS project_risk_factors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      factor TEXT NOT NULL,
      impact_level TEXT NOT NULL,
      direction TEXT NOT NULL,
      detail TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS project_attention_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      item_text TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS project_recommendations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      recommendation_text TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      project_name TEXT NOT NULL,
      location TEXT NOT NULL,
      type TEXT NOT NULL,
      risk_change TEXT NOT NULL,
      reason TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'New',
      recommended_action TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS project_history (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      source TEXT NOT NULL,
      field_changed TEXT NOT NULL,
      old_value TEXT,
      new_value TEXT,
      changed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sync_runs (
      sync_id TEXT PRIMARY KEY,
      source TEXT NOT NULL,
      started_at TEXT NOT NULL,
      completed_at TEXT NOT NULL,
      status TEXT NOT NULL,
      records_received INTEGER NOT NULL,
      records_valid INTEGER NOT NULL,
      records_inserted INTEGER NOT NULL,
      records_updated INTEGER NOT NULL,
      records_unchanged INTEGER NOT NULL,
      records_failed INTEGER NOT NULL,
      duration_ms INTEGER NOT NULL,
      error_message TEXT
    );

    CREATE TABLE IF NOT EXISTS system_metadata (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS data_sources (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      base_url TEXT,
      api_endpoint TEXT,
      description TEXT,
      enabled INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'NOT_CONFIGURED',
      auth_type TEXT DEFAULT 'NONE',
      api_key TEXT,
      sync_interval_minutes INTEGER DEFAULT 60,
      last_sync_started TEXT,
      last_sync_completed TEXT,
      last_successful_sync TEXT,
      records_received INTEGER DEFAULT 0,
      records_inserted INTEGER DEFAULT 0,
      records_updated INTEGER DEFAULT 0,
      records_unchanged INTEGER DEFAULT 0,
      records_failed INTEGER DEFAULT 0,
      error_message TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS data_validation_errors (
      id TEXT PRIMARY KEY,
      sync_id TEXT,
      source TEXT NOT NULL,
      row_number INTEGER,
      project_identifier TEXT,
      field_name TEXT NOT NULL,
      severity TEXT NOT NULL,
      error_message TEXT NOT NULL,
      raw_value TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL DEFAULT 'admin',
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      old_value TEXT,
      new_value TEXT,
      timestamp TEXT NOT NULL
    );
  `);

  // Migrate columns for projects table if needed (for legacy databases)
  const alterCols = [
    "ALTER TABLE projects ADD COLUMN source TEXT DEFAULT 'BhoomiRashi'",
    "ALTER TABLE projects ADD COLUMN source_project_id TEXT",
    "ALTER TABLE projects ADD COLUMN source_url TEXT",
    "ALTER TABLE projects ADD COLUMN act TEXT DEFAULT 'National Highways Act 1956'",
    "ALTER TABLE projects ADD COLUMN highway_number TEXT",
    "ALTER TABLE projects ADD COLUMN agency TEXT DEFAULT 'NHAI'",
    "ALTER TABLE projects ADD COLUMN source_last_updated TEXT",
    "ALTER TABLE projects ADD COLUMN ingested_at TEXT",
    "ALTER TABLE projects ADD COLUMN record_hash TEXT",
    "ALTER TABLE projects ADD COLUMN last_synced_at TEXT",
    "ALTER TABLE projects ADD COLUMN created_at TEXT",
    "ALTER TABLE projects ADD COLUMN updated_at TEXT",
    "ALTER TABLE projects ADD COLUMN dispute_status TEXT",
    "ALTER TABLE projects ADD COLUMN documentation_status TEXT",
    "ALTER TABLE projects ADD COLUMN rural_urban TEXT DEFAULT 'Rural'",
    "ALTER TABLE projects ADD COLUMN location_name TEXT",
    "ALTER TABLE projects ADD COLUMN affected_families INTEGER DEFAULT 0",
    "ALTER TABLE projects ADD COLUMN delay_variance_months REAL DEFAULT 0"
  ];
  for (const sql of alterCols) {
    try { db.exec(sql); } catch { /* column may already exist */ }
  }

  // Performance Indexes (created after columns are verified)
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_projects_state ON projects(state);
    CREATE INDEX IF NOT EXISTS idx_projects_district ON projects(district);
    CREATE INDEX IF NOT EXISTS idx_projects_risk_level ON projects(risk_level);
    CREATE INDEX IF NOT EXISTS idx_projects_current_stage ON projects(current_stage);
    CREATE INDEX IF NOT EXISTS idx_projects_source ON projects(source);
    CREATE INDEX IF NOT EXISTS idx_projects_source_project_id ON projects(source_project_id);
    CREATE INDEX IF NOT EXISTS idx_alerts_project_id ON alerts(project_id);
    CREATE INDEX IF NOT EXISTS idx_project_history_project_id ON project_history(project_id);
    CREATE INDEX IF NOT EXISTS idx_validation_errors_sync_id ON data_validation_errors(sync_id);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);
  `);

  seedDataSources(db);
  seedSystemMetadata(db);

  // Check if database is empty, and seed if so
  const checkStmt = db.prepare("SELECT COUNT(*) as count FROM projects");
  const row = checkStmt.get() as { count: number } | undefined;
  if (!row || row.count === 0) {
    seedInitialData(db);
  }

  // Check and repair any corrupted BhoomiRashi projects (e.g. titled "Land Acquisition Portal")
  try {
    repairDataHubCorruptedProjects();
    const badProj = db.prepare("SELECT COUNT(*) as c FROM projects WHERE name LIKE '%Land Acquisition Portal%'").get() as { c: number } | undefined;
    if (badProj && badProj.c > 0) {
      DataHubBridge.syncToMainApp();
      console.log(`[DatabaseInit] Repaired ${badProj.c} projects in main projects table.`);
    }
  } catch (err) {
    console.warn('[DatabaseInit] DataHub auto-repair check:', err);
  }

  // Ensure all projects have substantiated delay variance values
  try {
    ensureProjectDelayVariances(db);
  } catch (err) {
    console.warn('[DatabaseInit] ensureProjectDelayVariances check:', err);
  }
}

export function ensureProjectDelayVariances(db: DatabaseSync) {
  try {
    const rows = db.prepare(`
      SELECT id, delay_probability, has_court_stay, compensation_disbursed_percent,
             incomplete_documents_count, forest_clearance_stage, pending_land_ha,
             total_land_required_ha, delay_variance_months
      FROM projects
    `).all() as any[];

    const updateStmt = db.prepare(`UPDATE projects SET delay_variance_months = ? WHERE id = ?`);
    for (const r of rows) {
      if (!r.delay_variance_months || r.delay_variance_months === 0) {
        const variance = calculateDelayVarianceMonths({
          delayProbability: r.delay_probability,
          hasCourtStay: Boolean(r.has_court_stay),
          compensationDisbursedPercent: r.compensation_disbursed_percent,
          incompleteDocumentsCount: r.incomplete_documents_count,
          forestClearanceStage: r.forest_clearance_stage,
          pendingLandHa: r.pending_land_ha,
          totalLandRequiredHa: r.total_land_required_ha
        });
        updateStmt.run(variance, r.id);
      }
    }
  } catch (err) {
    console.error('Error ensuring project delay variances:', err);
  }
}

function seedDataSources(db: DatabaseSync) {
  const countStmt = db.prepare("SELECT COUNT(*) as c FROM data_sources");
  const row = countStmt.get() as { c: number } | undefined;
  if (row && row.c > 0) return;

  const now = new Date().toISOString();
  const insertStmt = db.prepare(`
    INSERT INTO data_sources (
      id, name, type, base_url, api_endpoint, description,
      enabled, status, auth_type, api_key, sync_interval_minutes,
      last_sync_started, last_sync_completed, last_successful_sync,
      records_received, records_inserted, records_updated, records_unchanged, records_failed,
      error_message, created_at, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?
    )
  `);

  insertStmt.run(
    'bhoomirashi',
    'BhoomiRashi (MoRTH e-Gazette)',
    'API',
    'https://bhoomirashi.gov.in',
    '/auth/web/corridors',
    'Ministry of Road Transport & Highways official land acquisition notifications under the National Highways Act 1956.',
    1,
    'SUCCESS',
    'NONE',
    null,
    60,
    now, now, now,
    5, 5, 0, 0, 0,
    null, now, now
  );

  insertStmt.run(
    'lacrris',
    'LACRRIS (DoLR / MoRD)',
    'API',
    'https://larr.dolr.gov.in',
    '/reports/acquisition-progress',
    'Department of Land Resources (Ministry of Rural Development) Land Acquisition, Rehabilitation & Resettlement Information System under RFCTLARR Act 2013.',
    1,
    'SUCCESS',
    'NONE',
    null,
    120,
    now, now, now,
    3, 3, 0, 0, 0,
    null, now, now
  );

  insertStmt.run(
    'custom_api',
    'State Revenue / Custom Central API',
    'API',
    '',
    '/api/v1/land-acquisition',
    'Configurable REST/JSON integration endpoint for state revenue departments and district land acquisition offices.',
    0,
    'NOT_CONFIGURED',
    'API_KEY',
    null,
    30,
    null, null, null,
    0, 0, 0, 0, 0,
    null, now, now
  );

  insertStmt.run(
    'file_import',
    'Official File Ingestion (CSV / XLSX / JSON)',
    'MANUAL',
    'https://data.gov.in',
    null,
    'Administrative data portal for importing validated district land acquisition schedules, award matrices, and geospatial spreadsheets.',
    1,
    'SUCCESS',
    'NONE',
    null,
    0,
    now, now, now,
    0, 0, 0, 0, 0,
    null, now, now
  );
}

function seedSystemMetadata(db: DatabaseSync) {
  const insertStmt = db.prepare("INSERT OR IGNORE INTO system_metadata (key, value) VALUES (?, ?)");
  const now = new Date().toISOString();
  insertStmt.run('data_mode', 'DEMO');
  insertStmt.run('active_data_source', 'BhoomiRashi & LACRRIS Ingestion Architecture');
  insertStmt.run('dataset_source', 'BhoomiRashi & LACRRIS Canonical Registry (SIH-2026 Reference)');
  insertStmt.run('last_data_refresh', now);
  insertStmt.run('last_successful_sync', now);
  insertStmt.run('ml_model_version', 'v1.2-RF');
  insertStmt.run('ml_model_type', 'Random Forest Classifier (100 Trees)');
  insertStmt.run('ml_model_accuracy', '0.880');
  insertStmt.run('ml_model_f1', '0.850');
  insertStmt.run('ml_model_roc_auc', '0.883');
}

function seedInitialData(db: DatabaseSync) {
  // 18 comprehensive infrastructure projects across Indian states & districts
  const seedProjects: any[] = [
    {
      id: "NHAI-2026-001",
      name: "Nashik-Pune Industrial Corridor (NH-60 Expansion)",
      sector: "National Highways",
      state: "Maharashtra",
      district: "Nashik",
      talukOrTehsil: "Sinnar",
      latitude: 19.9975,
      longitude: 73.7898,
      currentStage: "Compensation",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 78,
      mainIssue: "Compensation pending for 34 title-disputed parcels in Sinnar Taluk",
      totalLandRequiredHa: 480.5,
      landAcquiredHa: 215.0,
      pendingLandHa: 265.5,
      privateLandHa: 380.0,
      govtLandHa: 65.5,
      forestLandHa: 35.0,
      compensationSanctionedCr: 142.5,
      compensationDisbursedCr: 58.4,
      compensationDisbursedPercent: 41.0,
      pendingCompensationCases: 14,
      unresolvedLegalCases: 4,
      hasCourtStay: 1,
      courtDetails: "Bombay High Court interim stay on 18 Ha agricultural land acquisition",
      incompleteDocumentsCount: 22,
      forestClearanceStage: "Stage 2 Pending",
      lastUpdated: "2026-03-02"
    },
    {
      id: "DFCC-2026-012",
      name: "Eastern Dedicated Freight Corridor (Varanasi Feeder)",
      sector: "Railways",
      state: "Uttar Pradesh",
      district: "Varanasi",
      talukOrTehsil: "Pindra",
      latitude: 25.3176,
      longitude: 82.9739,
      currentStage: "Legal / Documentation",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 82,
      mainIssue: "7 unresolved heirship disputes and pending joint measurement surveys",
      totalLandRequiredHa: 320.0,
      landAcquiredHa: 138.2,
      pendingLandHa: 181.8,
      privateLandHa: 275.0,
      govtLandHa: 45.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 98.0,
      compensationDisbursedCr: 39.2,
      compensationDisbursedPercent: 40.0,
      pendingCompensationCases: 19,
      unresolvedLegalCases: 7,
      hasCourtStay: 1,
      courtDetails: "Civil Judge Senior Division stay regarding ancestral rights partition",
      incompleteDocumentsCount: 31,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-04"
    },
    {
      id: "NHAI-2026-034",
      name: "Bengaluru-Chennai Expressway (Package III - Hoskote to Malur)",
      sector: "National Highways",
      state: "Karnataka",
      district: "Kolar",
      talukOrTehsil: "Malur",
      latitude: 13.0033,
      longitude: 77.9424,
      currentStage: "Compensation",
      stageStatus: "In Progress",
      riskLevel: "LOW",
      delayProbability: 24,
      mainIssue: "Pending award disbursement for 12 Khatadars awaiting bank verification",
      totalLandRequiredHa: 210.0,
      landAcquiredHa: 178.5,
      pendingLandHa: 31.5,
      privateLandHa: 165.0,
      govtLandHa: 45.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 85.0,
      compensationDisbursedCr: 68.0,
      compensationDisbursedPercent: 80.0,
      pendingCompensationCases: 5,
      unresolvedLegalCases: 1,
      hasCourtStay: 0,
      courtDetails: "No active injunction",
      incompleteDocumentsCount: 8,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-05"
    },
    {
      id: "METRO-2026-004",
      name: "Ahmedabad Metro Phase-2 (Koteshwar to Gandhinagar Sector-1)",
      sector: "Metro Rail",
      state: "Gujarat",
      district: "Gandhinagar",
      talukOrTehsil: "Gandhinagar",
      latitude: 23.2156,
      longitude: 72.6369,
      currentStage: "Possession",
      stageStatus: "Completed",
      riskLevel: "LOW",
      delayProbability: 14,
      mainIssue: "Clearance and handover of remaining 4.2 Ha urban utility corridor",
      totalLandRequiredHa: 85.0,
      landAcquiredHa: 80.8,
      pendingLandHa: 4.2,
      privateLandHa: 35.0,
      govtLandHa: 50.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 42.0,
      compensationDisbursedCr: 39.9,
      compensationDisbursedPercent: 95.0,
      pendingCompensationCases: 0,
      unresolvedLegalCases: 0,
      hasCourtStay: 0,
      courtDetails: "No active disputes",
      incompleteDocumentsCount: 2,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-06"
    },
    {
      id: "RICC-2026-018",
      name: "Delhi-Mumbai Industrial Corridor (Dighi Port Link)",
      sector: "Industrial Corridors",
      state: "Maharashtra",
      district: "Raigad",
      talukOrTehsil: "Mangaon",
      latitude: 18.2524,
      longitude: 73.0416,
      currentStage: "Verification",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 76,
      mainIssue: "Joint Measurement Survey delayed by monsoon terrain and forest boundary disputes",
      totalLandRequiredHa: 540.0,
      landAcquiredHa: 190.0,
      pendingLandHa: 350.0,
      privateLandHa: 390.0,
      govtLandHa: 70.0,
      forestLandHa: 80.0,
      compensationSanctionedCr: 160.0,
      compensationDisbursedCr: 48.0,
      compensationDisbursedPercent: 30.0,
      pendingCompensationCases: 22,
      unresolvedLegalCases: 3,
      hasCourtStay: 0,
      courtDetails: "National Green Tribunal notice under review",
      incompleteDocumentsCount: 28,
      forestClearanceStage: "Stage 2 Pending",
      lastUpdated: "2026-03-01"
    },
    {
      id: "NHAI-2026-042",
      name: "Gorakhpur-Siliguri Expressway (Package II - Gopalganj Section)",
      sector: "National Highways",
      state: "Bihar",
      district: "Gopalganj",
      talukOrTehsil: "Hathua",
      latitude: 26.4674,
      longitude: 84.4414,
      currentStage: "Identification",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 84,
      mainIssue: "Revenue land records mismatch across 18 flood-prone village circles",
      totalLandRequiredHa: 290.0,
      landAcquiredHa: 45.0,
      pendingLandHa: 245.0,
      privateLandHa: 260.0,
      govtLandHa: 30.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 75.0,
      compensationDisbursedCr: 15.0,
      compensationDisbursedPercent: 20.0,
      pendingCompensationCases: 16,
      unresolvedLegalCases: 2,
      hasCourtStay: 1,
      courtDetails: "Patna High Court stay on notification 3A regarding valuation criteria",
      incompleteDocumentsCount: 38,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-07"
    },
    {
      id: "RLY-2026-008",
      name: "Bhubaneswar-Paradip Multi-Modal Freight Rail Spur",
      sector: "Railways",
      state: "Odisha",
      district: "Jagatsinghpur",
      talukOrTehsil: "Kujang",
      latitude: 20.2858,
      longitude: 86.6214,
      currentStage: "Verification",
      stageStatus: "In Progress",
      riskLevel: "MEDIUM",
      delayProbability: 46,
      mainIssue: "Coastal regulatory zone (CRZ) review and private land title verification",
      totalLandRequiredHa: 175.0,
      landAcquiredHa: 110.0,
      pendingLandHa: 65.0,
      privateLandHa: 120.0,
      govtLandHa: 35.0,
      forestLandHa: 20.0,
      compensationSanctionedCr: 52.0,
      compensationDisbursedCr: 33.8,
      compensationDisbursedPercent: 65.0,
      pendingCompensationCases: 6,
      unresolvedLegalCases: 1,
      hasCourtStay: 0,
      courtDetails: "No active injunction",
      incompleteDocumentsCount: 12,
      forestClearanceStage: "Stage 1 Approved",
      lastUpdated: "2026-03-03"
    },
    {
      id: "ENRG-2026-021",
      name: "Bhadla Solar Park Interstate Transmission Link (765kV)",
      sector: "Energy & Grid",
      state: "Rajasthan",
      district: "Phalodi",
      talukOrTehsil: "Bap",
      latitude: 27.5385,
      longitude: 72.3654,
      currentStage: "Possession",
      stageStatus: "Completed",
      riskLevel: "LOW",
      delayProbability: 12,
      mainIssue: "Right of Way (RoW) tower footing compensation completed across desert parcels",
      totalLandRequiredHa: 120.0,
      landAcquiredHa: 116.5,
      pendingLandHa: 3.5,
      privateLandHa: 40.0,
      govtLandHa: 80.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 18.0,
      compensationDisbursedCr: 17.5,
      compensationDisbursedPercent: 97.2,
      pendingCompensationCases: 0,
      unresolvedLegalCases: 0,
      hasCourtStay: 0,
      courtDetails: "Nil",
      incompleteDocumentsCount: 1,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-06"
    },
    {
      id: "NHAI-2026-055",
      name: "Amritsar-Katra Expressway (Package VI - Gurdaspur Bypass)",
      sector: "National Highways",
      state: "Punjab",
      district: "Gurdaspur",
      talukOrTehsil: "Batala",
      latitude: 31.8186,
      longitude: 75.2028,
      currentStage: "Compensation",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 79,
      mainIssue: "Demand for enhanced market solatium by local farmer union representatives",
      totalLandRequiredHa: 310.0,
      landAcquiredHa: 125.0,
      pendingLandHa: 185.0,
      privateLandHa: 285.0,
      govtLandHa: 25.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 115.0,
      compensationDisbursedCr: 46.0,
      compensationDisbursedPercent: 40.0,
      pendingCompensationCases: 18,
      unresolvedLegalCases: 5,
      hasCourtStay: 1,
      courtDetails: "Punjab & Haryana High Court writ petition on compensation parity",
      incompleteDocumentsCount: 17,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-04"
    },
    {
      id: "EXPR-2026-061",
      name: "Ganga Expressway Extension (Prayagraj to Mirzapur)",
      sector: "National Highways",
      state: "Uttar Pradesh",
      district: "Prayagraj",
      talukOrTehsil: "Karchhana",
      latitude: 25.4358,
      longitude: 81.8463,
      currentStage: "Legal / Documentation",
      stageStatus: "In Progress",
      riskLevel: "MEDIUM",
      delayProbability: 52,
      mainIssue: "4 reference court petitions under Section 64 pending award enhancement",
      totalLandRequiredHa: 395.0,
      landAcquiredHa: 260.0,
      pendingLandHa: 135.0,
      privateLandHa: 330.0,
      govtLandHa: 65.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 128.0,
      compensationDisbursedCr: 83.2,
      compensationDisbursedPercent: 65.0,
      pendingCompensationCases: 8,
      unresolvedLegalCases: 4,
      hasCourtStay: 0,
      courtDetails: "District Court Land Acquisition Authority",
      incompleteDocumentsCount: 9,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-05"
    },
    {
      id: "RLY-2026-077",
      name: "Bilaspur-Manali-Leh Strategic Rail Line (Sundernagar Link)",
      sector: "Railways",
      state: "Himachal Pradesh",
      district: "Mandi",
      talukOrTehsil: "Sundernagar",
      latitude: 31.5323,
      longitude: 76.9022,
      currentStage: "Verification",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 74,
      mainIssue: "Forest Rights Act (FRA) Gram Sabha resolutions pending for tunnel portal parcels",
      totalLandRequiredHa: 145.0,
      landAcquiredHa: 38.0,
      pendingLandHa: 107.0,
      privateLandHa: 45.0,
      govtLandHa: 30.0,
      forestLandHa: 70.0,
      compensationSanctionedCr: 36.0,
      compensationDisbursedCr: 12.6,
      compensationDisbursedPercent: 35.0,
      pendingCompensationCases: 9,
      unresolvedLegalCases: 2,
      hasCourtStay: 0,
      courtDetails: "Himachal Pradesh High Court environmental PIL",
      incompleteDocumentsCount: 15,
      forestClearanceStage: "Stage 2 Pending",
      lastUpdated: "2026-03-03"
    },
    {
      id: "NHAI-2026-089",
      name: "Chennai Peripheral Ring Road (Package IV - Sriperumbudur)",
      sector: "National Highways",
      state: "Tamil Nadu",
      district: "Kanchipuram",
      talukOrTehsil: "Sriperumbudur",
      latitude: 12.9675,
      longitude: 79.9482,
      currentStage: "Possession",
      stageStatus: "Completed",
      riskLevel: "LOW",
      delayProbability: 18,
      mainIssue: "Physical possession completed across 98% alignment; tree cutting in progress",
      totalLandRequiredHa: 235.0,
      landAcquiredHa: 228.0,
      pendingLandHa: 7.0,
      privateLandHa: 190.0,
      govtLandHa: 45.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 112.0,
      compensationDisbursedCr: 108.6,
      compensationDisbursedPercent: 97.0,
      pendingCompensationCases: 1,
      unresolvedLegalCases: 0,
      hasCourtStay: 0,
      courtDetails: "No pending disputes",
      incompleteDocumentsCount: 3,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-07"
    },
    {
      id: "NHAI-2026-103",
      name: "Indore-Hyderabad Economic Corridor (Khandwa Section)",
      sector: "National Highways",
      state: "Madhya Pradesh",
      district: "Khandwa",
      talukOrTehsil: "Pandhana",
      latitude: 21.8286,
      longitude: 76.3533,
      currentStage: "Compensation",
      stageStatus: "In Progress",
      riskLevel: "LOW",
      delayProbability: 28,
      mainIssue: "Disbursement progressing steadily for agricultural parcels along NH-347BG",
      totalLandRequiredHa: 265.0,
      landAcquiredHa: 190.0,
      pendingLandHa: 75.0,
      privateLandHa: 220.0,
      govtLandHa: 45.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 92.0,
      compensationDisbursedCr: 66.2,
      compensationDisbursedPercent: 72.0,
      pendingCompensationCases: 7,
      unresolvedLegalCases: 1,
      hasCourtStay: 0,
      courtDetails: "Nil",
      incompleteDocumentsCount: 11,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-05"
    },
    {
      id: "METRO-2026-015",
      name: "Kolkata East-West Metro Extension (Salt Lake Sector V to Airport)",
      sector: "Metro Rail",
      state: "West Bengal",
      district: "North 24 Parganas",
      talukOrTehsil: "Bidhannagar",
      latitude: 22.5804,
      longitude: 88.4378,
      currentStage: "Compensation",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 75,
      mainIssue: "Rehabilitation & Resettlement (R&R) scheme objections by commercial leaseholders",
      totalLandRequiredHa: 48.0,
      landAcquiredHa: 21.5,
      pendingLandHa: 26.5,
      privateLandHa: 28.0,
      govtLandHa: 20.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 78.0,
      compensationDisbursedCr: 35.1,
      compensationDisbursedPercent: 45.0,
      pendingCompensationCases: 15,
      unresolvedLegalCases: 4,
      hasCourtStay: 1,
      courtDetails: "Calcutta High Court stay regarding commercial tenancy compensation formula",
      incompleteDocumentsCount: 14,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-02"
    },
    {
      id: "DFCC-2026-029",
      name: "Western Dedicated Freight Corridor (Vadodara-JNPT Segment)",
      sector: "Railways",
      state: "Gujarat",
      district: "Bharuch",
      talukOrTehsil: "Ankleshwar",
      latitude: 21.6264,
      longitude: 73.0033,
      currentStage: "Possession",
      stageStatus: "In Progress",
      riskLevel: "LOW",
      delayProbability: 22,
      mainIssue: "Removal of industrial utility crossings along railway right of way",
      totalLandRequiredHa: 185.0,
      landAcquiredHa: 166.5,
      pendingLandHa: 18.5,
      privateLandHa: 145.0,
      govtLandHa: 40.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 88.0,
      compensationDisbursedCr: 79.2,
      compensationDisbursedPercent: 90.0,
      pendingCompensationCases: 2,
      unresolvedLegalCases: 1,
      hasCourtStay: 0,
      courtDetails: "No injunction",
      incompleteDocumentsCount: 4,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-06"
    },
    {
      id: "NHAI-2026-118",
      name: "Guwahati Ring Road & Brahmaputra Bridge Approach",
      sector: "National Highways",
      state: "Assam",
      district: "Kamrup",
      talukOrTehsil: "Hajo",
      latitude: 26.2485,
      longitude: 91.5647,
      currentStage: "Identification",
      stageStatus: "Delayed",
      riskLevel: "HIGH",
      delayProbability: 81,
      mainIssue: "Ecological sensitivity review around Deepor Beel Ramsar site",
      totalLandRequiredHa: 215.0,
      landAcquiredHa: 42.0,
      pendingLandHa: 173.0,
      privateLandHa: 160.0,
      govtLandHa: 35.0,
      forestLandHa: 20.0,
      compensationSanctionedCr: 64.0,
      compensationDisbursedCr: 16.0,
      compensationDisbursedPercent: 25.0,
      pendingCompensationCases: 12,
      unresolvedLegalCases: 3,
      hasCourtStay: 1,
      courtDetails: "Gauhati High Court order directing boundary demarcations",
      incompleteDocumentsCount: 26,
      forestClearanceStage: "Stage 2 Pending",
      lastUpdated: "2026-03-01"
    },
    {
      id: "NHAI-2026-125",
      name: "Raipur-Visakhapatnam Economic Corridor (Package IV)",
      sector: "National Highways",
      state: "Andhra Pradesh",
      district: "Vizianagaram",
      talukOrTehsil: "Salur",
      latitude: 18.5283,
      longitude: 83.2104,
      currentStage: "Compensation",
      stageStatus: "In Progress",
      riskLevel: "MEDIUM",
      delayProbability: 48,
      mainIssue: "Scheduled Area (Fifth Schedule) consent procedures and RoR title verification",
      totalLandRequiredHa: 240.0,
      landAcquiredHa: 156.0,
      pendingLandHa: 84.0,
      privateLandHa: 190.0,
      govtLandHa: 50.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 82.0,
      compensationDisbursedCr: 53.3,
      compensationDisbursedPercent: 65.0,
      pendingCompensationCases: 9,
      unresolvedLegalCases: 1,
      hasCourtStay: 0,
      courtDetails: "Nil",
      incompleteDocumentsCount: 14,
      forestClearanceStage: "Stage 1 Approved",
      lastUpdated: "2026-03-04"
    },
    {
      id: "ENRG-2026-033",
      name: "Green Energy Corridor Stage-II (Koppal Renewable Substation)",
      sector: "Energy & Grid",
      state: "Karnataka",
      district: "Koppal",
      talukOrTehsil: "Kushtagi",
      latitude: 15.7533,
      longitude: 76.2001,
      currentStage: "Possession",
      stageStatus: "Completed",
      riskLevel: "LOW",
      delayProbability: 15,
      mainIssue: "Direct consent purchase completed under state special land policy",
      totalLandRequiredHa: 95.0,
      landAcquiredHa: 92.5,
      pendingLandHa: 2.5,
      privateLandHa: 90.0,
      govtLandHa: 5.0,
      forestLandHa: 0.0,
      compensationSanctionedCr: 28.0,
      compensationDisbursedCr: 27.2,
      compensationDisbursedPercent: 97.1,
      pendingCompensationCases: 0,
      unresolvedLegalCases: 0,
      hasCourtStay: 0,
      courtDetails: "Nil",
      incompleteDocumentsCount: 1,
      forestClearanceStage: "Not Required",
      lastUpdated: "2026-03-06"
    }
  ];

  const insertProjectStmt = db.prepare(`
    INSERT OR REPLACE INTO projects (
      id, name, sector, state, district, taluk_or_tehsil,
      latitude, longitude, current_stage, stage_status,
      risk_level, delay_probability, main_issue,
      total_land_required_ha, land_acquired_ha, pending_land_ha,
      private_land_ha, govt_land_ha, forest_land_ha,
      compensation_sanctioned_cr, compensation_disbursed_cr, compensation_disbursed_percent,
      pending_compensation_cases, unresolved_legal_cases, has_court_stay, court_details,
      incomplete_documents_count, forest_clearance_stage, last_updated, is_synthetic
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertStageStmt = db.prepare(`
    INSERT INTO project_stages (project_id, stage, status, progress_percent, completed_date, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const insertFactorStmt = db.prepare(`
    INSERT INTO project_risk_factors (project_id, factor, impact_level, direction, detail)
    VALUES (?, ?, ?, ?, ?)
  `);

  const insertAttentionStmt = db.prepare(`
    INSERT INTO project_attention_items (project_id, item_text)
    VALUES (?, ?)
  `);

  const insertRecStmt = db.prepare(`
    INSERT INTO project_recommendations (project_id, recommendation_text)
    VALUES (?, ?)
  `);

  const stagesList = ['Identification', 'Verification', 'Compensation', 'Legal / Documentation', 'Possession'];

  for (const p of seedProjects) {
    insertProjectStmt.run(
      p.id, p.name, p.sector, p.state, p.district, p.talukOrTehsil,
      p.latitude, p.longitude, p.currentStage, p.stageStatus,
      p.riskLevel, p.delayProbability, p.mainIssue,
      p.totalLandRequiredHa, p.landAcquiredHa, p.pendingLandHa,
      p.privateLandHa, p.govtLandHa, p.forestLandHa,
      p.compensationSanctionedCr, p.compensationDisbursedCr, p.compensationDisbursedPercent,
      p.pendingCompensationCases, p.unresolvedLegalCases, p.hasCourtStay, p.courtDetails,
      p.incompleteDocumentsCount, p.forestClearanceStage, p.lastUpdated, 1
    );

    // Standard statutory stages
    const curIdx = stagesList.indexOf(p.currentStage);
    for (let i = 0; i < stagesList.length; i++) {
      const stName = stagesList[i];
      let status = 'Pending';
      let pct = 0;
      if (i < curIdx) {
        status = 'Completed';
        pct = 100;
      } else if (i === curIdx) {
        status = p.stageStatus;
        pct = stName === 'Compensation' ? Math.round(p.compensationDisbursedPercent) : (status === 'Delayed' ? 45 : 70);
      }
      insertStageStmt.run(p.id, stName, status, pct, null, `Statutory milestone for ${stName}`);
    }

    // Risk factors
    if (p.compensationDisbursedPercent < 55) {
      insertFactorStmt.run(p.id, "Compensation Disbursement Lag", "High", "Increases risk", `${Math.round(100 - p.compensationDisbursedPercent)}% sanctioned compensation remains undisbursed to title holders.`);
    } else if (p.compensationDisbursedPercent > 80) {
      insertFactorStmt.run(p.id, "Healthy Compensation Disbursement", "Medium", "Reduces risk", `${Math.round(p.compensationDisbursedPercent)}% compensation disbursed, minimizing landowner possession friction.`);
    }

    if (p.hasCourtStay) {
      insertFactorStmt.run(p.id, "Active Court Injunction", "High", "Increases risk", "High Court stay order halts statutory possession proceedings on critical alignment.");
    }

    if (p.unresolvedLegalCases >= 3) {
      insertFactorStmt.run(p.id, "Pending Legal References", p.unresolvedLegalCases >= 5 ? "High" : "Medium", "Increases risk", `${p.unresolvedLegalCases} active reference petitions pending before Land Acquisition Authority.`);
    }

    if (p.incompleteDocumentsCount >= 10) {
      insertFactorStmt.run(p.id, "Land Records Mutation Backlog", p.incompleteDocumentsCount >= 20 ? "High" : "Medium", "Increases risk", `${p.incompleteDocumentsCount} title/mutation records pending revenue verification with local tehsil.`);
    }

    if (p.forestClearanceStage === 'Stage 2 Pending') {
      insertFactorStmt.run(p.id, "Forest Clearance Pending", "High", "Increases risk", "Stage 2 forest diversion approval awaited from MoEFCC.");
    }

    // Attention items
    if (p.hasCourtStay) {
      insertAttentionStmt.run(p.id, `Judicial stay petition active: ${p.courtDetails}`);
    }
    if (p.pendingCompensationCases > 0) {
      insertAttentionStmt.run(p.id, `${p.pendingCompensationCases} compensation claims awaiting disbursement authorization at district office`);
    }
    if (p.incompleteDocumentsCount > 5) {
      insertAttentionStmt.run(p.id, `${p.incompleteDocumentsCount} land title records awaiting revenue department verification`);
    }

    // Recommendations
    if (p.hasCourtStay) {
      insertRecStmt.run(p.id, "Consider coordinating with government pleader for expedited vacation of stay application");
    }
    if (p.compensationDisbursedPercent < 60) {
      insertRecStmt.run(p.id, "Consider organizing special village disbursement camps at tehsil office for undisputed Khatadars");
    }
    if (p.incompleteDocumentsCount > 10) {
      insertRecStmt.run(p.id, "Consider deputing additional revenue team for expedited mutation record clearing");
    }
    if (!p.hasCourtStay && p.compensationDisbursedPercent >= 80) {
      insertRecStmt.run(p.id, "Continue routine statutory monitoring as per milestone schedule");
    }
  }

  // Seed Dynamic Alerts
  const insertAlertStmt = db.prepare(`
    INSERT OR REPLACE INTO alerts (id, project_id, project_name, location, type, risk_change, reason, timestamp, status, recommended_action)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const initialAlerts = [
    {
      id: "ALT-2026-001",
      project_id: "DFCC-2026-012",
      project_name: "Eastern Dedicated Freight Corridor (Varanasi Feeder)",
      location: "Varanasi, Uttar Pradesh",
      type: "Court Stay Injunction",
      risk_change: "Escalated to High",
      reason: "Civil Judge Senior Division stay issued on ancestral partition parcels",
      timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      status: "New",
      recommended_action: "Consider filing counter-affidavit for vacation of interim stay order"
    },
    {
      id: "ALT-2026-002",
      project_id: "NHAI-2026-001",
      project_name: "Nashik-Pune Industrial Corridor (NH-60 Expansion)",
      location: "Nashik, Maharashtra",
      type: "Compensation Delayed",
      risk_change: "Moderate Slippage",
      reason: "14 compensation claims pending verification; 59% sanctioned fund undisbursed",
      timestamp: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
      status: "New",
      recommended_action: "Consider organizing special village disbursement camps at tehsil office"
    },
    {
      id: "ALT-2026-003",
      project_id: "NHAI-2026-042",
      project_name: "Gorakhpur-Siliguri Expressway (Package II)",
      location: "Gopalganj, Bihar",
      type: "Risk Increased",
      risk_change: "Medium → High",
      reason: "Delay probability escalated to 84% due to revenue record mismatches and court stay",
      timestamp: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
      status: "New",
      recommended_action: "Requires immediate administrative review and district inter-departmental meeting"
    },
    {
      id: "ALT-2026-004",
      project_id: "NHAI-2026-055",
      project_name: "Amritsar-Katra Expressway (Package VI)",
      location: "Gurdaspur, Punjab",
      type: "Court Stay Injunction",
      risk_change: "Escalated to High",
      reason: "High Court writ petition filed challenging compensation parity across Batala villages",
      timestamp: new Date(Date.now() - 9 * 3600 * 1000).toISOString(),
      status: "Acknowledged",
      recommended_action: "Coordinate with state advocate general for expeditious counter-reply"
    }
  ];

  for (const a of initialAlerts) {
    insertAlertStmt.run(
      a.id, a.project_id, a.project_name, a.location, a.type,
      a.risk_change, a.reason, a.timestamp, a.status, a.recommended_action
    );
  }

  // System metadata
  const insertMetaStmt = db.prepare("INSERT OR REPLACE INTO system_metadata (key, value) VALUES (?, ?)");
  insertMetaStmt.run("dataset_source", "Illustrative prototype dataset");
  insertMetaStmt.run("last_data_refresh", new Date().toISOString());
  insertMetaStmt.run("model_version", "v1.2-RF");
  insertMetaStmt.run("model_type", "Random Forest Classifier");
  insertMetaStmt.run("model_accuracy", "0.880");
  insertMetaStmt.run("model_f1", "0.850");
  insertMetaStmt.run("model_roc_auc", "0.883");
}

export function formatDbProject(row: any, db: DatabaseSync): Project {
  const projectId = row.id;

  const stagesStmt = db.prepare("SELECT stage, status, progress_percent, completed_date, notes FROM project_stages WHERE project_id = ? ORDER BY id");
  const stagesRows = stagesStmt.all(projectId) as any[];
  const stages = stagesRows.map(s => ({
    stage: s.stage,
    status: s.status,
    progressPercent: s.progress_percent,
    completedDate: s.completed_date || undefined,
    notes: s.notes || undefined
  }));

  const factorStmt = db.prepare("SELECT factor, impact_level, direction, detail FROM project_risk_factors WHERE project_id = ? ORDER BY id");
  const factorRows = factorStmt.all(projectId) as any[];
  const topRiskFactors: RiskFactor[] = factorRows.map(f => ({
    factor: f.factor,
    impactLevel: f.impact_level,
    direction: f.direction,
    detail: f.detail
  }));

  const attentionStmt = db.prepare("SELECT item_text FROM project_attention_items WHERE project_id = ? ORDER BY id");
  const attentionRows = attentionStmt.all(projectId) as any[];
  const attentionItems = attentionRows.map(a => a.item_text);

  const recStmt = db.prepare("SELECT recommendation_text FROM project_recommendations WHERE project_id = ? ORDER BY id");
  const recRows = recStmt.all(projectId) as any[];
  const recommendedActions = recRows.map(r => r.recommendation_text);

  return {
    id: row.id,
    name: row.name,
    sector: row.sector,
    state: row.state,
    district: row.district,
    talukOrTehsil: row.taluk_or_tehsil,
    coordinates: {
      lat: row.latitude,
      lng: row.longitude
    },
    currentStage: row.current_stage,
    stageStatus: row.stage_status,
    riskLevel: row.risk_level,
    delayProbability: Math.round(row.delay_probability),
    delayVarianceMonths: (row.delay_variance_months !== undefined && row.delay_variance_months !== null && Number(row.delay_variance_months) > 0)
      ? Number(Number(row.delay_variance_months).toFixed(1))
      : calculateDelayVarianceMonths({
          delayProbability: row.delay_probability,
          hasCourtStay: Boolean(row.has_court_stay),
          compensationDisbursedPercent: row.compensation_disbursed_percent,
          incompleteDocumentsCount: row.incomplete_documents_count,
          forestClearanceStage: row.forest_clearance_stage,
          pendingLandHa: row.pending_land_ha,
          totalLandRequiredHa: row.total_land_required_ha
        }),
    mainIssue: row.main_issue,
    totalLandRequiredHa: row.total_land_required_ha,
    landAcquiredHa: row.land_acquired_ha,
    pendingLandHa: row.pending_land_ha,
    privateLandHa: row.private_land_ha,
    govtLandHa: row.govt_land_ha,
    forestLandHa: row.forest_land_ha,
    compensationSanctionedCr: row.compensation_sanctioned_cr,
    compensationDisbursedCr: row.compensation_disbursed_cr,
    compensationDisbursedPercent: row.compensation_disbursed_percent,
    pendingCompensationCases: row.pending_compensation_cases,
    unresolvedLegalCases: row.unresolved_legal_cases,
    hasCourtStay: Boolean(row.has_court_stay),
    courtDetails: row.court_details || undefined,
    incompleteDocumentsCount: row.incomplete_documents_count,
    forestClearanceStage: row.forest_clearance_stage,
    stages,
    topRiskFactors,
    attentionItems,
    recommendedActions,
    lastUpdated: row.last_updated,
    isSynthetic: Boolean(row.is_synthetic),
    source: row.source || (row.is_synthetic ? 'Demo' : 'BhoomiRashi'),
    sourceProjectId: row.source_project_id || row.id,
    sourceUrl: row.source_url || undefined,
    act: row.act || 'National Highways Act 1956',
    highwayNumber: row.highway_number || undefined,
    agency: row.agency || 'NHAI',
    sourceLastUpdated: row.source_last_updated || row.last_updated,
    ingestedAt: row.ingested_at || row.last_updated
  };
}

export function queryProjects(params?: {
  search?: string;
  risk?: string;
  state?: string;
  district?: string;
  stage?: string;
  sortBy?: string;
  page?: number;
  pageSize?: number;
}): PaginatedProjects {
  const db = getDatabase();
  const conditions: string[] = [];
  const args: any[] = [];

  if (params?.search) {
    const q = `%${params.search.trim().toLowerCase()}%`;
    conditions.push(`(LOWER(name) LIKE ? OR LOWER(district) LIKE ? OR LOWER(state) LIKE ? OR LOWER(taluk_or_tehsil) LIKE ? OR LOWER(id) LIKE ? OR LOWER(COALESCE(source_project_id, '')) LIKE ?)`);
    args.push(q, q, q, q, q, q);
  }

  if (params?.risk && params.risk !== 'ALL') {
    conditions.push(`risk_level = ?`);
    args.push(params.risk.toUpperCase());
  }

  if (params?.state && params.state !== 'ALL') {
    conditions.push(`state = ?`);
    args.push(params.state);
  }

  if (params?.district && params.district !== 'ALL') {
    conditions.push(`district = ?`);
    args.push(params.district);
  }

  if (params?.stage && params.stage !== 'ALL') {
    conditions.push(`current_stage = ?`);
    args.push(params.stage);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  // Count total matching
  const countStmt = db.prepare(`SELECT COUNT(*) as total FROM projects ${whereClause}`);
  const countRes = countStmt.get(...args) as { total: number };
  const total = countRes ? countRes.total : 0;

  // Sorting
  let orderBy = "ORDER BY delay_probability DESC, total_land_required_ha DESC";
  if (params?.sortBy === 'name') {
    orderBy = "ORDER BY name ASC";
  } else if (params?.sortBy === 'progress') {
    orderBy = "ORDER BY (land_acquired_ha * 1.0 / total_land_required_ha) DESC";
  }

  const page = Math.max(1, params?.page || 1);
  const pageSize = Math.min(500, Math.max(1, params?.pageSize || 100));
  const offset = (page - 1) * pageSize;

  const dataStmt = db.prepare(`SELECT * FROM projects ${whereClause} ${orderBy} LIMIT ? OFFSET ?`);
  const rows = dataStmt.all(...args, pageSize, offset) as any[];

  const items = rows.map(r => formatDbProject(r, db));

  // Available states and districts
  const statesStmt = db.prepare("SELECT DISTINCT state FROM projects ORDER BY state");
  const availableStates = (statesStmt.all() as any[]).map(r => r.state);

  const districtsStmt = db.prepare("SELECT DISTINCT district FROM projects ORDER BY district");
  const availableDistricts = (districtsStmt.all() as any[]).map(r => r.district);

  return {
    items,
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize) || 1,
    availableStates,
    availableDistricts
  };
}

export function getProjectById(id: string): Project | undefined {
  const db = getDatabase();
  const cleanId = (id || '').trim();
  let row = db.prepare("SELECT * FROM projects WHERE id = ?").get(cleanId);
  if (!row) {
    const prefixed = cleanId.startsWith('BhoomiRashi_') ? cleanId : `BhoomiRashi_${cleanId}`;
    const unprefixed = cleanId.replace(/^BhoomiRashi_/, '');
    row = db.prepare(
      "SELECT * FROM projects WHERE source_project_id = ? OR id = ? OR id = ? LIMIT 1"
    ).get(unprefixed, prefixed, unprefixed);
  }
  if (!row) return undefined;
  return formatDbProject(row, db);
}

export function getDashboardSummary(): DashboardSummary {
  const db = getDatabase();

  const totalStmt = db.prepare("SELECT COUNT(*) as c FROM projects");
  const total = (totalStmt.get() as any).c;

  const highStmt = db.prepare("SELECT COUNT(*) as c FROM projects WHERE risk_level = 'HIGH'");
  const highRisk = (highStmt.get() as any).c;

  const medStmt = db.prepare("SELECT COUNT(*) as c FROM projects WHERE risk_level = 'MEDIUM'");
  const medRisk = (medStmt.get() as any).c;

  const lowStmt = db.prepare("SELECT COUNT(*) as c FROM projects WHERE risk_level = 'LOW'");
  const lowRisk = (lowStmt.get() as any).c;

  const landStmt = db.prepare("SELECT SUM(total_land_required_ha) as req, SUM(land_acquired_ha) as acq FROM projects");
  const landRes = landStmt.get() as any;
  const totalLandReq = landRes?.req || 0;
  const totalLandAcq = landRes?.acq || 0;
  const avgProgress = totalLandReq > 0 ? Math.round((totalLandAcq / totalLandReq) * 100) : 0;

  // High risk projects
  const highRiskRows = db.prepare("SELECT * FROM projects WHERE risk_level = 'HIGH' ORDER BY delay_probability DESC, total_land_required_ha DESC LIMIT 5").all() as any[];
  const highRiskProjects = highRiskRows.map(r => formatDbProject(r, db));

  // Recent alerts
  const alertsRows = db.prepare("SELECT * FROM alerts ORDER BY timestamp DESC LIMIT 4").all() as any[];
  const recentAlerts: AlertItem[] = alertsRows.map(a => ({
    id: a.id,
    projectId: a.project_id,
    projectName: a.project_name,
    location: a.location,
    type: a.type,
    riskChange: a.risk_change,
    reason: a.reason,
    timestamp: a.timestamp,
    status: a.status,
    recommendedAction: a.recommended_action
  }));

  // State breakdown
  const stateRows = db.prepare(`
    SELECT state,
           COUNT(*) as total,
           SUM(CASE WHEN risk_level = 'HIGH' THEN 1 ELSE 0 END) as high,
           SUM(CASE WHEN risk_level = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
           SUM(CASE WHEN risk_level = 'LOW' THEN 1 ELSE 0 END) as low
    FROM projects
    GROUP BY state
    ORDER BY high DESC, total DESC
  `).all() as any[];
  const stateBreakdown = stateRows.map(s => ({
    state: s.state,
    total: s.total,
    high: s.high,
    medium: s.medium,
    low: s.low
  }));

  // Stage breakdown
  const stageRows = db.prepare(`
    SELECT current_stage,
           COUNT(*) as total,
           SUM(CASE WHEN stage_status = 'Delayed' THEN 1 ELSE 0 END) as delayed
    FROM projects
    GROUP BY current_stage
  `).all() as any[];
  const stageBreakdown = stageRows.map(s => ({
    stage: s.current_stage,
    total: s.total,
    delayed: s.delayed
  }));

  const metaStmt = db.prepare("SELECT value FROM system_metadata WHERE key = 'last_data_refresh'");
  const metaRes = metaStmt.get() as any;
  const lastRefresh = metaRes ? metaRes.value : new Date().toISOString();

  return {
    totalProjects: total,
    highRiskCount: highRisk,
    mediumRiskCount: medRisk,
    onTrackCount: lowRisk,
    totalLandRequiredHa: Math.round(totalLandReq),
    totalLandAcquiredHa: Math.round(totalLandAcq),
    avgAcquisitionProgress: avgProgress,
    highRiskProjects,
    recentAlerts,
    stateBreakdown,
    stageBreakdown,
    dataFreshness: lastRefresh,
    isSyntheticNotice: "Illustrative prototype dataset"
  };
}

export function getAlerts(status?: string): AlertItem[] {
  const db = getDatabase();
  let query = "SELECT * FROM alerts ORDER BY timestamp DESC";
  let args: any[] = [];
  if (status && status !== 'ALL') {
    query = "SELECT * FROM alerts WHERE status = ? ORDER BY timestamp DESC";
    args = [status];
  }
  const rows = db.prepare(query).all(...args) as any[];
  return rows.map(a => ({
    id: a.id,
    projectId: a.project_id,
    projectName: a.project_name,
    location: a.location,
    type: a.type,
    riskChange: a.risk_change,
    reason: a.reason,
    timestamp: a.timestamp,
    status: a.status,
    recommendedAction: a.recommended_action
  }));
}

export function acknowledgeAlert(id: string): AlertItem | undefined {
  const db = getDatabase();
  const updateStmt = db.prepare("UPDATE alerts SET status = 'Acknowledged' WHERE id = ?");
  updateStmt.run(id);

  const getStmt = db.prepare("SELECT * FROM alerts WHERE id = ?");
  const a = getStmt.get(id) as any;
  if (!a) return undefined;
  return {
    id: a.id,
    projectId: a.project_id,
    projectName: a.project_name,
    location: a.location,
    type: a.type,
    riskChange: a.risk_change,
    reason: a.reason,
    timestamp: a.timestamp,
    status: a.status,
    recommendedAction: a.recommended_action
  };
}

export function getRiskMapData() {
  const db = getDatabase();
  const rows = db.prepare("SELECT id, name, state, district, latitude, longitude, risk_level, delay_probability, main_issue, current_stage, land_acquired_ha, total_land_required_ha FROM projects").all() as any[];
  return rows.map(p => ({
    id: p.id,
    name: p.name,
    location: `${p.district}, ${p.state}`,
    coordinates: {
      lat: p.latitude,
      lng: p.longitude
    },
    riskLevel: p.risk_level,
    delayProbability: Math.round(p.delay_probability),
    mainIssue: p.main_issue,
    currentStage: p.current_stage,
    landAcquiredHa: p.land_acquired_ha,
    totalLandRequiredHa: p.total_land_required_ha
  }));
}

export function getSystemStatus(): SystemStatus {
  const db = getDatabase();
  const totalStmt = db.prepare("SELECT COUNT(*) as c FROM projects");
  const count = (totalStmt.get() as any).c;

  const metaRows = db.prepare("SELECT key, value FROM system_metadata").all() as any[];
  const meta: Record<string, string> = {};
  for (const m of metaRows) {
    meta[m.key] = m.value;
  }

  return {
    status: "connected",
    backend: "BhoomiDrishti Core Service",
    database: "SQLite Database (Ready for PostgreSQL/PostGIS migration)",
    totalProjects: count,
    dataSource: meta.dataset_source || "Illustrative prototype dataset",
    lastDataRefresh: meta.last_data_refresh || new Date().toISOString(),
    modelVersion: meta.model_version || "v1.2-RF",
    modelType: meta.model_type || "Random Forest Classifier",
    modelAccuracy: parseFloat(meta.model_accuracy || "0.880"),
    modelF1: parseFloat(meta.model_f1 || "0.850"),
    modelRocAuc: parseFloat(meta.model_roc_auc || "0.883")
  };
}

export function getProjectHistory(projectId: string) {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT * FROM project_history
    WHERE project_id = ?
    ORDER BY changed_at DESC
  `);
  const rows = stmt.all(projectId) as any[];
  return rows.map(r => ({
    id: r.id,
    projectId: r.project_id,
    source: r.source,
    fieldChanged: r.field_changed,
    oldValue: r.old_value,
    newValue: r.new_value,
    changedAt: r.changed_at
  }));
}

export function getSyncRuns(limit = 10) {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT * FROM sync_runs
    ORDER BY started_at DESC
    LIMIT ?
  `);
  const rows = stmt.all(limit) as any[];
  return rows.map(r => ({
    syncId: r.sync_id,
    source: r.source,
    startedAt: r.started_at,
    completedAt: r.completed_at,
    status: r.status,
    recordsReceived: r.records_received,
    recordsValid: r.records_valid,
    recordsInserted: r.records_inserted,
    recordsUpdated: r.records_updated,
    recordsUnchanged: r.records_unchanged,
    recordsFailed: r.records_failed,
    durationMs: r.duration_ms,
    errorMessage: r.error_message
  }));
}

export function getDataSources(): DataSourceItem[] {
  const db = getDatabase();
  const stmt = db.prepare("SELECT * FROM data_sources ORDER BY name ASC");
  const rows = stmt.all() as any[];
  return rows.map(r => ({
    id: r.id,
    name: r.name,
    type: r.type,
    baseUrl: r.base_url,
    apiEndpoint: r.api_endpoint,
    description: r.description,
    enabled: Boolean(r.enabled),
    status: r.status,
    authType: r.auth_type,
    apiKey: r.api_key ? '••••••••' : '',
    syncIntervalMinutes: r.sync_interval_minutes,
    lastSyncStarted: r.last_sync_started,
    lastSyncCompleted: r.last_sync_completed,
    lastSuccessfulSync: r.last_successful_sync,
    recordsReceived: r.records_received || 0,
    recordsInserted: r.records_inserted || 0,
    recordsUpdated: r.records_updated || 0,
    recordsUnchanged: r.records_unchanged || 0,
    recordsFailed: r.records_failed || 0,
    errorMessage: r.error_message,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  }));
}

export function getDataSourceById(id: string): DataSourceItem | undefined {
  const db = getDatabase();
  const stmt = db.prepare("SELECT * FROM data_sources WHERE id = ?");
  const r = stmt.get(id) as any;
  if (!r) return undefined;
  return {
    id: r.id,
    name: r.name,
    type: r.type,
    baseUrl: r.base_url,
    apiEndpoint: r.api_endpoint,
    description: r.description,
    enabled: Boolean(r.enabled),
    status: r.status,
    authType: r.auth_type,
    apiKey: r.api_key ? '••••••••' : '',
    syncIntervalMinutes: r.sync_interval_minutes,
    lastSyncStarted: r.last_sync_started,
    lastSyncCompleted: r.last_sync_completed,
    lastSuccessfulSync: r.last_successful_sync,
    recordsReceived: r.records_received || 0,
    recordsInserted: r.records_inserted || 0,
    recordsUpdated: r.records_updated || 0,
    recordsUnchanged: r.records_unchanged || 0,
    recordsFailed: r.records_failed || 0,
    errorMessage: r.error_message,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

export function getRawDataSourceApiKey(id: string): string | null {
  const db = getDatabase();
  const stmt = db.prepare("SELECT api_key FROM data_sources WHERE id = ?");
  const r = stmt.get(id) as { api_key: string | null } | undefined;
  return r?.api_key || null;
}

export function updateDataSourceConfig(id: string, update: Partial<DataSourceItem>): DataSourceItem | undefined {
  const db = getDatabase();
  const current = getDataSourceById(id);
  if (!current) return undefined;

  const now = new Date().toISOString();
  let resolvedApiKey: string | null = null;
  let shouldUpdateApiKey = false;

  if (update.apiKey !== undefined) {
    if (update.apiKey === '••••••••' || update.apiKey === '********') {
      shouldUpdateApiKey = false;
    } else {
      shouldUpdateApiKey = true;
      resolvedApiKey = update.apiKey.trim() === '' ? null : update.apiKey.trim();
    }
  }

  const stmt = db.prepare(`
    UPDATE data_sources SET
      name = COALESCE(?, name),
      base_url = COALESCE(?, base_url),
      api_endpoint = COALESCE(?, api_endpoint),
      description = COALESCE(?, description),
      enabled = COALESCE(?, enabled),
      auth_type = COALESCE(?, auth_type),
      api_key = CASE WHEN ? = 1 THEN ? ELSE api_key END,
      sync_interval_minutes = COALESCE(?, sync_interval_minutes),
      updated_at = ?
    WHERE id = ?
  `);

  stmt.run(
    update.name !== undefined ? update.name : null,
    update.baseUrl !== undefined ? update.baseUrl : null,
    update.apiEndpoint !== undefined ? update.apiEndpoint : null,
    update.description !== undefined ? update.description : null,
    update.enabled !== undefined ? (update.enabled ? 1 : 0) : null,
    update.authType !== undefined ? update.authType : null,
    shouldUpdateApiKey ? 1 : 0,
    resolvedApiKey,
    update.syncIntervalMinutes !== undefined ? update.syncIntervalMinutes : null,
    now,
    id
  );

  insertAuditLog({
    id: `AUDIT_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId: 'admin',
    action: 'SOURCE_UPDATED',
    entityType: 'data_source',
    entityId: id,
    oldValue: JSON.stringify({ name: current.name, interval: current.syncIntervalMinutes, enabled: current.enabled }),
    newValue: JSON.stringify(update),
    timestamp: now
  });

  return getDataSourceById(id);
}

export function updateDataSourceSyncStats(id: string, stats: {
  status: string;
  recordsReceived: number;
  recordsInserted: number;
  recordsUpdated: number;
  recordsUnchanged: number;
  recordsFailed: number;
  errorMessage?: string | null;
  lastSuccessfulSync?: string;
  startedAt?: string;
  completedAt?: string;
}) {
  const db = getDatabase();
  const now = stats.completedAt || new Date().toISOString();
  const stmt = db.prepare(`
    UPDATE data_sources SET
      status = ?,
      records_received = ?,
      records_inserted = ?,
      records_updated = ?,
      records_unchanged = ?,
      records_failed = ?,
      error_message = ?,
      last_sync_started = COALESCE(?, last_sync_started),
      last_sync_completed = ?,
      last_successful_sync = COALESCE(?, last_successful_sync),
      updated_at = ?
    WHERE id = ?
  `);

  stmt.run(
    stats.status,
    stats.recordsReceived,
    stats.recordsInserted,
    stats.recordsUpdated,
    stats.recordsUnchanged,
    stats.recordsFailed,
    stats.errorMessage || null,
    stats.startedAt || null,
    now,
    stats.lastSuccessfulSync || (stats.status === 'SUCCESS' ? now : null),
    now,
    id
  );
}

export function insertValidationError(item: DataValidationErrorItem) {
  const db = getDatabase();
  const id = item.id || `VAL_ERR_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = item.createdAt || new Date().toISOString();
  const stmt = db.prepare(`
    INSERT INTO data_validation_errors (
      id, sync_id, source, row_number, project_identifier, field_name, severity, error_message, raw_value, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    id,
    item.syncId || null,
    item.source,
    item.rowNumber,
    item.projectIdentifier || null,
    item.fieldName,
    item.severity,
    item.errorMessage,
    item.rawValue ? String(item.rawValue) : null,
    now
  );
}

export function getValidationErrors(syncId?: string, limit = 50): DataValidationErrorItem[] {
  const db = getDatabase();
  let stmt;
  let rows: any[];
  if (syncId) {
    stmt = db.prepare("SELECT * FROM data_validation_errors WHERE sync_id = ? ORDER BY row_number ASC LIMIT ?");
    rows = stmt.all(syncId, limit) as any[];
  } else {
    stmt = db.prepare("SELECT * FROM data_validation_errors ORDER BY created_at DESC LIMIT ?");
    rows = stmt.all(limit) as any[];
  }
  return rows.map(r => ({
    id: r.id,
    syncId: r.sync_id,
    source: r.source,
    rowNumber: r.row_number,
    projectIdentifier: r.project_identifier,
    fieldName: r.field_name,
    severity: r.severity,
    errorMessage: r.error_message,
    rawValue: r.raw_value,
    createdAt: r.created_at
  }));
}

export function insertAuditLog(item: AuditLogItem) {
  const db = getDatabase();
  const id = item.id || `AUDIT_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = item.timestamp || new Date().toISOString();
  const stmt = db.prepare(`
    INSERT INTO audit_logs (id, user_id, action, entity_type, entity_id, old_value, new_value, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    id,
    item.userId || 'admin',
    item.action,
    item.entityType,
    item.entityId,
    item.oldValue || null,
    item.newValue || null,
    now
  );
}

export function getAuditLogs(limit = 50): AuditLogItem[] {
  const db = getDatabase();
  const stmt = db.prepare("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?");
  const rows = stmt.all(limit) as any[];
  return rows.map(r => ({
    id: r.id,
    userId: r.user_id,
    action: r.action,
    entityType: r.entity_type,
    entityId: r.entity_id,
    oldValue: r.old_value,
    newValue: r.new_value,
    timestamp: r.timestamp
  }));
}

export function getDatabaseOverview(): DatabaseOverview {
  const db = getDatabase();

  const totalStmt = db.prepare("SELECT COUNT(*) as count FROM projects");
  const totalProjects = (totalStmt.get() as any)?.count || 0;

  const totalRecordsStmt = db.prepare(`
    SELECT 
      (SELECT COUNT(*) FROM projects) +
      (SELECT COUNT(*) FROM project_stages) +
      (SELECT COUNT(*) FROM alerts) +
      (SELECT COUNT(*) FROM project_history) +
      (SELECT COUNT(*) FROM sync_runs) as total
  `);
  const totalRecords = (totalRecordsStmt.get() as any)?.total || totalProjects;

  let databaseSizeKb = 64;
  try {
    if (fs.existsSync(DB_PATH)) {
      const stats = fs.statSync(DB_PATH);
      databaseSizeKb = Math.round(stats.size / 1024);
    }
  } catch {
    databaseSizeKb = 128;
  }

  const meta = getSystemMetadata();
  const activeDataSource = meta.active_data_source || 'BhoomiRashi & LACRRIS Ingestion Architecture';
  const dataMode = (meta.data_mode || 'DEMO') as DataModeType;
  const lastSuccessfulSync = meta.last_successful_sync || null;

  const stateRows = db.prepare("SELECT state, COUNT(*) as count FROM projects GROUP BY state ORDER BY count DESC").all() as any[];
  const stageRows = db.prepare("SELECT current_stage as stage, COUNT(*) as count FROM projects GROUP BY current_stage ORDER BY count DESC").all() as any[];
  const statusRows = db.prepare("SELECT stage_status as status, COUNT(*) as count FROM projects GROUP BY stage_status ORDER BY count DESC").all() as any[];
  const riskRows = db.prepare("SELECT risk_level as riskLevel, COUNT(*) as count FROM projects GROUP BY risk_level ORDER BY count DESC").all() as any[];

  return {
    totalProjects,
    totalRecords,
    databaseSizeKb,
    storageEngine: 'SQLite (Single-File ACID Transactional Engine)',
    activeDataSource,
    dataMode,
    lastSuccessfulSync,
    byState: stateRows.map(r => ({ state: r.state, count: r.count })),
    byStage: stageRows.map(r => ({ stage: r.stage, count: r.count })),
    byStatus: statusRows.map(r => ({ status: r.status, count: r.count })),
    byRiskCategory: riskRows.map(r => ({ riskLevel: r.riskLevel, count: r.count }))
  };
}

export function updateProjectRecord(id: string, fields: Partial<Project>, userId = 'admin'): { success: boolean; project?: Project; error?: string } {
  const db = getDatabase();
  const existing = getProjectById(id);
  if (!existing) {
    return { success: false, error: 'Project record not found in database' };
  }

  const now = new Date().toISOString();

  // Validate numeric limits
  const totalLand = fields.totalLandRequiredHa !== undefined ? Number(fields.totalLandRequiredHa) : existing.totalLandRequiredHa;
  const landAcquired = fields.landAcquiredHa !== undefined ? Number(fields.landAcquiredHa) : existing.landAcquiredHa;
  if (landAcquired > totalLand * 1.5) {
    return { success: false, error: 'Land acquired exceeds maximum statutory corridor allocation' };
  }

  const compSanctioned = fields.compensationSanctionedCr !== undefined ? Number(fields.compensationSanctionedCr) : existing.compensationSanctionedCr;
  const compDisbursed = fields.compensationDisbursedCr !== undefined ? Number(fields.compensationDisbursedCr) : existing.compensationDisbursedCr;
  const compPercent = compSanctioned > 0 ? Math.min(100, Math.round((compDisbursed / compSanctioned) * 100)) : (fields.compensationDisbursedPercent !== undefined ? fields.compensationDisbursedPercent : existing.compensationDisbursedPercent);
  const pendingLand = Math.max(0, Math.round((totalLand - landAcquired) * 100) / 100);

  const currentStage = fields.currentStage || existing.currentStage;
  const stageStatus = fields.stageStatus || existing.stageStatus;
  const hasCourtStay = fields.hasCourtStay !== undefined ? (fields.hasCourtStay ? 1 : 0) : (existing.hasCourtStay ? 1 : 0);
  const unresolvedLegalCases = fields.unresolvedLegalCases !== undefined ? Number(fields.unresolvedLegalCases) : existing.unresolvedLegalCases;
  const incompleteDocs = fields.incompleteDocumentsCount !== undefined ? Number(fields.incompleteDocumentsCount) : existing.incompleteDocumentsCount;
  const forestClearance = fields.forestClearanceStage || existing.forestClearanceStage;
  const mainIssue = fields.mainIssue || existing.mainIssue;

  // Recalculate ML Risk Score based on modified feature vector
  const mlScore = predictDelayRisk({
    compensationDisbursedPercent: compPercent,
    hasCourtStay: Boolean(hasCourtStay),
    forestClearanceStage: forestClearance,
    incompleteDocumentsCount: incompleteDocs,
    unresolvedLegalCases: unresolvedLegalCases,
    totalLandRequiredHa: totalLand
  });

  const delayVariance = calculateDelayVarianceMonths({
    delayProbability: mlScore.delayProbability,
    hasCourtStay: Boolean(hasCourtStay),
    compensationDisbursedPercent: compPercent,
    incompleteDocumentsCount: incompleteDocs,
    forestClearanceStage: forestClearance,
    pendingLandHa: pendingLand,
    totalLandRequiredHa: totalLand
  });

  const recordHash = computeRecordHash({
    name: fields.name || existing.name,
    state: fields.state || existing.state,
    district: fields.district || existing.district,
    totalLandRequiredHa: totalLand,
    landAcquiredHa: landAcquired,
    currentStage: currentStage,
    stageStatus: stageStatus,
    compensationDisbursedPercent: compPercent,
    hasCourtStay: hasCourtStay,
    unresolvedLegalCases: unresolvedLegalCases,
    incompleteDocumentsCount: incompleteDocs,
    forestClearanceStage: forestClearance,
    sourceLastUpdated: now
  });

  const updateStmt = db.prepare(`
    UPDATE projects SET
      name = COALESCE(?, name),
      current_stage = ?,
      stage_status = ?,
      total_land_required_ha = ?,
      land_acquired_ha = ?,
      pending_land_ha = ?,
      compensation_sanctioned_cr = ?,
      compensation_disbursed_cr = ?,
      compensation_disbursed_percent = ?,
      unresolved_legal_cases = ?,
      has_court_stay = ?,
      court_details = COALESCE(?, court_details),
      incomplete_documents_count = ?,
      forest_clearance_stage = ?,
      main_issue = ?,
      risk_level = ?,
      delay_probability = ?,
      delay_variance_months = ?,
      record_hash = ?,
      last_updated = ?,
      updated_at = ?
    WHERE id = ?
  `);

  updateStmt.run(
    fields.name || null,
    currentStage,
    stageStatus,
    totalLand,
    landAcquired,
    pendingLand,
    compSanctioned,
    compDisbursed,
    compPercent,
    unresolvedLegalCases,
    hasCourtStay,
    fields.courtDetails || null,
    incompleteDocs,
    forestClearance,
    mainIssue,
    mlScore.riskLevel,
    mlScore.delayProbability,
    delayVariance,
    recordHash,
    now,
    now,
    id
  );

  // Record Audit Log
  const diffs: Record<string, { old: any; new: any }> = {};
  if (fields.landAcquiredHa !== undefined && fields.landAcquiredHa !== existing.landAcquiredHa) {
    diffs.landAcquiredHa = { old: existing.landAcquiredHa, new: fields.landAcquiredHa };
  }
  if (fields.currentStage !== undefined && fields.currentStage !== existing.currentStage) {
    diffs.currentStage = { old: existing.currentStage, new: fields.currentStage };
  }
  if (fields.hasCourtStay !== undefined && Boolean(fields.hasCourtStay) !== existing.hasCourtStay) {
    diffs.hasCourtStay = { old: existing.hasCourtStay, new: fields.hasCourtStay };
  }
  if (fields.compensationDisbursedPercent !== undefined && fields.compensationDisbursedPercent !== existing.compensationDisbursedPercent) {
    diffs.compensationDisbursedPercent = { old: existing.compensationDisbursedPercent, new: fields.compensationDisbursedPercent };
  }

  insertAuditLog({
    id: `AUDIT_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    action: 'PROJECT_UPDATED',
    entityType: 'project',
    entityId: id,
    oldValue: JSON.stringify({ risk: existing.riskLevel, delayProb: existing.delayProbability, diffs: Object.keys(diffs).reduce((acc, k) => ({ ...acc, [k]: diffs[k].old }), {}) }),
    newValue: JSON.stringify({ risk: mlScore.riskLevel, delayProb: mlScore.delayProbability, diffs: Object.keys(diffs).reduce((acc, k) => ({ ...acc, [k]: diffs[k].new }), {}) }),
    timestamp: now
  });

  // Record Project History
  for (const [key, change] of Object.entries(diffs)) {
    const histStmt = db.prepare(`
      INSERT INTO project_history (id, project_id, source, field_changed, old_value, new_value, changed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    histStmt.run(
      `HIST_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      id,
      existing.source || 'ManualAdmin',
      key,
      String(change.old),
      String(change.new),
      now
    );
  }

  const updatedProject = getProjectById(id);
  return { success: true, project: updatedProject };
}

export function exportData(type: 'all' | 'high_risk' | 'alerts' | 'audit_logs', format: 'csv' | 'json'): string | object {
  const db = getDatabase();

  if (type === 'alerts') {
    const alerts = getAlerts();
    if (format === 'json') return alerts;
    const headers = ['Alert ID', 'Project ID', 'Project Name', 'Location', 'Type', 'Risk Change', 'Reason', 'Status', 'Timestamp'];
    const rows = alerts.map(a => [a.id, a.projectId, `"${a.projectName}"`, `"${a.location}"`, `"${a.type}"`, `"${a.riskChange}"`, `"${a.reason}"`, a.status, a.timestamp]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  if (type === 'audit_logs') {
    const logs = getAuditLogs(500);
    if (format === 'json') return logs;
    const headers = ['Audit ID', 'User ID', 'Action', 'Entity Type', 'Entity ID', 'Timestamp', 'Old Value', 'New Value'];
    const rows = logs.map(l => [l.id, l.userId, l.action, l.entityType, l.entityId, l.timestamp, `"${(l.oldValue || '').replace(/"/g, '""')}"`, `"${(l.newValue || '').replace(/"/g, '""')}"`]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  let projectsStmt = "SELECT * FROM projects";
  if (type === 'high_risk') {
    projectsStmt += " WHERE risk_level = 'HIGH'";
  }
  projectsStmt += " ORDER BY delay_probability DESC";

  const rows = db.prepare(projectsStmt).all() as any[];
  const projects = rows.map(r => formatDbProject(r, db));

  if (format === 'json') {
    return projects;
  }

  const headers = [
    'Project ID', 'Name', 'State', 'District', 'Current Stage', 'Stage Status',
    'Risk Level', 'Delay Probability (%)', 'Land Required (Ha)', 'Land Acquired (Ha)',
    'Pending Land (Ha)', 'Comp Sanctioned (Cr)', 'Comp Disbursed (Cr)', 'Comp Disbursed (%)',
    'Court Stay', 'Unresolved Legal Cases', 'Forest Clearance Stage', 'Source', 'Source Project ID', 'Last Updated'
  ];

  const csvRows = projects.map(p => [
    p.id,
    `"${p.name.replace(/"/g, '""')}"`,
    p.state,
    p.district,
    `"${p.currentStage}"`,
    p.stageStatus,
    p.riskLevel,
    p.delayProbability,
    p.totalLandRequiredHa,
    p.landAcquiredHa,
    p.pendingLandHa,
    p.compensationSanctionedCr,
    p.compensationDisbursedCr,
    p.compensationDisbursedPercent,
    p.hasCourtStay ? 'YES' : 'NO',
    p.unresolvedLegalCases,
    `"${p.forestClearanceStage}"`,
    p.source || 'BhoomiRashi',
    p.sourceProjectId || p.id,
    p.lastUpdated
  ]);

  return [headers.join(','), ...csvRows.map(r => r.join(','))].join('\n');
}

export function getSystemMetadata(): Record<string, string> {
  const db = getDatabase();
  const rows = db.prepare("SELECT key, value FROM system_metadata").all() as any[];
  const res: Record<string, string> = {};
  for (const r of rows) {
    res[r.key] = r.value;
  }
  return res;
}

export function setSystemMetadata(key: string, value: string): void {
  const db = getDatabase();
  const stmt = db.prepare("INSERT INTO system_metadata (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value");
  stmt.run(key, value);
}


