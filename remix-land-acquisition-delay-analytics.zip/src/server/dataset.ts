import { Project, AlertItem } from '../types.ts';

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'NHAI-2026-001',
    name: 'Nashik-Pune Industrial Corridor (NH-60 Expansion)',
    sector: 'National Highways',
    state: 'Maharashtra',
    district: 'Nashik',
    talukOrTehsil: 'Sinnar',
    coordinates: { lat: 19.9975, lng: 73.7898 },
    currentStage: 'Compensation',
    stageStatus: 'Delayed',
    riskLevel: 'HIGH',
    delayProbability: 78,
    delayVarianceMonths: 9.5,
    mainIssue: 'Compensation pending for 34 title-disputed parcels in Sinnar Taluk',
    totalLandRequiredHa: 480.5,
    landAcquiredHa: 215.0,
    pendingLandHa: 265.5,
    privateLandHa: 380.0,
    govtLandHa: 65.5,
    forestLandHa: 35.0,
    compensationSanctionedCr: 142.5,
    compensationDisbursedCr: 58.4,
    compensationDisbursedPercent: 41,
    pendingCompensationCases: 14,
    unresolvedLegalCases: 4,
    hasCourtStay: true,
    courtDetails: 'Bombay High Court interim stay on 18 Ha agricultural land acquisition',
    incompleteDocumentsCount: 22,
    forestClearanceStage: 'Stage 2 Pending',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2024-04-12' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-11-20' },
      { stage: 'Compensation', status: 'Delayed', progressPercent: 41, notes: 'Disbursement slow due to joint ownership claims' },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 35 },
      { stage: 'Possession', status: 'Pending', progressPercent: 0 }
    ],
    topRiskFactors: [
      { factor: 'Compensation Pending', impactScore: 82, detail: '59% sanctioned compensation undisbursed across 14 village clusters' },
      { factor: 'Active Court Stay', impactScore: 74, detail: 'High Court injunction on 18 Ha awaiting hearing date' },
      { factor: 'Documentation Backlog', impactScore: 56, detail: '22 mutation entries pending with Talathi office' }
    ],
    attentionItems: [
      '14 compensation claims pending verification at District Land Acquisition Office',
      'High Court stay petition (WP/4921) requires urgent reply affidavit from NHAI PIU',
      'Stage 2 Forest clearance compliance report pending submission to MoEFCC'
    ],
    recommendedActions: [
      'Consider organizing special revenue camps at Sinnar for spot title settlement',
      'Prioritize filing counter-affidavit for vacation of High Court interim stay',
      'Coordinate with Sub-Divisional Officer (SDO) for expedited disbursement to undisputed heirs'
    ],
    lastUpdated: '2026-03-02'
  },
  {
    id: 'DFCC-2026-012',
    name: 'Eastern Dedicated Freight Corridor (Varanasi Feeder)',
    sector: 'Railways',
    state: 'Uttar Pradesh',
    district: 'Varanasi',
    talukOrTehsil: 'Pindra',
    coordinates: { lat: 25.3176, lng: 82.9739 },
    currentStage: 'Legal / Documentation',
    stageStatus: 'Delayed',
    riskLevel: 'HIGH',
    delayProbability: 84,
    delayVarianceMonths: 11.0,
    mainIssue: '7 unresolved heirship disputes and pending joint measurement surveys',
    totalLandRequiredHa: 320.0,
    landAcquiredHa: 138.2,
    pendingLandHa: 181.8,
    privateLandHa: 275.0,
    govtLandHa: 45.0,
    forestLandHa: 0,
    compensationSanctionedCr: 98.0,
    compensationDisbursedCr: 39.2,
    compensationDisbursedPercent: 40,
    pendingCompensationCases: 19,
    unresolvedLegalCases: 7,
    hasCourtStay: true,
    courtDetails: 'Civil Judge Senior Division stay regarding ancestral rights partition',
    incompleteDocumentsCount: 31,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2024-02-15' },
      { stage: 'Verification', status: 'Completed', progressPercent: 95, completedDate: '2024-09-10' },
      { stage: 'Compensation', status: 'Delayed', progressPercent: 40 },
      { stage: 'Legal / Documentation', status: 'Delayed', progressPercent: 28 },
      { stage: 'Possession', status: 'Pending', progressPercent: 0 }
    ],
    topRiskFactors: [
      { factor: 'Civil Court Litigation', impactScore: 88, detail: '7 separate partition suits impeding Section 19 notification' },
      { factor: 'Compensation Hold', impactScore: 78, detail: '₹58.8 Cr escrowed in court treasury due to conflicting claims' },
      { factor: 'Incomplete Land Records', impactScore: 65, detail: '31 parcels lack updated computerized RoR (Khatauni)' }
    ],
    attentionItems: [
      '19 compensation disbursement vouchers held due to missing partition deeds',
      '7 civil court notices pending representation by district government pleader',
      'Joint measurement survey pending for 42 Ha in Pindra circle'
    ],
    recommendedActions: [
      'Consider establishing a dedicated Lok Adalat bench for family partition settlements',
      'Deposit disputed compensation in reference court under Sec 77 of RFCTLARR Act to proceed with physical possession',
      'Direct District Magistrate to depute additional revenue staff for land record verification'
    ],
    lastUpdated: '2026-03-04'
  },
  {
    id: 'NHAI-2026-034',
    name: 'Delhi-Dehradun Economic Corridor (Saharanpur Bypass)',
    sector: 'National Highways',
    state: 'Uttar Pradesh',
    district: 'Saharanpur',
    talukOrTehsil: 'Behat',
    coordinates: { lat: 29.9679, lng: 77.5452 },
    currentStage: 'Possession',
    stageStatus: 'Delayed',
    riskLevel: 'HIGH',
    delayProbability: 73,
    delayVarianceMonths: 7.2,
    mainIssue: 'Physical possession resisted on 24 Ha private farmland demanding higher circle rate',
    totalLandRequiredHa: 260.0,
    landAcquiredHa: 195.0,
    pendingLandHa: 65.0,
    privateLandHa: 220.0,
    govtLandHa: 40.0,
    forestLandHa: 0,
    compensationSanctionedCr: 115.0,
    compensationDisbursedCr: 88.5,
    compensationDisbursedPercent: 77,
    pendingCompensationCases: 8,
    unresolvedLegalCases: 2,
    hasCourtStay: false,
    courtDetails: 'Arbitration appeal pending before Divisional Commissioner',
    incompleteDocumentsCount: 9,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-11-05' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-05-18' },
      { stage: 'Compensation', status: 'Completed', progressPercent: 77 },
      { stage: 'Legal / Documentation', status: 'Completed', progressPercent: 85 },
      { stage: 'Possession', status: 'Delayed', progressPercent: 55, notes: 'Physical resistance in 2 villages' }
    ],
    topRiskFactors: [
      { factor: 'Physical Possession Resistance', impactScore: 85, detail: 'Farmers union demanding enhanced compensation multiplier' },
      { factor: 'Pending Arbitration', impactScore: 68, detail: 'Arbitration cases pending with Arbitrator/Divisional Commissioner' },
      { factor: 'Partial Handover', impactScore: 52, detail: 'Isolated patches hindering contractor mobilization' }
    ],
    attentionItems: [
      '24 Ha land in 2 villages physically barricaded pending arbitration decision',
      'Arbitration hearing scheduled with Divisional Commissioner on 15th of current month',
      'Possession notices issued under Section 3E of NH Act requiring police assistance'
    ],
    recommendedActions: [
      'Consider organizing District Grievance Redressal meeting with farmer representatives',
      'Expedite arbitration orders with Divisional Commissioner to finalize awards',
      'Schedule joint administrative-police possession drive for undisputed acquired stretches'
    ],
    lastUpdated: '2026-03-01'
  },
  {
    id: 'METRO-2026-004',
    name: 'Bengaluru Metro Rail Phase 3 (Outer Ring Road West)',
    sector: 'Metro Rail',
    state: 'Karnataka',
    district: 'Bengaluru Urban',
    talukOrTehsil: 'Bengaluru South',
    coordinates: { lat: 12.9716, lng: 77.5946 },
    currentStage: 'Compensation',
    stageStatus: 'Delayed',
    riskLevel: 'HIGH',
    delayProbability: 76,
    delayVarianceMonths: 8.0,
    mainIssue: 'High commercial land acquisition costs and TDR negotiations stalled',
    totalLandRequiredHa: 68.4,
    landAcquiredHa: 28.5,
    pendingLandHa: 39.9,
    privateLandHa: 52.0,
    govtLandHa: 16.4,
    forestLandHa: 0,
    compensationSanctionedCr: 410.0,
    compensationDisbursedCr: 180.0,
    compensationDisbursedPercent: 44,
    pendingCompensationCases: 16,
    unresolvedLegalCases: 5,
    hasCourtStay: true,
    courtDetails: 'Karnataka High Court stay on demolition of 6 commercial multi-storey buildings',
    incompleteDocumentsCount: 14,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2024-01-20' },
      { stage: 'Verification', status: 'Completed', progressPercent: 90 },
      { stage: 'Compensation', status: 'Delayed', progressPercent: 44 },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 40 },
      { stage: 'Possession', status: 'Pending', progressPercent: 0 }
    ],
    topRiskFactors: [
      { factor: 'Commercial Valuation Disputes', impactScore: 84, detail: 'Property owners contesting KIADB guidance value determinations' },
      { factor: 'High Court Injunction', impactScore: 79, detail: 'Stay on 6 commercial properties blocking viaduct alignment' },
      { factor: 'TDR Allocation Delays', impactScore: 61, detail: 'BBMP TDR certificate issuance awaiting urban development approval' }
    ],
    attentionItems: [
      '6 commercial building owners granted interim protection by High Court',
      '16 package compensation awards pending concurrence from Urban Development Dept',
      'BBMP joint inspection required for utility shifting clearance'
    ],
    recommendedActions: [
      'Consider offering revised structural compensation formula under KIAD Act',
      'File urgent vacation application before Karnataka High Court citing public transit priority',
      'Convene joint meeting with BBMP Commissioner to fast-track Transfer of Development Rights (TDR)'
    ],
    lastUpdated: '2026-03-03'
  },
  {
    id: 'RICC-2026-018',
    name: 'Dighi Port Industrial Corridor Expressway',
    sector: 'Industrial Corridors',
    state: 'Maharashtra',
    district: 'Raigad',
    talukOrTehsil: 'Mangaon',
    coordinates: { lat: 18.2562, lng: 73.2842 },
    currentStage: 'Verification',
    stageStatus: 'Delayed',
    riskLevel: 'HIGH',
    delayProbability: 71,
    delayVarianceMonths: 6.8,
    mainIssue: 'Forest Stage 1 diversion compliance pending and tribal land NOC verification',
    totalLandRequiredHa: 340.0,
    landAcquiredHa: 110.0,
    pendingLandHa: 230.0,
    privateLandHa: 190.0,
    govtLandHa: 80.0,
    forestLandHa: 70.0,
    compensationSanctionedCr: 120.0,
    compensationDisbursedCr: 45.0,
    compensationDisbursedPercent: 38,
    pendingCompensationCases: 11,
    unresolvedLegalCases: 3,
    hasCourtStay: false,
    courtDetails: 'Tribal advisory council inquiry on Community Forest Rights (CFR)',
    incompleteDocumentsCount: 26,
    forestClearanceStage: 'Stage 2 Pending',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2024-03-10' },
      { stage: 'Verification', status: 'Delayed', progressPercent: 62 },
      { stage: 'Compensation', status: 'In Progress', progressPercent: 38 },
      { stage: 'Legal / Documentation', status: 'Pending', progressPercent: 15 },
      { stage: 'Possession', status: 'Pending', progressPercent: 0 }
    ],
    topRiskFactors: [
      { factor: 'Forest Rights Act (FRA) Clearances', impactScore: 81, detail: 'Gram Sabha resolutions pending in 4 tribal hamlets' },
      { factor: 'Forest Stage 2 Diversion', impactScore: 75, detail: 'Compensatory Afforestation (CA) land verification pending' },
      { factor: 'Compensation Incomplete', impactScore: 60, detail: 'Only 38% disbursed due to unverified tribal tenancy rights' }
    ],
    attentionItems: [
      '4 Gram Sabhas yet to pass formal consent resolutions under FRA 2006',
      'CA land inspection report awaited from Deputy Conservator of Forests (DCF)',
      '11 compensation packages require verification of non-transferable tribal tenancy'
    ],
    recommendedActions: [
      'Coordinate with District Collector to schedule Gram Sabha meetings with tribal welfare officers',
      'Finalize CA land parcel handover with DCF Raigad to satisfy Stage 2 conditions',
      'Prioritize direct benefit transfer to eligible verified tribal beneficiaries'
    ],
    lastUpdated: '2026-03-04'
  },
  {
    id: 'NHAI-2026-042',
    name: 'Ahmedabad-Dholera Expressway (Package 3)',
    sector: 'National Highways',
    state: 'Gujarat',
    district: 'Ahmedabad',
    talukOrTehsil: 'Dholera',
    coordinates: { lat: 22.2476, lng: 72.1932 },
    currentStage: 'Compensation',
    stageStatus: 'In Progress',
    riskLevel: 'MEDIUM',
    delayProbability: 54,
    delayVarianceMonths: 3.8,
    mainIssue: '8 compensation cases delayed due to ancestral mutation backlog in revenue records',
    totalLandRequiredHa: 510.0,
    landAcquiredHa: 360.0,
    pendingLandHa: 150.0,
    privateLandHa: 440.0,
    govtLandHa: 70.0,
    forestLandHa: 0,
    compensationSanctionedCr: 185.0,
    compensationDisbursedCr: 124.0,
    compensationDisbursedPercent: 67,
    pendingCompensationCases: 8,
    unresolvedLegalCases: 1,
    hasCourtStay: false,
    courtDetails: 'Single land boundary demarcation dispute in Taluka Mamlatdar court',
    incompleteDocumentsCount: 12,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-08-15' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-02-20' },
      { stage: 'Compensation', status: 'In Progress', progressPercent: 67 },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 70 },
      { stage: 'Possession', status: 'In Progress', progressPercent: 65 }
    ],
    topRiskFactors: [
      { factor: 'Revenue Mutation Delays', impactScore: 62, detail: 'E-Dhara system record sync pending for 12 Khatas' },
      { factor: 'Pending Compensation', impactScore: 55, detail: '₹61 Cr remaining to be disbursed upon succession clearance' },
      { factor: 'Boundary Demarcation', impactScore: 40, detail: 'Re-survey requested by 4 private landowners' }
    ],
    attentionItems: [
      '12 succession mutations pending verification with Dholera Mamlatdar',
      '₹61 Cr compensation fund allocated and ready in escrow account',
      'Joint DGPS re-survey scheduled for 8 agricultural parcels'
    ],
    recommendedActions: [
      'Request Mamlatdar Dholera to conduct weekend revenue mutation drive',
      'Issue disbursement cheques immediately upon upload of succession certificates',
      'Expedite DGPS survey team to resolve boundary overlap within 10 days'
    ],
    lastUpdated: '2026-03-02'
  },
  {
    id: 'RLY-2026-008',
    name: 'Pune-Miraj Railway Doubling (Satara Stretch)',
    sector: 'Railways',
    state: 'Maharashtra',
    district: 'Satara',
    talukOrTehsil: 'Karad',
    coordinates: { lat: 17.2885, lng: 74.1834 },
    currentStage: 'Legal / Documentation',
    stageStatus: 'In Progress',
    riskLevel: 'MEDIUM',
    delayProbability: 49,
    delayVarianceMonths: 3.2,
    mainIssue: '5 court cases regarding compensation enhancement under Section 64',
    totalLandRequiredHa: 195.0,
    landAcquiredHa: 145.0,
    pendingLandHa: 50.0,
    privateLandHa: 160.0,
    govtLandHa: 35.0,
    forestLandHa: 0,
    compensationSanctionedCr: 88.0,
    compensationDisbursedCr: 65.0,
    compensationDisbursedPercent: 74,
    pendingCompensationCases: 6,
    unresolvedLegalCases: 5,
    hasCourtStay: false,
    courtDetails: 'Reference court petitions for enhanced solatium; no stay on possession',
    incompleteDocumentsCount: 7,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-09-12' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-03-15' },
      { stage: 'Compensation', status: 'In Progress', progressPercent: 74 },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 65 },
      { stage: 'Possession', status: 'In Progress', progressPercent: 60 }
    ],
    topRiskFactors: [
      { factor: 'Solatium Enhancement Claims', impactScore: 58, detail: 'Claimants seeking 100% additional solatium under LARR Act' },
      { factor: 'Pending Possession Handover', impactScore: 50, detail: '50 Ha yet to be demarcated with railway boundary stones' },
      { factor: 'Documentation Queries', impactScore: 38, detail: '7 indemnity bonds pending legal vetting' }
    ],
    attentionItems: [
      'Reference court cases pending without stay; possession can legally proceed',
      '6 compensation vouchers awaiting submission of bank mandate forms',
      'Boundary stone laying completed for 145 Ha'
    ],
    recommendedActions: [
      'Proceed with physical possession under Sec 38 as compensation is deposited in reference court',
      'Direct revenue field officers to collect remaining bank mandate forms',
      'Brief government advocate for unified defense in reference court'
    ],
    lastUpdated: '2026-03-01'
  },
  {
    id: 'ENRG-2026-021',
    name: 'Green Energy Corridor Ultra-High Voltage Substation',
    sector: 'Energy & Grid',
    state: 'Rajasthan',
    district: 'Jaipur',
    talukOrTehsil: 'Chaksu',
    coordinates: { lat: 26.6042, lng: 75.9528 },
    currentStage: 'Compensation',
    stageStatus: 'In Progress',
    riskLevel: 'MEDIUM',
    delayProbability: 46,
    delayVarianceMonths: 2.8,
    mainIssue: 'Right of Way (RoW) compensation dispute on 14 transmission tower footings',
    totalLandRequiredHa: 140.0,
    landAcquiredHa: 105.0,
    pendingLandHa: 35.0,
    privateLandHa: 120.0,
    govtLandHa: 20.0,
    forestLandHa: 0,
    compensationSanctionedCr: 45.0,
    compensationDisbursedCr: 32.5,
    compensationDisbursedPercent: 72,
    pendingCompensationCases: 7,
    unresolvedLegalCases: 2,
    hasCourtStay: false,
    courtDetails: 'Writ petition in Jaipur bench regarding crop damages assessment',
    incompleteDocumentsCount: 5,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2024-01-10' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-06-12' },
      { stage: 'Compensation', status: 'In Progress', progressPercent: 72 },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 80 },
      { stage: 'Possession', status: 'In Progress', progressPercent: 70 }
    ],
    topRiskFactors: [
      { factor: 'Tower Footing Compensation', impactScore: 54, detail: 'Farmers disputing tower base land valuation vs line corridor valuation' },
      { factor: 'Crop Damage Assessment', impactScore: 48, detail: 'Horticulture damage assessment report pending from District Agri Dept' },
      { factor: 'Transmission Line Stringing', impactScore: 35, detail: '3 tower sites blocked by local landholders' }
    ],
    attentionItems: [
      'District Horticulture Officer report on orchard valuation due this week',
      '7 farmers scheduled for direct negotiation at District Collectorate',
      'Line stringing contractor on standby awaiting RoW clearance'
    ],
    recommendedActions: [
      'Adopt Ministry of Power revised 2024 RoW guidelines for tower footing compensation',
      'Release interim crop damage ex-gratia to unblock tower erection',
      'Deploy SDM Chaksu for spot conciliation'
    ],
    lastUpdated: '2026-03-03'
  },
  {
    id: 'NHAI-2026-055',
    name: 'Chennai-Bengaluru Expressway (Package 4)',
    sector: 'National Highways',
    state: 'Tamil Nadu',
    district: 'Salem',
    talukOrTehsil: 'Omalur',
    coordinates: { lat: 11.7454, lng: 78.0436 },
    currentStage: 'Possession',
    stageStatus: 'Completed',
    riskLevel: 'LOW',
    delayProbability: 18,
    delayVarianceMonths: 0.5,
    mainIssue: 'Minor boundary fence relocation on 3 Ha government poramboke land',
    totalLandRequiredHa: 380.0,
    landAcquiredHa: 368.0,
    pendingLandHa: 12.0,
    privateLandHa: 320.0,
    govtLandHa: 60.0,
    forestLandHa: 0,
    compensationSanctionedCr: 160.0,
    compensationDisbursedCr: 154.0,
    compensationDisbursedPercent: 96,
    pendingCompensationCases: 2,
    unresolvedLegalCases: 0,
    hasCourtStay: false,
    incompleteDocumentsCount: 2,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-04-10' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2023-10-15' },
      { stage: 'Compensation', status: 'Completed', progressPercent: 96, completedDate: '2024-08-20' },
      { stage: 'Legal / Documentation', status: 'Completed', progressPercent: 98, completedDate: '2024-11-30' },
      { stage: 'Possession', status: 'In Progress', progressPercent: 95 }
    ],
    topRiskFactors: [
      { factor: 'Minor Boundary Demarcation', impactScore: 22, detail: 'Final verification of 12 Ha government land transfer' },
      { factor: 'Residual Disbursements', impactScore: 16, detail: '2 claimants untraced; funds deposited in treasury' },
      { factor: 'Fencing Coordination', impactScore: 12, detail: 'Civil contractor erecting boundary pillars' }
    ],
    attentionItems: [
      'Revenue divisional officer transfer order for 12 Ha poramboke land prepared',
      'All private land compensation disbursed (96% overall)',
      'No pending legal stays or litigation'
    ],
    recommendedActions: [
      'Complete final handover certificate under Section 3E',
      'Transfer remaining unclaimed compensation to revenue deposit account'
    ],
    lastUpdated: '2026-03-02'
  },
  {
    id: 'EXPR-2026-061',
    name: 'Purvanchal Expressway Link to Buxar',
    sector: 'National Highways',
    state: 'Uttar Pradesh',
    district: 'Ghazipur',
    talukOrTehsil: 'Zamania',
    coordinates: { lat: 25.4312, lng: 83.5657 },
    currentStage: 'Possession',
    stageStatus: 'Completed',
    riskLevel: 'LOW',
    delayProbability: 22,
    delayVarianceMonths: 0.8,
    mainIssue: 'Final mutation updates in Bhoomi Rashi portal for 8 revenue villages',
    totalLandRequiredHa: 290.0,
    landAcquiredHa: 275.0,
    pendingLandHa: 15.0,
    privateLandHa: 250.0,
    govtLandHa: 40.0,
    forestLandHa: 0,
    compensationSanctionedCr: 110.0,
    compensationDisbursedCr: 102.5,
    compensationDisbursedPercent: 93,
    pendingCompensationCases: 3,
    unresolvedLegalCases: 0,
    hasCourtStay: false,
    incompleteDocumentsCount: 3,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-06-15' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2023-12-10' },
      { stage: 'Compensation', status: 'Completed', progressPercent: 93, completedDate: '2024-09-05' },
      { stage: 'Legal / Documentation', status: 'Completed', progressPercent: 95, completedDate: '2024-12-18' },
      { stage: 'Possession', status: 'In Progress', progressPercent: 92 }
    ],
    topRiskFactors: [
      { factor: 'Portal Data Entry', impactScore: 24, detail: 'Final upload of possession memo in Bhoomi Rashi' },
      { factor: 'Residual Cases', impactScore: 18, detail: '3 minor compensation claims under verification' }
    ],
    attentionItems: [
      'Over 94% of total alignment in physical possession of UPEIDA',
      'Contractor earthwork active on 90% of corridor'
    ],
    recommendedActions: [
      'Complete final digital record sync with District Land Acquisition Officer',
      'Sanction final completion certificate for acquisition package'
    ],
    lastUpdated: '2026-03-04'
  },
  {
    id: 'RLY-2026-077',
    name: 'Sambalpur-Talcher Rail Line Doubling',
    sector: 'Railways',
    state: 'Odisha',
    district: 'Sambalpur',
    talukOrTehsil: 'Rairakhol',
    coordinates: { lat: 21.4669, lng: 83.9812 },
    currentStage: 'Possession',
    stageStatus: 'Completed',
    riskLevel: 'LOW',
    delayProbability: 15,
    delayVarianceMonths: 0.2,
    mainIssue: 'All statutory stages complete; final stone demarcation underway',
    totalLandRequiredHa: 225.0,
    landAcquiredHa: 220.0,
    pendingLandHa: 5.0,
    privateLandHa: 170.0,
    govtLandHa: 45.0,
    forestLandHa: 10.0,
    compensationSanctionedCr: 75.0,
    compensationDisbursedCr: 73.0,
    compensationDisbursedPercent: 97,
    pendingCompensationCases: 1,
    unresolvedLegalCases: 0,
    hasCourtStay: false,
    incompleteDocumentsCount: 1,
    forestClearanceStage: 'Stage 2 Approved',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-03-20' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2023-09-15' },
      { stage: 'Compensation', status: 'Completed', progressPercent: 97, completedDate: '2024-06-25' },
      { stage: 'Legal / Documentation', status: 'Completed', progressPercent: 100, completedDate: '2024-10-10' },
      { stage: 'Possession', status: 'Completed', progressPercent: 98 }
    ],
    topRiskFactors: [
      { factor: 'Routine Formalities', impactScore: 15, detail: 'Final joint inspection report with forest department' }
    ],
    attentionItems: [
      '100% forest diversion conditions satisfied with approved CA land',
      'All 98% land handed over to East Coast Railway'
    ],
    recommendedActions: [
      'Close acquisition record and archive in State Land Bank database'
    ],
    lastUpdated: '2026-03-01'
  },
  {
    id: 'NHAI-2026-089',
    name: 'Nagpur Ring Road Northern Bypass (Package 2)',
    sector: 'National Highways',
    state: 'Maharashtra',
    district: 'Nagpur',
    talukOrTehsil: 'Kamptee',
    coordinates: { lat: 21.1458, lng: 79.0882 },
    currentStage: 'Compensation',
    stageStatus: 'In Progress',
    riskLevel: 'MEDIUM',
    delayProbability: 51,
    delayVarianceMonths: 3.5,
    mainIssue: 'Partial compensation release pending verification of Non-Agricultural (NA) status',
    totalLandRequiredHa: 310.0,
    landAcquiredHa: 210.0,
    pendingLandHa: 100.0,
    privateLandHa: 260.0,
    govtLandHa: 50.0,
    forestLandHa: 0,
    compensationSanctionedCr: 135.0,
    compensationDisbursedCr: 88.0,
    compensationDisbursedPercent: 65,
    pendingCompensationCases: 9,
    unresolvedLegalCases: 2,
    hasCourtStay: false,
    courtDetails: '2 writ petitions before Nagpur Bench for NA market valuation',
    incompleteDocumentsCount: 15,
    forestClearanceStage: 'Not Required',
    stages: [
      { stage: 'Identification', status: 'Completed', progressPercent: 100, completedDate: '2023-10-20' },
      { stage: 'Verification', status: 'Completed', progressPercent: 100, completedDate: '2024-04-12' },
      { stage: 'Compensation', status: 'In Progress', progressPercent: 65 },
      { stage: 'Legal / Documentation', status: 'In Progress', progressPercent: 60 },
      { stage: 'Possession', status: 'In Progress', progressPercent: 50 }
    ],
    topRiskFactors: [
      { factor: 'NA Valuation Claims', impactScore: 60, detail: 'Plot owners claiming commercial rates for peri-urban layouts' },
      { factor: 'Documentation Verification', impactScore: 52, detail: '15 town planning layout approval certificates pending verification' },
      { factor: 'Pending Compensation', impactScore: 48, detail: '₹47 Cr undisbursed pending layout legitimacy confirmation' }
    ],
    attentionItems: [
      'Nagpur Metropolitan Region Development Authority (NMRDA) verification awaited for 15 layouts',
      '2 writ petitions pending hearing; state advocate briefed to argue for non-stay',
      'Over 67% physical corridor cleared for construction'
    ],
    recommendedActions: [
      'Convene joint meeting with NMRDA Town Planner to verify layout sanctions within 14 days',
      'Release undisputed agricultural component of compensation to willing owners'
    ],
    lastUpdated: '2026-03-03'
  }
];

export const INITIAL_ALERTS: AlertItem[] = [
  {
    id: 'ALT-101',
    projectId: 'NHAI-2026-001',
    projectName: 'Nashik-Pune Industrial Corridor (NH-60 Expansion)',
    location: 'Nashik, Maharashtra',
    type: 'Court Stay Injunction',
    riskChange: 'Medium → High',
    reason: 'Bombay High Court granted interim stay on 18 Ha agricultural land parcel in Sinnar Taluk.',
    timestamp: '2 hours ago',
    status: 'New',
    recommendedAction: 'Consider prioritizing counter-affidavit filing with District Government Pleader to vacate stay.'
  },
  {
    id: 'ALT-102',
    projectId: 'DFCC-2026-012',
    projectName: 'Eastern Dedicated Freight Corridor (Varanasi Feeder)',
    location: 'Varanasi, Uttar Pradesh',
    type: 'Risk Increased',
    riskChange: 'Medium → High',
    reason: 'Delay probability escalated to 84% due to 7 unresolved heirship partition suits.',
    timestamp: '5 hours ago',
    status: 'New',
    recommendedAction: 'Consider depositing disputed compensation into reference court under Sec 77 to proceed with possession.'
  },
  {
    id: 'ALT-103',
    projectId: 'METRO-2026-004',
    projectName: 'Bengaluru Metro Rail Phase 3 (Outer Ring Road West)',
    location: 'Bengaluru Urban, Karnataka',
    type: 'Compensation Delayed',
    riskChange: 'Low → High',
    reason: 'Commercial property owners contested KIADB structural compensation; 6 stay petitions filed.',
    timestamp: '1 day ago',
    status: 'New',
    recommendedAction: 'Coordinate with Urban Development Dept and BBMP to finalize enhanced TDR allocation package.'
  },
  {
    id: 'ALT-104',
    projectId: 'NHAI-2026-034',
    projectName: 'Delhi-Dehradun Economic Corridor (Saharanpur Bypass)',
    location: 'Saharanpur, Uttar Pradesh',
    type: 'Milestone Lapsed',
    riskChange: 'Medium → High',
    reason: 'Physical possession milestone lapsed by 90 days due to farmer agitation demanding circle rate revision.',
    timestamp: '2 days ago',
    status: 'Acknowledged',
    recommendedAction: 'Schedule District Grievance Redressal Committee meeting chaired by District Magistrate.'
  },
  {
    id: 'ALT-105',
    projectId: 'RICC-2026-018',
    projectName: 'Dighi Port Industrial Corridor Expressway',
    location: 'Raigad, Maharashtra',
    type: 'Risk Increased',
    riskChange: 'Low → High',
    reason: 'Stage 2 Forest Clearance pending due to delay in Gram Sabha resolutions under Forest Rights Act.',
    timestamp: '3 days ago',
    status: 'Acknowledged',
    recommendedAction: 'Request District Collector Raigad to depute Tribal Welfare Officers for Gram Sabha conciliation.'
  }
];
