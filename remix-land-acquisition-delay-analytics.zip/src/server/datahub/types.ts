/**
 * Data Hub Type Definitions
 * Phase 1: BhoomiRashi Data Collection & Synchronization Hub
 * Smart India Hackathon 2026 - SIH26017
 */

export type DiscoveryMethod = 'AUTO_DISCOVERED' | 'MANUALLY_REGISTERED' | 'IMPORTED' | 'DEMO';
export type DataStatus = 'SYNCHRONIZED' | 'RECENTLY_UPDATED' | 'UNCHANGED' | 'SOURCE_ERROR' | 'IMPORTED' | 'DEMO';
export type SyncRunStatus = 'RUNNING' | 'SUCCESS' | 'PARTIAL' | 'FAILED';
export type HistoryChangeType = 'INITIAL' | 'UPDATED' | 'UNCHANGED' | 'IMPORTED';

export interface DataHubSource {
  id: string;
  source_name: string;
  organization: string;
  base_url: string;
  source_type: string;
  enabled: boolean;
  check_interval_minutes: number;
  last_check_at: string | null;
  last_success_at: string | null;
  last_error_at: string | null;
  next_check_at: string | null;
  status: 'CONNECTED' | 'CHECKING' | 'ERROR' | 'DISABLED';
  created_at: string;
  updated_at: string;
}

export interface SourceProjectRecord {
  id: string;
  source_name: string;
  source_project_id: string;
  project_number: string | null;
  project_name: string;
  source_url: string;
  discovery_method: DiscoveryMethod;
  first_seen_at: string;
  last_checked_at: string | null;
  last_changed_at: string | null;
  current_hash: string | null;
  source_status: string;
  data_status: DataStatus;
  created_at: string;
  updated_at: string;
}

export interface ProjectCurrentRecord {
  source_project_id: string;
  project_name: string;
  project_number: string | null;
  state: string | null;
  district: string | null;
  implementing_agency: string | null;
  highway_number: string | null;
  land_required: number;
  land_available: number;
  land_to_be_acquired: number;
  land_acquired_till_now: number;
  sanction_number: string | null;
  sanction_date: string | null;
  sanction_amount: number | null;
  additional_info: string | null; // JSON
  created_at: string;
  updated_at: string;
  last_source_check: string;
}

export interface Project3aNotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  cala: string | null;
  villages: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface Project3ANotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  survey_numbers: string | null;
  objections: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface Project3dNotification {
  id: string;
  source_project_id: string;
  publish_date: string | null;
  notification_number: string | null;
  survey_numbers: string | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface ProjectSanction {
  id: string;
  source_project_id: string;
  sanction_number: string | null;
  sanction_date: string | null;
  sanction_amount: number | null;
  status: string | null;
  raw_value: string | null;
  created_at: string;
}

export interface ProjectConsentPurchase {
  id: string;
  source_project_id: string;
  state: string | null;
  district: string | null;
  sub_district: string | null;
  village: string | null;
  survey_number: string | null;
  land_party: string | null;
  amount: number | null;
  disbursement_details: string | null;
  created_at: string;
}

export interface ProjectHistoryRecord {
  id: string;
  source_project_id: string;
  snapshot_hash: string;
  snapshot_json: string;
  captured_at: string;
  change_type: HistoryChangeType;
}

export interface SyncRunRecord {
  id: string;
  source_name: string;
  started_at: string;
  completed_at: string | null;
  status: SyncRunStatus;
  projects_checked: number;
  new_projects: number;
  updated_projects: number;
  unchanged_projects: number;
  error_projects: number;
  error_message: string | null;
}

export interface SyncChangeRecord {
  id: string;
  sync_run_id: string;
  source_project_id: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  detected_at: string;
  project_name?: string;
}

export interface SyncErrorRecord {
  id: string;
  sync_run_id: string;
  source_project_id: string;
  error_type: string;
  error_message: string;
  http_status: number | null;
  occurred_at: string;
  retry_count: number;
}

export interface NormalizedProjectPayload {
  sourceProjectId: string;
  projectName: string;
  projectNumber: string;
  state: string;
  district: string;
  implementingAgency: string;
  highwayNumber: string;
  landRequired: number;
  landAvailable: number;
  landToBeAcquired: number;
  landAcquiredTillNow: number;
  sanctionNumber?: string;
  sanctionDate?: string;
  sanctionAmount?: number;
  notifications3a: Partial<Project3aNotification>[];
  notifications3A: Partial<Project3ANotification>[];
  notifications3d: Partial<Project3dNotification>[];
  sanctions: Partial<ProjectSanction>[];
  consentPurchases: Partial<ProjectConsentPurchase>[];
  additionalInfo?: Record<string, any>;
  rawValues?: Record<string, string>;
}

export interface SourceTestResult {
  sourceProjectId: string;
  sourceUrl: string;
  httpStatus: number;
  responseTimeMs: number;
  htmlLength: number;
  canonicalHash: string;
  parsingSuccess: boolean;
  validationSuccess: boolean;
  fieldsExtractedCount: number;
  status: string; // e.g. "HTTP 200 — OK (PARSED)", "HTTP 200 — PARSE FAILED", "HTTP 200 — VALIDATION FAILED", "HTTP 404 — NOT FOUND", "NETWORK ERROR"
  reason?: string;
  fetchedAt: string;
  extractedSample: {
    projectName?: string;
    projectNumber?: string;
    state?: string;
    district?: string;
    implementingAgency?: string;
    highwayNumber?: string;
    landRequired?: number;
    landAvailable?: number;
    landToBeAcquired?: number;
    landAcquiredTillNow?: number;
    sanctionNumber?: string;
    sanctionDate?: string;
    sanctionAmount?: number;
    notificationsCount?: number;
  };
  note?: string;
  success: boolean;
}

export interface DataHubStatusOverview {
  source: {
    name: string;
    organization: string;
    url: string;
    status: string;
  };
  totalRegisteredProjects: number;
  lastCheck: string | null;
  nextCheck: string | null;
  lastSuccessfulSync: string | null;
  syncIntervalMinutes: number;
  currentRunStatus: string;
  counts: {
    newProjects: number;
    updatedProjects: number;
    unchangedProjects: number;
    errorProjects: number;
  };
}
