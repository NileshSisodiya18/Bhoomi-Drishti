/**
 * BhoomiRashi Source Collector & Semantic HTML Parser
 * Phase 1 Data Hub Collector
 * Ministry of Road Transport & Highways (MoRTH)
 * Smart India Hackathon 2026 - SIH26017
 */

import { createHash } from 'node:crypto';
import { NormalizedProjectPayload, SourceTestResult } from './types.ts';
import { getUpdatedFixture60940 } from './fixtures.ts';
import { ChangeDetectionEngine } from './changeDetection.ts';

export interface ParseValidationResult {
  success: boolean;
  parsingSuccess: boolean;
  validationSuccess: boolean;
  payload?: NormalizedProjectPayload;
  reason?: string;
  fieldsExtractedCount: number;
}

export class BhoomiRashiCollector {
  private static readonly BASE_URL = 'https://bhoomirashi.gov.in';
  private static readonly PUBLIC_DETAIL_PATH = '/auth/revamp/prep_public.cshtml?nid=1&project_id=';
  private static readonly REQUEST_TIMEOUT_MS = 8000;

  // Toggle for automated verification test fixture (Section 42 test)
  private static simulateUpdatedFixtureFor60940 = false;

  public static setSimulateUpdateFor60940(enabled: boolean) {
    this.simulateUpdatedFixtureFor60940 = enabled;
  }

  public static isSimulatingUpdateFor60940(): boolean {
    return this.simulateUpdatedFixtureFor60940;
  }

  /**
   * Generates public project detail URL
   */
  public static getPublicUrl(projectId: string): string {
    return `${this.BASE_URL}${this.PUBLIC_DETAIL_PATH}${encodeURIComponent(projectId.trim())}`;
  }

  /**
   * Fetches and parses a public project detail page from BhoomiRashi.
   * STRICT: In live mode, network/HTTP/parse/validation failures return explicit errors.
   * No fixture substitution occurs in live mode.
   */
  public static async fetchAndParseProject(projectId: string): Promise<{
    success: boolean;
    httpStatus: number;
    responseTimeMs: number;
    payload?: NormalizedProjectPayload;
    rawHtml?: string;
    errorMessage?: string;
    parsingSuccess?: boolean;
    validationSuccess?: boolean;
  }> {
    const cleanId = projectId.trim();
    const url = this.getPublicUrl(cleanId);
    const startMs = Date.now();

    // Section 42 automated verification test toggle for Project 60940
    if (cleanId === '60940' && this.simulateUpdatedFixtureFor60940) {
      const updated = getUpdatedFixture60940();
      return {
        success: true,
        httpStatus: 200,
        responseTimeMs: 34,
        payload: updated,
        parsingSuccess: true,
        validationSuccess: true
      };
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.REQUEST_TIMEOUT_MS);

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 BhoomiDrishti-Monitor/2.5 (SIH26017 Government Data Pipeline)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startMs;
      const html = await response.text();

      if (!response.ok) {
        return {
          success: false,
          httpStatus: response.status,
          responseTimeMs: latencyMs,
          rawHtml: html,
          errorMessage: `BhoomiRashi public portal returned HTTP ${response.status}: ${response.statusText}`,
          parsingSuccess: false,
          validationSuccess: false
        };
      }

      // Parse and strictly validate the HTML response
      const parseResult = this.parseAndValidateHtml(cleanId, html);

      if (parseResult.success && parseResult.payload) {
        return {
          success: true,
          httpStatus: response.status,
          responseTimeMs: latencyMs,
          payload: parseResult.payload,
          rawHtml: html,
          parsingSuccess: true,
          validationSuccess: true
        };
      }

      return {
        success: false,
        httpStatus: response.status,
        responseTimeMs: latencyMs,
        rawHtml: html,
        errorMessage: parseResult.reason || 'Failed to extract valid project data from BhoomiRashi portal.',
        parsingSuccess: parseResult.parsingSuccess,
        validationSuccess: parseResult.validationSuccess
      };

    } catch (err: any) {
      const latencyMs = Date.now() - startMs;
      const isTimeout = err.name === 'AbortError';

      return {
        success: false,
        httpStatus: isTimeout ? 504 : 0,
        responseTimeMs: latencyMs,
        errorMessage: isTimeout
          ? `Connection to BhoomiRashi timed out after ${this.REQUEST_TIMEOUT_MS}ms`
          : `Network error connecting to bhoomirashi.gov.in: ${err.message || 'Host unreachable'}`,
        parsingSuccess: false,
        validationSuccess: false
      };
    }
  }

  /**
   * Helper to unescape HTML entities and strip tags cleanly
   */
  private static cleanText(str: string | undefined | null): string {
    if (!str) return '';
    return str
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Robust parser and validator for BhoomiRashi project detail HTML.
   */
  public static parseAndValidateHtml(projectId: string, html: string): ParseValidationResult {
    if (!html || typeof html !== 'string' || html.trim().length < 100) {
      return {
        success: false,
        parsingSuccess: false,
        validationSuccess: false,
        reason: 'Empty or insufficient HTML response from server (project not found or invalid ID)',
        fieldsExtractedCount: 0
      };
    }

    // Check for authentication, CAPTCHA, or maintenance walls
    if (html.includes('Please Login') || html.includes('User Login') || html.includes('Enter Captcha')) {
      return {
        success: false,
        parsingSuccess: false,
        validationSuccess: false,
        reason: 'Encountered authentication or CAPTCHA requirement on BhoomiRashi portal',
        fieldsExtractedCount: 0
      };
    }

    if (html.includes('No Record Found') || html.includes('Project not found') || html.includes('Page Under Construction')) {
      return {
        success: false,
        parsingSuccess: false,
        validationSuccess: false,
        reason: `No record found for project ID ${projectId} on BhoomiRashi portal`,
        fieldsExtractedCount: 0
      };
    }

    // Extract all <table> elements
    const tables = html.match(/<table[^>]*>[\s\S]*?<\/table>/gi) || [];
    if (tables.length === 0) {
      return {
        success: false,
        parsingSuccess: false,
        validationSuccess: false,
        reason: 'No data tables detected in HTML response',
        fieldsExtractedCount: 0
      };
    }

    let projectName = '';
    let projectNumber = '';
    let landRequired = 0;
    let landAvailable = 0;
    let landToBeAcquired = 0;
    let landAcquiredTillNow = 0;
    let state = '';
    let district = '';
    let highwayNumber = '';
    let implementingAgency = '';

    // ==========================================
    // 1. Process Table 0: Basic Details
    // ==========================================
    const basicTable = tables[0];
    const trs = basicTable.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];

    for (const tr of trs) {
      const cells = (tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) || []).map(c => ({
        raw: c,
        text: this.cleanText(c)
      }));

      for (let i = 0; i < cells.length; i++) {
        const txt = cells[i].text.toLowerCase();

        if (txt.includes('project name') && cells[i + 1]) {
          // Bilingual separation: English text is before <br />
          const rawContent = cells[i + 1].raw;
          const parts = rawContent.replace(/<t[dh][^>]*>|<\/t[dh]>/gi, '').split(/<br\s*\/?>/i);
          projectName = this.cleanText(parts[0]);
        } else if (txt.includes('project number') && cells[i + 1]) {
          projectNumber = this.cleanText(cells[i + 1].text);
        } else if (txt === 'land required' && cells[i + 1]) {
          landRequired = this.parseNumber(cells[i + 1].text);
        } else if (txt.includes('land available') && cells[i + 1]) {
          landAvailable = this.parseNumber(cells[i + 1].text);
        } else if (txt.includes('land to be acquired') && cells[i + 1]) {
          landToBeAcquired = this.parseNumber(cells[i + 1].text);
        } else if (txt.includes('land acquired till now') && cells[i + 1]) {
          landAcquiredTillNow = this.parseNumber(cells[i + 1].text);
        } else if (txt === 'state' && cells[i + 1]) {
          state = this.cleanText(cells[i + 1].text);
        } else if (txt === 'district' && cells[i + 1]) {
          district = this.cleanText(cells[i + 1].text);
        } else if ((txt.includes('nh no') || txt.includes('highway')) && cells[i + 1]) {
          highwayNumber = this.cleanText(cells[i + 1].text);
        } else if (txt.includes('implementing agency') && cells[i + 1]) {
          implementingAgency = this.cleanText(cells[i + 1].text);
        }
      }
    }

    // Broad fallback if cells were arranged differently
    if (!projectName) {
      const m = html.match(/Project\s+Name[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/i);
      if (m) {
        const parts = m[1].split(/<br\s*\/?>/i);
        projectName = this.cleanText(parts[0]);
      }
    }

    if (!projectNumber) {
      const m = html.match(/Project\s+Number[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/i);
      if (m) projectNumber = this.cleanText(m[1]);
    }

    // Derive Highway Number from Project Name if not in a separate cell
    if (!highwayNumber && projectName) {
      const hwMatch = projectName.match(/(?:NH|NE|National\s+Highway)[\s\-]*[0-9]+[A-Z\-]*(?:\s*\/\s*(?:NH|NE)[\s\-]*[0-9]+[A-Z\-]*)*/i);
      if (hwMatch) {
        highwayNumber = hwMatch[0].trim();
      }
    }

    // Derive State from Project Name if not in cell
    const INDIAN_STATES = [
      'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa',
      'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala',
      'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland',
      'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
      'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu & Kashmir', 'Ladakh'
    ];

    if (!state && projectName) {
      const stateMatch = projectName.match(/in\s+the\s+(?:state|State)\s+of\s+([A-Za-z\s]+?)(?:,|\.|\s*[-–—]|\s+Section|\s+on|\s*$|\n)/i);
      if (stateMatch) {
        state = stateMatch[1].trim();
      } else {
        const found = INDIAN_STATES.find(st => new RegExp(`\\b${st}\\b`, 'i').test(projectName));
        if (found) state = found;
      }
    }

    // Derive District from alignment or name if not in cell
    if (!district && projectName) {
      const stopWords = new Set(['lane', 'two', 'four', 'six', 'km', 'existing', 'paved', 'shoulder', 'from', 'near', 'junction', 'section', 'package', 'corridor']);
      const parenMatch = projectName.match(/\(([A-Za-z]+)\s+to\s+([A-Za-z]+)\)/i);
      const distMatch1 = projectName.match(/([A-Za-z]+)\s+District/i);
      const distMatch2 = projectName.match(/(?:from|connecting)\s+([A-Za-z]+)\s+to\s+([A-Za-z]+)/i);

      if (distMatch1) {
        district = distMatch1[1].trim();
      } else if (parenMatch && !stopWords.has(parenMatch[1].toLowerCase())) {
        district = parenMatch[1].trim();
      } else if (distMatch2 && !stopWords.has(distMatch2[2].toLowerCase())) {
        district = distMatch2[2].trim();
      } else if (distMatch2 && !stopWords.has(distMatch2[1].toLowerCase())) {
        district = distMatch2[1].trim();
      }
    }

    // Implementing Agency derivation from Project Number prefix
    if (!implementingAgency) {
      if (projectNumber.startsWith('NI/')) {
        implementingAgency = 'National Highways Authority of India (NHAI)';
      } else if (projectNumber.startsWith('MO/')) {
        implementingAgency = 'Ministry of Road Transport & Highways (MoRTH)';
      } else if (projectNumber.startsWith('NHIDCL/')) {
        implementingAgency = 'National Highways and Infrastructure Development Corporation (NHIDCL)';
      } else {
        implementingAgency = 'National Highways Authority of India (NHAI)';
      }
    }

    // ==========================================
    // 2. Process Table 1: Sanction Details
    // ==========================================
    let sanctionNumber = '';
    let sanctionDate = '';
    let sanctionAmount = 0;
    const sanctions: { sanction_number: string; sanction_date: string; sanction_amount: number }[] = [];

    const sanctionTable = tables.find(t => t.includes('Sanction Details') || t.includes('Sanction Number'));
    if (sanctionTable) {
      const sTrs = sanctionTable.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
      for (const str of sTrs) {
        if (str.includes('Sanction Number') || str.includes('Sanction Date') || str.includes('Total')) continue;
        const cols = (str.match(/<td[^>]*>[\s\S]*?<\/td>/gi) || []).map(c => this.cleanText(c.split(/<br\s*\/?>/i)[0]));
        if (cols.length >= 3 && cols[0] && cols[1]) {
          const sNum = cols[0];
          const sDt = this.normalizeDate(cols[1]);
          const sAmt = this.parseNumber(cols[2]);
          if (sAmt > 0 || sNum) {
            sanctions.push({ sanction_number: sNum, sanction_date: sDt, sanction_amount: sAmt });
            if (!sanctionNumber) {
              sanctionNumber = sNum;
              sanctionDate = sDt;
              sanctionAmount = sAmt;
            }
          }
        }
      }
    }

    // ==========================================
    // 3. Process Table 2: 3a Notifications
    // ==========================================
    const notifications3a: { notification_number: string; publish_date: string; status: string }[] = [];
    const t3a = tables.find(t => t.includes('Project 3a Notifications') || t.includes('3a Notified'));
    if (t3a) {
      const rows = t3a.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
      for (const r of rows) {
        if (r.includes('Publish Date') || r.includes('Sno')) continue;
        const cols = (r.match(/<td[^>]*>[\s\S]*?<\/td>/gi) || []).map(c => this.cleanText(c.split(/<br\s*\/?>/i)[0]));
        if (cols.length >= 4 && cols[2]) {
          notifications3a.push({
            notification_number: cols[2],
            publish_date: this.normalizeDate(cols[1]),
            status: cols[4] || '3a Notified'
          });
        }
      }
    }

    // ==========================================
    // 4. Process Table 3: 3A Notifications
    // ==========================================
    const notifications3A: { notification_number: string; publish_date: string; status: string }[] = [];
    const t3A = tables.find(t => t.includes('Project 3A Notifications') || (t.includes('3A Notified') && !t.includes('3a Notified')));
    if (t3A) {
      const rows = t3A.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
      for (const r of rows) {
        if (r.includes('Publish Date') || r.includes('S.No') || r.includes('Sno')) continue;
        const cols = (r.match(/<td[^>]*>[\s\S]*?<\/td>/gi) || []).map(c => this.cleanText(c.split(/<br\s*\/?>/i)[0]));
        if (cols.length >= 5 && cols[2]) {
          notifications3A.push({
            notification_number: cols[2],
            publish_date: this.normalizeDate(cols[1]),
            status: cols[5] || cols[4] || '3A Notified'
          });
        }
      }
    }

    // ==========================================
    // 5. Process Table 4: 3D Notifications
    // ==========================================
    const notifications3d: { notification_number: string; publish_date: string; status: string }[] = [];
    const t3D = tables.find(t => t.includes('Project 3D Notifications') || t.includes('3D Notified'));
    if (t3D) {
      const rows = t3D.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
      for (const r of rows) {
        if (r.includes('Publish Date') || r.includes('Sno')) continue;
        const cols = (r.match(/<td[^>]*>[\s\S]*?<\/td>/gi) || []).map(c => this.cleanText(c.split(/<br\s*\/?>/i)[0]));
        if (cols.length >= 4 && cols[1] && cols[2]) {
          notifications3d.push({
            notification_number: cols[2],
            publish_date: this.normalizeDate(cols[1]),
            status: cols[4] || '3D Notified'
          });
        }
      }
    }

    // ==========================================
    // STRICT VALIDATION CHECKS (Section 4)
    // ==========================================
    const lowerName = projectName.toLowerCase();
    const isGenericName =
      !projectName ||
      lowerName === 'land acquisition portal' ||
      lowerName.includes('bhoomirashi project') ||
      lowerName === 'bhoomirashi' ||
      projectName.trim().length < 10;

    if (isGenericName) {
      return {
        success: false,
        parsingSuccess: true,
        validationSuccess: false,
        reason: `Validation failed: Rejected generic or missing project name ("${projectName || 'empty'}")`,
        fieldsExtractedCount: 0
      };
    }

    if (!projectNumber || projectNumber.trim().length < 3) {
      return {
        success: false,
        parsingSuccess: true,
        validationSuccess: false,
        reason: 'Validation failed: Missing official project number in portal response',
        fieldsExtractedCount: 1
      };
    }

    // Verify project number or HTML content associates with requested project ID
    const matchesProjectId = projectNumber.includes(projectId) || html.includes(projectId);
    if (!matchesProjectId) {
      return {
        success: false,
        parsingSuccess: true,
        validationSuccess: false,
        reason: `Validation failed: Extracted record (${projectNumber}) does not match requested project ID ${projectId}`,
        fieldsExtractedCount: 2
      };
    }

    if (landRequired <= 0 && landToBeAcquired <= 0) {
      return {
        success: false,
        parsingSuccess: true,
        validationSuccess: false,
        reason: 'Validation failed: Invalid or zero statutory land acquisition requirement',
        fieldsExtractedCount: 2
      };
    }

    // Count valid extracted fields
    const payload: NormalizedProjectPayload = {
      sourceProjectId: projectId,
      projectName,
      projectNumber,
      state: state || '',
      district: district || '',
      implementingAgency,
      highwayNumber,
      landRequired,
      landAvailable,
      landToBeAcquired: landToBeAcquired > 0 ? landToBeAcquired : landRequired,
      landAcquiredTillNow,
      sanctionNumber,
      sanctionDate,
      sanctionAmount,
      notifications3a,
      notifications3A,
      notifications3d,
      sanctions,
      consentPurchases: [],
      rawValues: {
        land_required: String(landRequired),
        land_available: String(landAvailable),
        land_to_be_acquired: String(landToBeAcquired),
        land_acquired_till_now: String(landAcquiredTillNow)
      }
    };

    const extractedFields = [
      payload.projectName,
      payload.projectNumber,
      payload.state,
      payload.district,
      payload.implementingAgency,
      payload.highwayNumber,
      payload.landRequired > 0 ? payload.landRequired : null,
      payload.landAvailable !== undefined ? payload.landAvailable : null,
      payload.landToBeAcquired > 0 ? payload.landToBeAcquired : null,
      payload.landAcquiredTillNow >= 0 ? payload.landAcquiredTillNow : null,
      payload.sanctionNumber,
      payload.sanctionDate,
      payload.sanctionAmount > 0 ? payload.sanctionAmount : null,
      ...payload.notifications3a,
      ...payload.notifications3A,
      ...payload.notifications3d,
      ...payload.sanctions
    ].filter(v => v !== undefined && v !== null && v !== '');

    return {
      success: true,
      parsingSuccess: true,
      validationSuccess: true,
      payload,
      fieldsExtractedCount: extractedFields.length
    };
  }

  /**
   * Semantic parser for BhoomiRashi public project detail HTML.
   * Backward compatible wrapper around parseAndValidateHtml.
   */
  public static parseHtml(projectId: string, html: string): NormalizedProjectPayload | null {
    const res = this.parseAndValidateHtml(projectId, html);
    return res.success && res.payload ? res.payload : null;
  }

  /**
   * Live source diagnostic testing per Section 10 & 11.
   * Completely READ-ONLY: Does not mutate database, projects, history, or risk scores.
   */
  public static async testSource(projectId: string): Promise<SourceTestResult> {
    const cleanId = projectId.trim() || '60940';
    const url = this.getPublicUrl(cleanId);
    const startMs = Date.now();

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.REQUEST_TIMEOUT_MS);

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 BhoomiDrishti-Monitor/2.5 (SIH26017 Government Data Pipeline)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startMs;
      const html = await response.text();
      const htmlLength = html.length;

      if (!response.ok) {
        const is404 = response.status === 404;
        return {
          sourceProjectId: cleanId,
          sourceUrl: url,
          httpStatus: response.status,
          responseTimeMs: latencyMs,
          htmlLength,
          canonicalHash: '',
          parsingSuccess: false,
          validationSuccess: false,
          fieldsExtractedCount: 0,
          status: is404 ? 'HTTP 404 — NOT FOUND' : `HTTP ${response.status} — ERROR`,
          reason: `Portal responded with HTTP ${response.status}: ${response.statusText}`,
          fetchedAt: new Date().toISOString(),
          extractedSample: {},
          note: `HTTP ${response.status} error from BhoomiRashi server`,
          success: false
        };
      }

      // Execute parsing and validation
      const parseResult = this.parseAndValidateHtml(cleanId, html);

      if (parseResult.success && parseResult.payload) {
        const canonical = ChangeDetectionEngine.generateCanonicalHash(parseResult.payload);
        const p = parseResult.payload;

        return {
          sourceProjectId: cleanId,
          sourceUrl: url,
          httpStatus: 200,
          responseTimeMs: latencyMs,
          htmlLength,
          canonicalHash: canonical.hash,
          parsingSuccess: true,
          validationSuccess: true,
          fieldsExtractedCount: parseResult.fieldsExtractedCount,
          status: 'HTTP 200 — OK (PARSED)',
          fetchedAt: new Date().toISOString(),
          extractedSample: {
            projectName: p.projectName,
            projectNumber: p.projectNumber,
            state: p.state,
            district: p.district,
            implementingAgency: p.implementingAgency,
            highwayNumber: p.highwayNumber,
            landRequired: p.landRequired,
            landAvailable: p.landAvailable,
            landToBeAcquired: p.landToBeAcquired,
            landAcquiredTillNow: p.landAcquiredTillNow,
            sanctionNumber: p.sanctionNumber,
            sanctionDate: p.sanctionDate,
            sanctionAmount: p.sanctionAmount,
            notificationsCount: (p.notifications3a?.length || 0) + (p.notifications3A?.length || 0) + (p.notifications3d?.length || 0)
          },
          note: 'Public project detail page retrieved and parsed successfully with genuine statutory metrics.',
          success: true
        };
      }

      // Parsing or validation failed on HTTP 200 response
      const status = parseResult.parsingSuccess && !parseResult.validationSuccess
        ? 'HTTP 200 — VALIDATION FAILED'
        : 'HTTP 200 — PARSE FAILED';

      const canonicalHash = htmlLength > 0
        ? createHash('sha256').update(html).digest('hex').substring(0, 32)
        : '';

      return {
        sourceProjectId: cleanId,
        sourceUrl: url,
        httpStatus: 200,
        responseTimeMs: latencyMs,
        htmlLength,
        canonicalHash,
        parsingSuccess: parseResult.parsingSuccess,
        validationSuccess: parseResult.validationSuccess,
        fieldsExtractedCount: parseResult.fieldsExtractedCount,
        status,
        reason: parseResult.reason || 'Parser or validation constraint rejected document',
        fetchedAt: new Date().toISOString(),
        extractedSample: parseResult.payload ? {
          projectName: parseResult.payload.projectName,
          projectNumber: parseResult.payload.projectNumber
        } : {},
        note: parseResult.reason || 'Failed to extract valid project data from BhoomiRashi response.',
        success: false
      };

    } catch (err: any) {
      const latencyMs = Date.now() - startMs;
      const isTimeout = err.name === 'AbortError';

      return {
        sourceProjectId: cleanId,
        sourceUrl: url,
        httpStatus: isTimeout ? 504 : 0,
        responseTimeMs: latencyMs,
        htmlLength: 0,
        canonicalHash: '',
        parsingSuccess: false,
        validationSuccess: false,
        fieldsExtractedCount: 0,
        status: 'NETWORK ERROR',
        reason: isTimeout
          ? `Connection to BhoomiRashi timed out after ${this.REQUEST_TIMEOUT_MS}ms`
          : `Network error connecting to bhoomirashi.gov.in: ${err.message || 'Host unreachable'}`,
        fetchedAt: new Date().toISOString(),
        extractedSample: {},
        note: isTimeout ? 'Request timed out' : 'Network connectivity failure',
        success: false
      };
    }
  }

  /**
   * Helper: Normalize dates (DD/MM/YYYY or DD-MM-YYYY to ISO YYYY-MM-DD)
   */
  public static normalizeDate(dateStr: string): string {
    if (!dateStr) return '';
    const cleaned = this.cleanText(dateStr);
    const dmyMatch = cleaned.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (dmyMatch) {
      const day = dmyMatch[1].padStart(2, '0');
      const month = dmyMatch[2].padStart(2, '0');
      const year = dmyMatch[3];
      return `${year}-${month}-${day}`;
    }
    return cleaned;
  }

  /**
   * Helper: Normalize numeric strings ("1,902.48" to 1902.48)
   */
  public static parseNumber(val: any): number {
    if (typeof val === 'number') return isNaN(val) ? 0 : val;
    if (!val) return 0;
    const cleanStr = String(val).replace(/,/g, '').replace(/[^\d.-]/g, '').trim();
    const parsed = parseFloat(cleanStr);
    return isNaN(parsed) ? 0 : parsed;
  }
}

