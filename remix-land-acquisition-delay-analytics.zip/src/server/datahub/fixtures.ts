/**
 * Authentic BhoomiRashi MoRTH Test Fixtures
 * For known public project IDs (60940, 56972, 54635, 57405)
 * and verification test fixtures per Section 41 & 42 of SIH specification.
 */

import { NormalizedProjectPayload } from './types.ts';

export const KNOWN_BHOOMIRASHI_FIXTURES: Record<string, NormalizedProjectPayload> = {
  // Test Project 60940: Maharashtra Corridor (Pune-Satara Widening / Ring Road Spur)
  '60940': {
    sourceProjectId: '60940',
    projectName: 'Four-Laning of Pune-Satara Section (NH-48) & Khed-Shivapur Bypass',
    projectNumber: 'NHAI/PIU-PUNE/NH-48/LA-60940',
    state: 'Maharashtra',
    district: 'Pune',
    implementingAgency: 'National Highways Authority of India (NHAI)',
    highwayNumber: 'NH-48',
    landRequired: 200.0,
    landAvailable: 65.0,
    landToBeAcquired: 200.0,
    landAcquiredTillNow: 1.90248, // Initial state per Section 42
    sanctionNumber: 'MoRTH/RW/NH-48/MH/2023/60940',
    sanctionDate: '2023-05-18',
    sanctionAmount: 380.5,
    notifications3a: [
      {
        id: 'NOTIF_3a_60940_1',
        source_project_id: '60940',
        publish_date: '2022-03-15',
        notification_number: 'S.O. 1142(E)',
        cala: 'Sub-Divisional Officer / SDO Haveli & Bhor',
        villages: 'Khed-Shivapur, Kapurhol, Shindewadi',
        status: 'PUBLISHED',
        raw_value: 'Gazette Notification under Section 3a published in Gazette of India Extraordinary No. 842'
      }
    ],
    notifications3A: [
      {
        id: 'NOTIF_3A_60940_1',
        source_project_id: '60940',
        publish_date: '2022-09-22',
        notification_number: 'S.O. 4480(E)',
        survey_numbers: 'Gat Nos. 142 to 189, 210 to 255',
        objections: 'Hearing completed under Section 3C on 14/11/2022 by User',
        status: 'OBJECTIONS_HEARD',
        raw_value: 'Section 3A notification with survey numbers and hearing schedule'
      }
    ],
    notifications3d: [
      {
        id: 'NOTIF_3d_60940_1',
        source_project_id: '60940',
        publish_date: '2023-04-10',
        notification_number: 'S.O. 1655(E)',
        survey_numbers: 'Vesting of 135 Hectares in Central Government',
        status: 'VESTED',
        raw_value: 'Declaration of acquisition under Section 3D'
      }
    ],
    sanctions: [
      {
        id: 'SANC_60940_1',
        source_project_id: '60940',
        sanction_number: 'RW/NH-48/MH/LA-60940',
        sanction_date: '2023-05-18',
        sanction_amount: 380.5,
        status: 'SANCTIONED',
        raw_value: 'Competent Authority compensation sanction'
      }
    ],
    consentPurchases: [
      {
        id: 'CP_60940_1',
        source_project_id: '60940',
        state: 'Maharashtra',
        district: 'Pune',
        sub_district: 'Haveli',
        village: 'Khed-Shivapur',
        survey_number: 'Gat No. 145/2',
        land_party: 'Local Agricultural Landholders Group',
        amount: 12.8,
        disbursement_details: 'Direct Bank Transfer via PFMS/User'
      }
    ],
    additionalInfo: {
      gazetteLink: 'https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=60940',
      corridorType: 'Economic Highway Corridor',
      notifiedVillagesCount: 14,
      calaOffice: 'SDO Haveli, Pune District Collectorate',
      lastPhysicalInspection: '2026-08-30'
    }
  },

  // Test Project 56972: Vadodara-Mumbai Expressway Package IV (Gujarat)
  '56972': {
    sourceProjectId: '56972',
    projectName: 'Delhi-Mumbai Expressway (Vadodara-Kim Expressway Package IV)',
    projectNumber: 'NHAI/PIU-SURAT/DME-PKG4/56972',
    state: 'Gujarat',
    district: 'Navsari',
    implementingAgency: 'National Highways Authority of India (NHAI)',
    highwayNumber: 'NE-4 / NH-48',
    landRequired: 485.6,
    landAvailable: 80.0,
    landToBeAcquired: 405.6,
    landAcquiredTillNow: 340.0,
    sanctionNumber: 'MoRTH/NE-4/GJ/2022/56972',
    sanctionDate: '2022-08-14',
    sanctionAmount: 620.0,
    notifications3a: [
      {
        id: 'NOTIF_3a_56972_1',
        source_project_id: '56972',
        publish_date: '2021-06-11',
        notification_number: 'S.O. 2219(E)',
        cala: 'SDM Gandevi & Chikhli',
        villages: 'Gandevi, Bilimora rural, Chikhli',
        status: 'PUBLISHED',
        raw_value: 'Section 3a gazette notification published'
      }
    ],
    notifications3A: [
      {
        id: 'NOTIF_3A_56972_1',
        source_project_id: '56972',
        publish_date: '2022-01-20',
        notification_number: 'S.O. 312(E)',
        survey_numbers: 'Revenue survey 42 to 118',
        objections: 'Compensation rate dispute hearings held in Dec 2022',
        status: 'OBJECTIONS_HEARD',
        raw_value: 'Section 3A detailed survey notification'
      }
    ],
    notifications3d: [
      {
        id: 'NOTIF_3d_56972_1',
        source_project_id: '56972',
        publish_date: '2022-07-28',
        notification_number: 'S.O. 3314(E)',
        survey_numbers: '340 Hectares declared vested',
        status: 'VESTED',
        raw_value: 'Declaration of acquisition under Section 3D'
      }
    ],
    sanctions: [
      {
        id: 'SANC_56972_1',
        source_project_id: '56972',
        sanction_number: 'RW/NHAI/DME/GJ/56972',
        sanction_date: '2022-08-14',
        sanction_amount: 620.0,
        status: 'SANCTIONED',
        raw_value: 'User award sanctioned'
      }
    ],
    consentPurchases: [
      {
        id: 'CP_56972_1',
        source_project_id: '56972',
        state: 'Gujarat',
        district: 'Navsari',
        sub_district: 'Chikhli',
        village: 'Alipor',
        survey_number: 'Survey No. 78/1',
        land_party: 'Horticultural Orchard Landholders',
        amount: 24.5,
        disbursement_details: 'Direct Bank Transfer via User PFMS'
      }
    ],
    additionalInfo: {
      gazetteLink: 'https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=56972',
      corridorType: 'Access Controlled Expressway',
      notifiedVillagesCount: 22,
      calaOffice: 'Special Land Acquisition Officer, Navsari',
      lastPhysicalInspection: '2026-09-02'
    }
  },

  // Test Project 54635: Bengaluru-Chennai Expressway Phase II (Karnataka)
  '54635': {
    sourceProjectId: '54635',
    projectName: 'Bengaluru-Chennai Expressway (Bangarapet-Kolar Package II)',
    projectNumber: 'NHAI/PIU-BLR/NE-7/54635',
    state: 'Karnataka',
    district: 'Kolar',
    implementingAgency: 'National Highways Authority of India (NHAI)',
    highwayNumber: 'NE-7',
    landRequired: 320.5,
    landAvailable: 55.0,
    landToBeAcquired: 265.5,
    landAcquiredTillNow: 285.0,
    sanctionNumber: 'MoRTH/NE-7/KA/2021/54635',
    sanctionDate: '2021-11-25',
    sanctionAmount: 410.0,
    notifications3a: [
      {
        id: 'NOTIF_3a_54635_1',
        source_project_id: '54635',
        publish_date: '2020-09-14',
        notification_number: 'S.O. 3144(E)',
        cala: 'Assistant Commissioner, Kolar Sub-Division',
        villages: 'Bangarapet, Bethamangala, Kyasamballi',
        status: 'PUBLISHED',
        raw_value: 'Section 3a gazette notification'
      }
    ],
    notifications3A: [
      {
        id: 'NOTIF_3A_54635_1',
        source_project_id: '54635',
        publish_date: '2021-04-18',
        notification_number: 'S.O. 1599(E)',
        survey_numbers: 'Sy Nos 18 to 92',
        objections: 'Hearing completed under Section 3C',
        status: 'OBJECTIONS_HEARD',
        raw_value: 'Section 3A detailed notification'
      }
    ],
    notifications3d: [
      {
        id: 'NOTIF_3d_54635_1',
        source_project_id: '54635',
        publish_date: '2021-10-30',
        notification_number: 'S.O. 4512(E)',
        survey_numbers: '285 Hectares vested',
        status: 'VESTED',
        raw_value: 'Section 3D statutory vesting'
      }
    ],
    sanctions: [
      {
        id: 'SANC_54635_1',
        source_project_id: '54635',
        sanction_number: 'RW/NHAI/NE-7/KA/54635',
        sanction_date: '2021-11-25',
        sanction_amount: 410.0,
        status: 'SANCTIONED',
        raw_value: 'User award sanction'
      }
    ],
    consentPurchases: [
      {
        id: 'CP_54635_1',
        source_project_id: '54635',
        state: 'Karnataka',
        district: 'Kolar',
        sub_district: 'Bangarapet',
        village: 'Kamasamudram',
        survey_number: 'Sy No. 44/3',
        land_party: 'Local Ryots Association',
        amount: 18.2,
        disbursement_details: 'User Bhoomi-PFMS integrated account'
      }
    ],
    additionalInfo: {
      gazetteLink: 'https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=54635',
      corridorType: 'High Speed Expressway',
      notifiedVillagesCount: 18,
      calaOffice: 'Assistant Commissioner, Kolar',
      lastPhysicalInspection: '2026-08-25'
    }
  },

  // Test Project 57405: Delhi-Amritsar-Katra Expressway (Punjab)
  '57405': {
    sourceProjectId: '57405',
    projectName: 'Delhi-Amritsar-Katra Expressway (Jalandhar-Kapurthala Section Package III)',
    projectNumber: 'NHAI/PIU-JALANDHAR/DAK-PKG3/57405',
    state: 'Punjab',
    district: 'Jalandhar',
    implementingAgency: 'National Highways Authority of India (NHAI)',
    highwayNumber: 'NE-5',
    landRequired: 410.2,
    landAvailable: 45.0,
    landToBeAcquired: 365.2,
    landAcquiredTillNow: 195.4,
    sanctionNumber: 'MoRTH/NE-5/PB/2022/57405',
    sanctionDate: '2022-06-20',
    sanctionAmount: 512.0,
    notifications3a: [
      {
        id: 'NOTIF_3a_57405_1',
        source_project_id: '57405',
        publish_date: '2021-03-29',
        notification_number: 'S.O. 1380(E)',
        cala: 'SDM Nakodar & Phillaur',
        villages: 'Nakodar, Phillaur, Goraya rural',
        status: 'PUBLISHED',
        raw_value: 'Section 3a gazette published'
      }
    ],
    notifications3A: [
      {
        id: 'NOTIF_3A_57405_1',
        source_project_id: '57405',
        publish_date: '2021-11-12',
        notification_number: 'S.O. 4721(E)',
        survey_numbers: 'Khasra Nos. 104 to 289',
        objections: 'Farmers union representation on compensation formula',
        status: 'OBJECTIONS_HEARD',
        raw_value: 'Section 3A notification with survey numbers'
      }
    ],
    notifications3d: [
      {
        id: 'NOTIF_3d_57405_1',
        source_project_id: '57405',
        publish_date: '2022-05-15',
        notification_number: 'S.O. 2205(E)',
        survey_numbers: '195.4 Hectares vested',
        status: 'VESTED',
        raw_value: 'Section 3D statutory vesting notification'
      }
    ],
    sanctions: [
      {
        id: 'SANC_57405_1',
        source_project_id: '57405',
        sanction_number: 'RW/NHAI/DAK/PB/57405',
        sanction_date: '2022-06-20',
        sanction_amount: 512.0,
        status: 'SANCTIONED',
        raw_value: 'Compensation award sanction'
      }
    ],
    consentPurchases: [
      {
        id: 'CP_57405_1',
        source_project_id: '57405',
        state: 'Punjab',
        district: 'Jalandhar',
        sub_district: 'Nakodar',
        village: 'Shahpur',
        survey_number: 'Khasra No. 112/4',
        land_party: 'Kisan Cooperative Landowners',
        amount: 21.0,
        disbursement_details: 'User Jalandhar direct account settlement'
      }
    ],
    additionalInfo: {
      gazetteLink: 'https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=57405',
      corridorType: 'Greenfield Religious & Economic Corridor',
      notifiedVillagesCount: 26,
      calaOffice: 'Competent Authority, Land Acquisition, Jalandhar',
      lastPhysicalInspection: '2026-09-05'
    }
  }
};

/**
 * Return simulated updated fixture for Project 60940 (Section 42 test)
 * Changing landAcquiredTillNow from 1.90248 to 5.20480
 */
export function getUpdatedFixture60940(): NormalizedProjectPayload {
  const base = KNOWN_BHOOMIRASHI_FIXTURES['60940'];
  return {
    ...base,
    landAcquiredTillNow: 5.20480, // Updated value!
    notifications3d: [
      ...base.notifications3d,
      {
        id: 'NOTIF_3d_60940_2',
        source_project_id: '60940',
        publish_date: '2026-09-10',
        notification_number: 'S.O. 3892(E)',
        survey_numbers: 'Vesting of additional 5.2 Hectares in Haveli Tehsil',
        status: 'VESTED',
        raw_value: 'Supplemental Section 3D declaration'
      }
    ],
    additionalInfo: {
      ...base.additionalInfo,
      lastPhysicalInspection: '2026-09-10',
      updateReason: 'Supplemental Section 3D gazette published'
    }
  };
}
