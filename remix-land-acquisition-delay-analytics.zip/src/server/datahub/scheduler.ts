/**
 * Data Hub Synchronization Scheduler & Runner
 * Manages periodic background checks, overlapping sync locks, and Check Now triggers.
 * Smart India Hackathon 2026 - SIH26017
 */

import { getDataHubDb, updateDataHubSource } from './database.ts';
import { BhoomiRashiCollector } from './bhoomiRashiCollector.ts';
import { ChangeDetectionEngine } from './changeDetection.ts';
import { DataHubBridge } from './bridge.ts';
import { SourceProjectRecord, SyncRunRecord } from './types.ts';

export class DataHubScheduler {
  private static isSyncRunning = false;
  private static timerId: NodeJS.Timeout | null = null;
  private static checkIntervalMinutes = 60; // Default 1 hour per specification

  /**
   * Initializes background scheduler timer
   */
  public static init() {
    const db = getDataHubDb();
    const source = db.prepare('SELECT check_interval_minutes, enabled FROM dh_data_sources WHERE id = ?').get('bhoomirashi') as any;
    if (source) {
      this.checkIntervalMinutes = source.check_interval_minutes || 60;
    }

    if (this.timerId) {
      clearInterval(this.timerId);
    }

    // Schedule periodic timer
    const intervalMs = this.checkIntervalMinutes * 60 * 1000;
    this.timerId = setInterval(() => {
      this.runSync('SCHEDULED');
    }, intervalMs);

    console.log(`[DataHubScheduler] Initialized with interval ${this.checkIntervalMinutes} minutes.`);
  }

  /**
   * Updates sync interval in database and restarts timer
   */
  public static setIntervalMinutes(minutes: number) {
    const validIntervals = [15, 30, 60, 360, 720, 1440];
    const target = validIntervals.includes(minutes) ? minutes : 60;
    this.checkIntervalMinutes = target;

    updateDataHubSource('bhoomirashi', {
      check_interval_minutes: target,
      next_check_at: new Date(Date.now() + target * 60 * 1000).toISOString()
    });

    if (this.timerId) {
      clearInterval(this.timerId);
    }

    const intervalMs = target * 60 * 1000;
    this.timerId = setInterval(() => {
      this.runSync('SCHEDULED');
    }, intervalMs);

    console.log(`[DataHubScheduler] Updated interval to ${target} minutes.`);
    return { success: true, intervalMinutes: target };
  }

  public static getIntervalMinutes(): number {
    return this.checkIntervalMinutes;
  }

  public static isRunning(): boolean {
    return this.isSyncRunning;
  }

  /**
   * Executes a complete synchronization run across all registered public projects.
   * Prevents overlapping runs (mutex lock).
   */
  public static async runSync(triggerType: 'MANUAL_CHECK_NOW' | 'SCHEDULED' = 'MANUAL_CHECK_NOW'): Promise<SyncRunRecord> {
    if (this.isSyncRunning) {
      console.warn('[DataHubScheduler] Sync run already in progress. Rejecting overlapping run.');
      const db = getDataHubDb();
      const currentRun = db.prepare("SELECT * FROM dh_sync_runs WHERE status = 'RUNNING' ORDER BY started_at DESC LIMIT 1").get() as unknown as (SyncRunRecord | undefined);
      if (currentRun) return currentRun;
      throw new Error('A synchronization run is currently active.');
    }

    this.isSyncRunning = true;
    const db = getDataHubDb();
    const startTime = new Date();
    const syncRunId = `RUN-${Date.now()}`;
    const nowIso = startTime.toISOString();

    console.log(`[DataHubSync] [${triggerType}] Started run ${syncRunId} at ${nowIso}`);

    // Update source status to CHECKING
    updateDataHubSource('bhoomirashi', {
      status: 'CHECKING',
      last_check_at: nowIso
    });

    // Insert sync run record in RUNNING state
    db.prepare(`
      INSERT INTO dh_sync_runs (
        id, source_name, started_at, completed_at, status,
        projects_checked, new_projects, updated_projects, unchanged_projects,
        error_projects, error_message
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      syncRunId,
      'BhoomiRashi',
      nowIso,
      null,
      'RUNNING',
      0, 0, 0, 0, 0, null
    );

    let checkedCount = 0;
    let newCount = 0;
    let updatedCount = 0;
    let unchangedCount = 0;
    let errorCount = 0;
    let lastErrorMsg: string | null = null;

    try {
      // Step 1: Load all registered project IDs
      const registered = db.prepare('SELECT * FROM dh_source_projects ORDER BY created_at ASC').all() as unknown as SourceProjectRecord[];

      // Step 2-9: Iterate through each registered project
      for (const sp of registered) {
        checkedCount++;
        const pId = sp.source_project_id;

        try {
          // Fetch & parse public project detail page
          const fetchResult = await BhoomiRashiCollector.fetchAndParseProject(pId);

          if (!fetchResult.success || !fetchResult.payload) {
            errorCount++;
            lastErrorMsg = fetchResult.errorMessage || 'Failed to fetch public project page';

            // Record error in dh_sync_errors
            const errId = `ERR_${syncRunId}_${pId}_${Date.now()}`;
            db.prepare(`
              INSERT INTO dh_sync_errors (
                id, sync_run_id, source_project_id, error_type, error_message, http_status, occurred_at, retry_count
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
              errId,
              syncRunId,
              pId,
              'FETCH_ERROR',
              fetchResult.errorMessage || 'HTTP error',
              fetchResult.httpStatus || null,
              new Date().toISOString(),
              1
            );

            // Update source project data_status to SOURCE_ERROR without deleting previous valid data
            db.prepare(`
              UPDATE dh_source_projects
              SET last_checked_at = ?, data_status = 'SOURCE_ERROR', updated_at = ?
              WHERE source_project_id = ?
            `).run(new Date().toISOString(), new Date().toISOString(), pId);

            console.warn(`[DataHubSync] Project ${pId} HTTP ${fetchResult.httpStatus}: ${fetchResult.errorMessage}`);
            continue;
          }

          // Change Detection Evaluation
          const evalResult = ChangeDetectionEngine.evaluateChange(db, fetchResult.payload, syncRunId);

          if (evalResult.classification === 'NEW') {
            newCount++;
            ChangeDetectionEngine.applyChange(db, evalResult, fetchResult.payload, syncRunId, sp.discovery_method);
            console.log(`[DataHubSync] Project ${pId} -> NEW project record appended.`);
          } else if (evalResult.classification === 'UPDATED') {
            updatedCount++;
            ChangeDetectionEngine.applyChange(db, evalResult, fetchResult.payload, syncRunId, sp.discovery_method);
            console.log(`[DataHubSync] Project ${pId} -> UPDATED (${evalResult.fieldChanges.length} fields changed).`);
            for (const ch of evalResult.fieldChanges) {
              console.log(`   • ${ch.field_name}: ${ch.old_value} -> ${ch.new_value}`);
            }
          } else {
            unchangedCount++;
            ChangeDetectionEngine.applyChange(db, evalResult, fetchResult.payload, syncRunId, sp.discovery_method);
            console.log(`[DataHubSync] Project ${pId} -> UNCHANGED.`);
          }

        } catch (projErr: any) {
          errorCount++;
          lastErrorMsg = projErr.message;
          const errId = `ERR_${syncRunId}_${pId}_${Date.now()}`;
          db.prepare(`
            INSERT INTO dh_sync_errors (
              id, sync_run_id, source_project_id, error_type, error_message, http_status, occurred_at, retry_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            errId,
            syncRunId,
            pId,
            'PARSER_EXCEPTION',
            projErr.message || 'Unexpected exception',
            500,
            new Date().toISOString(),
            1
          );
        }
      }

      // Step 10: Bridge synchronized records to Phase 2 BhoomiDrishti application
      DataHubBridge.syncToMainApp();

      const completionTime = new Date();
      const runStatus: 'SUCCESS' | 'PARTIAL' | 'FAILED' =
        errorCount === 0 ? 'SUCCESS' : (checkedCount > errorCount ? 'PARTIAL' : 'FAILED');

      // Finalize sync run record
      db.prepare(`
        UPDATE dh_sync_runs
        SET
          completed_at = ?,
          status = ?,
          projects_checked = ?,
          new_projects = ?,
          updated_projects = ?,
          unchanged_projects = ?,
          error_projects = ?,
          error_message = ?
        WHERE id = ?
      `).run(
        completionTime.toISOString(),
        runStatus,
        checkedCount,
        newCount,
        updatedCount,
        unchangedCount,
        errorCount,
        lastErrorMsg,
        syncRunId
      );

      // Update source status in dh_data_sources
      const nextCheckIso = new Date(Date.now() + this.checkIntervalMinutes * 60 * 1000).toISOString();
      updateDataHubSource('bhoomirashi', {
        status: runStatus === 'FAILED' ? 'ERROR' : 'CONNECTED',
        last_success_at: runStatus !== 'FAILED' ? completionTime.toISOString() : undefined,
        last_error_at: runStatus === 'FAILED' ? completionTime.toISOString() : undefined,
        next_check_at: nextCheckIso
      });

      const updatedRun = db.prepare('SELECT * FROM dh_sync_runs WHERE id = ?').get(syncRunId) as unknown as SyncRunRecord;
      console.log(`[DataHubSync] Completed run ${syncRunId} in ${completionTime.getTime() - startTime.getTime()}ms. Status: ${runStatus}. Checked: ${checkedCount}, New: ${newCount}, Updated: ${updatedCount}, Unchanged: ${unchangedCount}, Errors: ${errorCount}`);

      return updatedRun;

    } finally {
      this.isSyncRunning = false;
    }
  }
}
