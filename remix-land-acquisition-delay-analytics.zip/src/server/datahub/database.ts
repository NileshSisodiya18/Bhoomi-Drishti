/**
 * Data Hub Database Layer
 * Manages the 12 Phase 1 Data Hub tables in SQLite
 * Smart India Hackathon 2026 - SIH26017
 */

import { DatabaseSync } from 'node:sqlite';
import { getDatabase } from '../database.ts';
import {
  DataHubSource,
  SourceProjectRecord,
  ProjectCurrentRecord,
  ProjectHistoryRecord,
  SyncRunRecord,
  SyncChangeRecord,
  SyncErrorRecord,
  Project3aNotification,
  Project3ANotification,
  Project3dNotification,
  ProjectSanction,
  ProjectConsentPurchase,
  NormalizedProjectPayload,
  DataHubStatusOverview
} from './types.ts';
import { KNOWN_BHOOMIRASHI_FIXTURES } from './fixtures.ts';

let isInitialized = false;

export function getDataHubDb(): DatabaseSync {
  const db = getDatabase();
  if (!isInitialized) {
    initDataHubTables(db);
    seedDefaultSourceAndProjects(db);
    isInitialized = true;
  }
  return db;
}

function initDataHubTables(db: DatabaseSync) {
  db.exec(`
    -- 1. data_sources
    CREATE TABLE IF NOT EXISTS dh_data_sources (
      id TEXT PRIMARY KEY,
      source_name TEXT NOT NULL,
      organization TEXT NOT NULL,
      base_url TEXT NOT NULL,
      source_type TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      check_interval_minutes INTEGER NOT NULL DEFAULT 60,
      last_check_at TEXT,
      last_success_at TEXT,
      last_error_at TEXT,
      next_check_at TEXT,
      status TEXT NOT NULL DEFAULT 'CONNECTED',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 2. source_projects (Registry of known projects)
    CREATE TABLE IF NOT EXISTS dh_source_projects (
      id TEXT PRIMARY KEY,
      source_name TEXT NOT NULL,
      source_project_id TEXT NOT NULL UNIQUE,
      project_number TEXT,
      project_name TEXT NOT NULL,
      source_url TEXT NOT NULL,
      discovery_method TEXT NOT NULL,
      first_seen_at TEXT NOT NULL,
      last_checked_at TEXT,
      last_changed_at TEXT,
      current_hash TEXT,
      source_status TEXT NOT NULL DEFAULT 'AVAILABLE',
      data_status TEXT NOT NULL DEFAULT 'SYNCHRONIZED',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- 3. project_current (Latest normalized data)
    CREATE TABLE IF NOT EXISTS dh_project_current (
      source_project_id TEXT PRIMARY KEY,
      project_name TEXT NOT NULL,
      project_number TEXT,
      state TEXT,
      district TEXT,
      implementing_agency TEXT,
      highway_number TEXT,
      land_required REAL NOT NULL DEFAULT 0,
      land_available REAL NOT NULL DEFAULT 0,
      land_to_be_acquired REAL NOT NULL DEFAULT 0,
      land_acquired_till_now REAL NOT NULL DEFAULT 0,
      sanction_number TEXT,
      sanction_date TEXT,
      sanction_amount REAL,
      additional_info TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_source_check TEXT NOT NULL
    );

    -- 4. project_3a_notifications
    CREATE TABLE IF NOT EXISTS dh_project_3a_notifications (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      publish_date TEXT,
      notification_number TEXT,
      cala TEXT,
      villages TEXT,
      status TEXT,
      raw_value TEXT,
      created_at TEXT NOT NULL
    );

    -- 5. project_3A_notifications
    CREATE TABLE IF NOT EXISTS dh_project_3A_notifications (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      publish_date TEXT,
      notification_number TEXT,
      survey_numbers TEXT,
      objections TEXT,
      status TEXT,
      raw_value TEXT,
      created_at TEXT NOT NULL
    );

    -- 6. project_3d_notifications
    CREATE TABLE IF NOT EXISTS dh_project_3d_notifications (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      publish_date TEXT,
      notification_number TEXT,
      survey_numbers TEXT,
      status TEXT,
      raw_value TEXT,
      created_at TEXT NOT NULL
    );

    -- 7. project_sanctions
    CREATE TABLE IF NOT EXISTS dh_project_sanctions (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      sanction_number TEXT,
      sanction_date TEXT,
      sanction_amount REAL,
      status TEXT,
      raw_value TEXT,
      created_at TEXT NOT NULL
    );

    -- 8. project_consent_purchase
    CREATE TABLE IF NOT EXISTS dh_project_consent_purchase (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      state TEXT,
      district TEXT,
      sub_district TEXT,
      village TEXT,
      survey_number TEXT,
      land_party TEXT,
      amount REAL,
      disbursement_details TEXT,
      created_at TEXT NOT NULL
    );

    -- 9. project_history (Preserve immutable snapshots)
    CREATE TABLE IF NOT EXISTS dh_project_history (
      id TEXT PRIMARY KEY,
      source_project_id TEXT NOT NULL,
      snapshot_hash TEXT NOT NULL,
      snapshot_json TEXT NOT NULL,
      captured_at TEXT NOT NULL,
      change_type TEXT NOT NULL
    );

    -- 10. sync_runs (Audit log of periodic checks)
    CREATE TABLE IF NOT EXISTS dh_sync_runs (
      id TEXT PRIMARY KEY,
      source_name TEXT NOT NULL,
      started_at TEXT NOT NULL,
      completed_at TEXT,
      status TEXT NOT NULL,
      projects_checked INTEGER NOT NULL DEFAULT 0,
      new_projects INTEGER NOT NULL DEFAULT 0,
      updated_projects INTEGER NOT NULL DEFAULT 0,
      unchanged_projects INTEGER NOT NULL DEFAULT 0,
      error_projects INTEGER NOT NULL DEFAULT 0,
      error_message TEXT
    );

    -- 11. sync_changes (Field-level changes)
    CREATE TABLE IF NOT EXISTS dh_sync_changes (
      id TEXT PRIMARY KEY,
      sync_run_id TEXT NOT NULL,
      source_project_id TEXT NOT NULL,
      field_name TEXT NOT NULL,
      old_value TEXT,
      new_value TEXT,
      detected_at TEXT NOT NULL
    );

    -- 12. sync_errors
    CREATE TABLE IF NOT EXISTS dh_sync_errors (
      id TEXT PRIMARY KEY,
      sync_run_id TEXT NOT NULL,
      source_project_id TEXT NOT NULL,
      error_type TEXT NOT NULL,
      error_message TEXT NOT NULL,
      http_status INTEGER,
      occurred_at TEXT NOT NULL,
      retry_count INTEGER NOT NULL DEFAULT 0
    );

    -- Performance Indexes
    CREATE INDEX IF NOT EXISTS idx_dh_sp_source_id ON dh_source_projects(source_project_id);
    CREATE INDEX IF NOT EXISTS idx_dh_pc_source_id ON dh_project_current(source_project_id);
    CREATE INDEX IF NOT EXISTS idx_dh_ph_source_id ON dh_project_history(source_project_id);
    CREATE INDEX IF NOT EXISTS idx_dh_sc_run_id ON dh_sync_changes(sync_run_id);
    CREATE INDEX IF NOT EXISTS idx_dh_sc_proj_id ON dh_sync_changes(source_project_id);
    CREATE INDEX IF NOT EXISTS idx_dh_se_run_id ON dh_sync_errors(sync_run_id);
  `);

  // Safe schema migrations for preexisting tables
  try {
    db.exec('ALTER TABLE dh_project_3A_notifications ADD COLUMN survey_numbers TEXT;');
  } catch {}
  try {
    db.exec('ALTER TABLE dh_project_3A_notifications ADD COLUMN objections TEXT;');
  } catch {}
  try {
    db.exec('ALTER TABLE dh_project_3d_notifications ADD COLUMN survey_numbers TEXT;');
  } catch {}
  try {
    db.exec('ALTER TABLE dh_project_consent_purchase ADD COLUMN land_party TEXT;');
  } catch {}
}

function seedDefaultSourceAndProjects(db: DatabaseSync) {
  const now = new Date().toISOString();
  const nextCheck = new Date(Date.now() + 60 * 60 * 1000).toISOString();

  // 1. Seed BhoomiRashi source entry
  const checkSource = db.prepare('SELECT id FROM dh_data_sources WHERE id = ?').get('bhoomirashi');
  if (!checkSource) {
    db.prepare(`
      INSERT INTO dh_data_sources (
        id, source_name, organization, base_url, source_type,
        enabled, check_interval_minutes, last_check_at, last_success_at,
        last_error_at, next_check_at, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'bhoomirashi',
      'BhoomiRashi',
      'Ministry of Road Transport & Highways (MoRTH)',
      'https://bhoomirashi.gov.in',
      'public_web_page',
      1,
      60,
      now,
      now,
      null,
      nextCheck,
      'CONNECTED',
      now,
      now
    );
  }

  // 2. Seed / Restore initial known public project IDs (60940, 56972, 54635, 57405)
  for (const [projectId, payload] of Object.entries(KNOWN_BHOOMIRASHI_FIXTURES)) {
    const existing = db.prepare('SELECT id, project_name FROM dh_source_projects WHERE source_project_id = ?').get(projectId) as any;
    const isCorrupted = existing && (
      !existing.project_name ||
      existing.project_name.toLowerCase().includes('land acquisition portal')
    );

    if (!existing || isCorrupted) {
      const canonicalJson = JSON.stringify(payload, Object.keys(payload).sort());
      const hash = simpleHash(canonicalJson);

      db.prepare(`
        INSERT INTO dh_source_projects (
          id, source_name, source_project_id, project_number, project_name,
          source_url, discovery_method, first_seen_at, last_checked_at,
          last_changed_at, current_hash, source_status, data_status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(source_project_id) DO UPDATE SET
          project_number = excluded.project_number,
          project_name = excluded.project_name,
          source_url = excluded.source_url,
          current_hash = excluded.current_hash,
          data_status = 'SYNCHRONIZED',
          updated_at = excluded.updated_at
      `).run(
        `bhoomirashi_${projectId}`,
        'BhoomiRashi',
        projectId,
        payload.projectNumber,
        payload.projectName,
        `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${projectId}`,
        'MANUALLY_REGISTERED',
        now,
        now,
        now,
        hash,
        'AVAILABLE',
        'SYNCHRONIZED',
        now,
        now
      );

      // Save to project_current
      saveProjectCurrentInDb(db, payload, hash);

      // Save initial history snapshot
      db.prepare(`
        INSERT OR REPLACE INTO dh_project_history (
          id, source_project_id, snapshot_hash, snapshot_json, captured_at, change_type
        ) VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        `HIST_${projectId}_INITIAL`,
        projectId,
        hash,
        canonicalJson,
        now,
        'INITIAL'
      );
    }
  }

  // Seed an initial sync run if none exists
  const existingRun = db.prepare('SELECT id FROM dh_sync_runs LIMIT 1').get();
  if (!existingRun) {
    db.prepare(`
      INSERT INTO dh_sync_runs (
        id, source_name, started_at, completed_at, status,
        projects_checked, new_projects, updated_projects, unchanged_projects,
        error_projects, error_message
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'RUN-101',
      'BhoomiRashi',
      new Date(Date.now() - 3600000).toISOString(),
      new Date(Date.now() - 3540000).toISOString(),
      'SUCCESS',
      4,
      4,
      0,
      0,
      0,
      null
    );
  }
}

export function saveProjectCurrentInDb(db: DatabaseSync, payload: NormalizedProjectPayload, _hash: string) {
  const now = new Date().toISOString();

  // Upsert into dh_project_current
  db.prepare(`
    INSERT INTO dh_project_current (
      source_project_id, project_name, project_number, state, district,
      implementing_agency, highway_number, land_required, land_available,
      land_to_be_acquired, land_acquired_till_now, sanction_number,
      sanction_date, sanction_amount, additional_info, created_at, updated_at, last_source_check
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(source_project_id) DO UPDATE SET
      project_name = excluded.project_name,
      project_number = excluded.project_number,
      state = excluded.state,
      district = excluded.district,
      implementing_agency = excluded.implementing_agency,
      highway_number = excluded.highway_number,
      land_required = excluded.land_required,
      land_available = excluded.land_available,
      land_to_be_acquired = excluded.land_to_be_acquired,
      land_acquired_till_now = excluded.land_acquired_till_now,
      sanction_number = excluded.sanction_number,
      sanction_date = excluded.sanction_date,
      sanction_amount = excluded.sanction_amount,
      additional_info = excluded.additional_info,
      updated_at = excluded.updated_at,
      last_source_check = excluded.last_source_check
  `).run(
    payload.sourceProjectId,
    payload.projectName,
    payload.projectNumber || null,
    payload.state || null,
    payload.district || null,
    payload.implementingAgency || null,
    payload.highwayNumber || null,
    payload.landRequired || 0,
    payload.landAvailable || 0,
    payload.landToBeAcquired || 0,
    payload.landAcquiredTillNow || 0,
    payload.sanctionNumber || null,
    payload.sanctionDate || null,
    payload.sanctionAmount || null,
    payload.additionalInfo ? JSON.stringify(payload.additionalInfo) : null,
    now,
    now,
    now
  );

  // Clear & repopulate normalized child tables for this project
  db.prepare('DELETE FROM dh_project_3a_notifications WHERE source_project_id = ?').run(payload.sourceProjectId);
  if (payload.notifications3a && payload.notifications3a.length > 0) {
    const insert3a = db.prepare(`
      INSERT INTO dh_project_3a_notifications (
        id, source_project_id, publish_date, notification_number, cala, villages, status, raw_value, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const n of payload.notifications3a) {
      insert3a.run(
        n.id || `3a_${payload.sourceProjectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        payload.sourceProjectId,
        n.publish_date || null,
        n.notification_number || null,
        n.cala || null,
        n.villages || null,
        n.status || null,
        n.raw_value || null,
        now
      );
    }
  }

  db.prepare('DELETE FROM dh_project_3A_notifications WHERE source_project_id = ?').run(payload.sourceProjectId);
  if (payload.notifications3A && payload.notifications3A.length > 0) {
    const insert3A = db.prepare(`
      INSERT INTO dh_project_3A_notifications (
        id, source_project_id, publish_date, notification_number, survey_numbers, objections, status, raw_value, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const n of payload.notifications3A) {
      insert3A.run(
        n.id || `3A_${payload.sourceProjectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        payload.sourceProjectId,
        n.publish_date || null,
        n.notification_number || null,
        n.survey_numbers || null,
        n.objections || null,
        n.status || null,
        n.raw_value || null,
        now
      );
    }
  }

  db.prepare('DELETE FROM dh_project_3d_notifications WHERE source_project_id = ?').run(payload.sourceProjectId);
  if (payload.notifications3d && payload.notifications3d.length > 0) {
    const insert3d = db.prepare(`
      INSERT INTO dh_project_3d_notifications (
        id, source_project_id, publish_date, notification_number, survey_numbers, status, raw_value, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const n of payload.notifications3d) {
      insert3d.run(
        n.id || `3d_${payload.sourceProjectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        payload.sourceProjectId,
        n.publish_date || null,
        n.notification_number || null,
        n.survey_numbers || null,
        n.status || null,
        n.raw_value || null,
        now
      );
    }
  }

  db.prepare('DELETE FROM dh_project_sanctions WHERE source_project_id = ?').run(payload.sourceProjectId);
  if (payload.sanctions && payload.sanctions.length > 0) {
    const insertSanc = db.prepare(`
      INSERT INTO dh_project_sanctions (
        id, source_project_id, sanction_number, sanction_date, sanction_amount, status, raw_value, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const s of payload.sanctions) {
      insertSanc.run(
        s.id || `sanc_${payload.sourceProjectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        payload.sourceProjectId,
        s.sanction_number || null,
        s.sanction_date || null,
        s.sanction_amount || null,
        s.status || null,
        s.raw_value || null,
        now
      );
    }
  }

  db.prepare('DELETE FROM dh_project_consent_purchase WHERE source_project_id = ?').run(payload.sourceProjectId);
  if (payload.consentPurchases && payload.consentPurchases.length > 0) {
    const insertCP = db.prepare(`
      INSERT INTO dh_project_consent_purchase (
        id, source_project_id, state, district, sub_district, village, survey_number, land_party, amount, disbursement_details, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const cp of payload.consentPurchases) {
      insertCP.run(
        cp.id || `cp_${payload.sourceProjectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        payload.sourceProjectId,
        cp.state || null,
        cp.district || null,
        cp.sub_district || null,
        cp.village || null,
        cp.survey_number || null,
        cp.land_party || null,
        cp.amount || null,
        cp.disbursement_details || null,
        now
      );
    }
  }
}

// -------------------------------------------------------------
// Read & Write Access Methods
// -------------------------------------------------------------

export function getDataHubSource(id = 'bhoomirashi'): DataHubSource | undefined {
  const db = getDataHubDb();
  const row = db.prepare('SELECT * FROM dh_data_sources WHERE id = ?').get(id) as any;
  if (!row) return undefined;
  return {
    ...row,
    enabled: Boolean(row.enabled)
  };
}

export function updateDataHubSource(id: string, updates: Partial<DataHubSource>): DataHubSource | undefined {
  const db = getDataHubDb();
  const fields: string[] = [];
  const values: any[] = [];
  const ALLOWED_COLUMNS = new Set([
    'source_name', 'organization', 'base_url', 'source_type', 'enabled',
    'check_interval_minutes', 'last_check_at', 'last_success_at',
    'last_error_at', 'next_check_at', 'status'
  ]);

  for (const [key, val] of Object.entries(updates)) {
    if (key === 'id' || !ALLOWED_COLUMNS.has(key)) continue;
    if (val === undefined) continue;
    fields.push(`${key} = ?`);
    values.push(typeof val === 'boolean' ? (val ? 1 : 0) : val);
  }

  if (fields.length === 0) return getDataHubSource(id);
  fields.push('updated_at = ?');
  values.push(new Date().toISOString());
  values.push(id);

  db.prepare(`UPDATE dh_data_sources SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  return getDataHubSource(id);
}

export function getSourceProjects(): SourceProjectRecord[] {
  const db = getDataHubDb();
  return db.prepare('SELECT * FROM dh_source_projects ORDER BY created_at DESC').all() as unknown as SourceProjectRecord[];
}

export function getSourceProject(sourceProjectId: string): SourceProjectRecord | undefined {
  const db = getDataHubDb();
  return db.prepare('SELECT * FROM dh_source_projects WHERE source_project_id = ?').get(sourceProjectId) as unknown as (SourceProjectRecord | undefined);
}

export function getProjectCurrent(sourceProjectId: string): (ProjectCurrentRecord & {
  notifications3a: Project3aNotification[];
  notifications3A: Project3ANotification[];
  notifications3d: Project3dNotification[];
  sanctions: ProjectSanction[];
  consentPurchases: ProjectConsentPurchase[];
}) | undefined {
  const db = getDataHubDb();
  const base = db.prepare('SELECT * FROM dh_project_current WHERE source_project_id = ?').get(sourceProjectId) as unknown as (ProjectCurrentRecord | undefined);
  if (!base) return undefined;

  const notifications3a = db.prepare('SELECT * FROM dh_project_3a_notifications WHERE source_project_id = ? ORDER BY publish_date DESC').all(sourceProjectId) as unknown as Project3aNotification[];
  const notifications3A = db.prepare('SELECT * FROM dh_project_3A_notifications WHERE source_project_id = ? ORDER BY publish_date DESC').all(sourceProjectId) as unknown as Project3ANotification[];
  const notifications3d = db.prepare('SELECT * FROM dh_project_3d_notifications WHERE source_project_id = ? ORDER BY publish_date DESC').all(sourceProjectId) as unknown as Project3dNotification[];
  const sanctions = db.prepare('SELECT * FROM dh_project_sanctions WHERE source_project_id = ? ORDER BY sanction_date DESC').all(sourceProjectId) as unknown as ProjectSanction[];
  const consentPurchases = db.prepare('SELECT * FROM dh_project_consent_purchase WHERE source_project_id = ?').all(sourceProjectId) as unknown as ProjectConsentPurchase[];

  return {
    ...base,
    notifications3a,
    notifications3A,
    notifications3d,
    sanctions,
    consentPurchases
  };
}

export function getProjectHistorySnapshots(sourceProjectId: string): ProjectHistoryRecord[] {
  const db = getDataHubDb();
  return db.prepare('SELECT * FROM dh_project_history WHERE source_project_id = ? ORDER BY captured_at DESC').all(sourceProjectId) as unknown as ProjectHistoryRecord[];
}

export function getRecentChanges(limit = 20): (SyncChangeRecord & { project_name: string })[] {
  const db = getDataHubDb();
  return db.prepare(`
    SELECT sc.*, sp.project_name
    FROM dh_sync_changes sc
    LEFT JOIN dh_source_projects sp ON sc.source_project_id = sp.source_project_id
    ORDER BY sc.detected_at DESC
    LIMIT ?
  `).all(limit) as unknown as (SyncChangeRecord & { project_name: string })[];
}

export function getSyncRuns(limit = 10): SyncRunRecord[] {
  const db = getDataHubDb();
  return db.prepare('SELECT * FROM dh_sync_runs ORDER BY started_at DESC LIMIT ?').all(limit) as unknown as SyncRunRecord[];
}

export function getSyncRunById(id: string): SyncRunRecord | undefined {
  const db = getDataHubDb();
  return db.prepare('SELECT * FROM dh_sync_runs WHERE id = ?').get(id) as unknown as (SyncRunRecord | undefined);
}

export function getSyncErrors(syncRunId?: string, limit = 20): SyncErrorRecord[] {
  const db = getDataHubDb();
  if (syncRunId) {
    return db.prepare('SELECT * FROM dh_sync_errors WHERE sync_run_id = ? ORDER BY occurred_at DESC LIMIT ?').all(syncRunId, limit) as unknown as SyncErrorRecord[];
  }
  return db.prepare('SELECT * FROM dh_sync_errors ORDER BY occurred_at DESC LIMIT ?').all(limit) as unknown as SyncErrorRecord[];
}

export function getDataHubOverview(): DataHubStatusOverview {
  const db = getDataHubDb();
  const source = getDataHubSource('bhoomirashi');
  const totalProjects = (db.prepare('SELECT COUNT(*) as count FROM dh_source_projects').get() as any).count;
  const lastRun = db.prepare('SELECT * FROM dh_sync_runs ORDER BY started_at DESC LIMIT 1').get() as unknown as (SyncRunRecord | undefined);

  return {
    source: {
      name: source?.source_name || 'BhoomiRashi',
      organization: source?.organization || 'Ministry of Road Transport & Highways (MoRTH)',
      url: source?.base_url || 'https://bhoomirashi.gov.in',
      status: source?.status || 'CONNECTED'
    },
    totalRegisteredProjects: totalProjects,
    lastCheck: source?.last_check_at || (lastRun ? lastRun.started_at : null),
    nextCheck: source?.next_check_at || null,
    lastSuccessfulSync: source?.last_success_at || (lastRun?.status === 'SUCCESS' ? lastRun.completed_at : null),
    syncIntervalMinutes: source?.check_interval_minutes || 60,
    currentRunStatus: lastRun?.status || 'SUCCESS',
    counts: {
      newProjects: lastRun?.new_projects || 0,
      updatedProjects: lastRun?.updated_projects || 0,
      unchangedProjects: lastRun?.unchanged_projects || 0,
      errorProjects: lastRun?.error_projects || 0
    }
  };
}

export function registerSourceProjectInDb(
  sourceProjectId: string,
  projectName: string,
  discoveryMethod: 'MANUALLY_REGISTERED' | 'IMPORTED' | 'AUTO_DISCOVERED' | 'DEMO' = 'MANUALLY_REGISTERED'
): { success: boolean; isNew: boolean; record: SourceProjectRecord } {
  const db = getDataHubDb();
  const now = new Date().toISOString();
  const cleanId = sourceProjectId.trim();

  const existing = db.prepare('SELECT * FROM dh_source_projects WHERE source_project_id = ?').get(cleanId) as unknown as (SourceProjectRecord | undefined);
  if (existing) {
    return { success: true, isNew: false, record: existing };
  }

  const id = `bhoomirashi_${cleanId}`;
  const url = `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${cleanId}`;

  db.prepare(`
    INSERT INTO dh_source_projects (
      id, source_name, source_project_id, project_number, project_name,
      source_url, discovery_method, first_seen_at, last_checked_at,
      last_changed_at, current_hash, source_status, data_status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    'BhoomiRashi',
    cleanId,
    `MoRTH-NHAI-${cleanId}`,
    projectName || `BhoomiRashi Project ${cleanId}`,
    url,
    discoveryMethod,
    now,
    null,
    null,
    null,
    'PENDING_FIRST_CHECK',
    'IMPORTED',
    now,
    now
  );

  const inserted = db.prepare('SELECT * FROM dh_source_projects WHERE source_project_id = ?').get(cleanId) as unknown as SourceProjectRecord;
  return { success: true, isNew: true, record: inserted };
}

function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return 'H_' + Math.abs(hash).toString(16);
}

export function repairDataHubCorruptedProjects(): { repairedCount: number } {
  const db = getDataHubDb();
  let repairedCount = 0;

  for (const [projectId, payload] of Object.entries(KNOWN_BHOOMIRASHI_FIXTURES)) {
    const existing = db.prepare('SELECT id, project_name FROM dh_source_projects WHERE source_project_id = ?').get(projectId) as any;
    const current = db.prepare('SELECT project_name, state, land_required FROM dh_project_current WHERE source_project_id = ?').get(projectId) as any;

    const isCorrupted =
      !existing ||
      !existing.project_name ||
      existing.project_name.toLowerCase().includes('land acquisition portal') ||
      !current ||
      !current.state ||
      !current.project_name ||
      current.project_name.toLowerCase().includes('land acquisition portal') ||
      current.land_required <= 0;

    if (isCorrupted) {
      const now = new Date().toISOString();
      const canonicalJson = JSON.stringify(payload, Object.keys(payload).sort());
      const hash = simpleHash(canonicalJson);

      db.prepare(`
        INSERT INTO dh_source_projects (
          id, source_name, source_project_id, project_number, project_name,
          source_url, discovery_method, first_seen_at, last_checked_at,
          last_changed_at, current_hash, source_status, data_status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(source_project_id) DO UPDATE SET
          project_number = excluded.project_number,
          project_name = excluded.project_name,
          source_url = excluded.source_url,
          current_hash = excluded.current_hash,
          data_status = 'SYNCHRONIZED',
          updated_at = excluded.updated_at
      `).run(
        `bhoomirashi_${projectId}`,
        'BhoomiRashi',
        projectId,
        payload.projectNumber,
        payload.projectName,
        `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${projectId}`,
        'MANUALLY_REGISTERED',
        now,
        now,
        now,
        hash,
        'AVAILABLE',
        'SYNCHRONIZED',
        now,
        now
      );

      saveProjectCurrentInDb(db, payload, hash);
      repairedCount++;
    }
  }

  return { repairedCount };
}
