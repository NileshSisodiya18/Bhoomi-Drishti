/**
 * Data Hub REST API Handlers
 * Section 22 API specifications for Phase 1 Data Hub
 * Smart India Hackathon 2026 - SIH26017
 */

import {
  getDataHubDb,
  getDataHubSource,
  getSourceProjects,
  getSourceProject,
  getProjectCurrent,
  getProjectHistorySnapshots,
  getRecentChanges,
  getSyncRuns,
  getSyncRunById,
  getSyncErrors,
  getDataHubOverview,
  registerSourceProjectInDb
} from './database.ts';
import { BhoomiRashiCollector } from './bhoomiRashiCollector.ts';
import { DataHubScheduler } from './scheduler.ts';
import { DataHubBridge } from './bridge.ts';

export class DataHubApi {
  /**
   * GET /api/datahub/projects
   * Returns all known/synchronized projects
   */
  public static getProjects() {
    const projects = getSourceProjects();
    const db = getDataHubDb();
    const currents = db.prepare('SELECT * FROM dh_project_current').all() as any[];
    const currentMap = new Map(currents.map(c => [c.source_project_id, c]));

    return projects.map(p => {
      const c = currentMap.get(p.source_project_id);
      return {
        source: p.source_name,
        source_project_id: p.source_project_id,
        project_number: p.project_number,
        project_name: p.project_name,
        state: c?.state || null,
        district: c?.district || null,
        land_required: c?.land_required || 0,
        land_available: c?.land_available || 0,
        land_to_be_acquired: c?.land_to_be_acquired || 0,
        land_acquired_till_now: c?.land_acquired_till_now || 0,
        source_url: p.source_url,
        discovery_method: p.discovery_method,
        source_status: p.source_status,
        data_status: p.data_status,
        first_seen_at: p.first_seen_at,
        last_checked_at: p.last_checked_at,
        last_changed_at: p.last_changed_at
      };
    });
  }

  /**
   * GET /api/datahub/projects/:sourceProjectId
   */
  public static getProjectById(sourceProjectId: string) {
    const project = getSourceProject(sourceProjectId);
    if (!project) return null;
    const current = getProjectCurrent(sourceProjectId);
    return {
      source: project.source_name,
      source_project_id: project.source_project_id,
      project_number: project.project_number,
      project_name: project.project_name,
      source_url: project.source_url,
      discovery_method: project.discovery_method,
      source_status: project.source_status,
      data_status: project.data_status,
      first_seen_at: project.first_seen_at,
      last_checked_at: project.last_checked_at,
      last_changed_at: project.last_changed_at,
      current_data: current || null
    };
  }

  /**
   * GET /api/datahub/projects/:sourceProjectId/history
   */
  public static getProjectHistory(sourceProjectId: string) {
    const db = getDataHubDb();
    const snapshots = getProjectHistorySnapshots(sourceProjectId);
    const changes = db.prepare(`
      SELECT * FROM dh_sync_changes
      WHERE source_project_id = ?
      ORDER BY detected_at DESC
    `).all(sourceProjectId);

    return {
      source_project_id: sourceProjectId,
      total_snapshots: snapshots.length,
      snapshots: snapshots.map(s => ({
        id: s.id,
        hash: s.snapshot_hash,
        captured_at: s.captured_at,
        change_type: s.change_type,
        data: JSON.parse(s.snapshot_json)
      })),
      field_changes: changes
    };
  }

  /**
   * GET /api/datahub/changes
   * Returns recent field-level changes
   */
  public static getRecentChanges(limit = 30) {
    return getRecentChanges(limit);
  }

  /**
   * GET /api/datahub/sync-status
   */
  public static getSyncStatus() {
    return getDataHubOverview();
  }

  /**
   * GET /api/datahub/sync-runs
   */
  public static getSyncRuns(limit = 15) {
    return getSyncRuns(limit);
  }

  /**
   * POST /api/datahub/sync
   * Triggers "Check Now"
   */
  public static async triggerSync() {
    return await DataHubScheduler.runSync('MANUAL_CHECK_NOW');
  }

  /**
   * POST /api/datahub/projects/register
   */
  public static async registerProject(sourceProjectId: string, projectName?: string, discoveryMethod: any = 'MANUALLY_REGISTERED') {
    if (!sourceProjectId || !sourceProjectId.trim()) {
      throw new Error('Project ID is required.');
    }
    const cleanId = sourceProjectId.trim();
    const res = registerSourceProjectInDb(cleanId, projectName || `BhoomiRashi Project ${cleanId}`, discoveryMethod);

    // Immediately attempt to fetch initial public details
    try {
      const fetchResult = await BhoomiRashiCollector.fetchAndParseProject(cleanId);
      if (fetchResult.success && fetchResult.payload) {
        const db = getDataHubDb();
        const { ChangeDetectionEngine } = await import('./changeDetection.ts');
        const evalResult = ChangeDetectionEngine.evaluateChange(db, fetchResult.payload, 'INIT_REGISTER');
        ChangeDetectionEngine.applyChange(db, evalResult, fetchResult.payload, 'INIT_REGISTER', discoveryMethod);
        DataHubBridge.syncToMainApp(cleanId);
      }
    } catch (e: any) {
      console.warn(`[DataHub] Immediate fetch for new project ${cleanId} pending next cycle: ${e.message}`);
    }

    return {
      success: true,
      isNew: res.isNew,
      record: res.record
    };
  }

  /**
   * POST /api/datahub/projects/import
   * Bulk import of project IDs (CSV, TXT, or JSON)
   */
  public static async importProjectIds(content: string, format: 'csv' | 'txt' | 'json' = 'csv') {
    const ids: string[] = [];

    if (format === 'json') {
      try {
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          for (const item of parsed) {
            if (typeof item === 'string') ids.push(item);
            else if (item && typeof item === 'object') {
              ids.push(item.project_id || item.projectId || item.id);
            }
          }
        }
      } catch {
        throw new Error('Invalid JSON format for project IDs import.');
      }
    } else {
      // CSV or plain TXT
      const lines = content.split(/[\r\n]+/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.toLowerCase().startsWith('project') || trimmed.toLowerCase().startsWith('id')) {
          continue;
        }
        // Extract first token if comma-separated
        const firstToken = trimmed.split(',')[0].trim();
        if (firstToken) ids.push(firstToken);
      }
    }

    const uniqueIds = Array.from(new Set(ids)).filter(id => Boolean(id && id.length > 0));
    const registered: string[] = [];
    const skipped: string[] = [];

    for (const pId of uniqueIds) {
      const reg = registerSourceProjectInDb(pId, `BhoomiRashi Project ${pId}`, 'IMPORTED');
      if (reg.isNew) registered.push(pId);
      else skipped.push(pId);
    }

    return {
      success: true,
      totalReceived: uniqueIds.length,
      registeredCount: registered.length,
      skippedDuplicateCount: skipped.length,
      registeredIds: registered
    };
  }

  /**
   * GET /api/datahub/source-status
   */
  public static getSourceStatus() {
    const source = getDataHubSource('bhoomirashi');
    return {
      source: source || {
        source_name: 'BhoomiRashi',
        organization: 'Ministry of Road Transport & Highways (MoRTH)',
        base_url: 'https://bhoomirashi.gov.in',
        status: 'CONNECTED'
      },
      legal_notice: 'BhoomiRashi is an official MoRTH system under the National Highways Act 1956. This Data Hub accesses publicly accessible project notifications.',
      current_interval_minutes: DataHubScheduler.getIntervalMinutes(),
      is_sync_running: DataHubScheduler.isRunning()
    };
  }

  /**
   * POST /api/datahub/source/test
   */
  public static async testSource(projectId?: string) {
    return await BhoomiRashiCollector.testSource(projectId || '60940');
  }

  /**
   * POST /api/datahub/test-fixture/toggle-60940
   * Toggle simulated update for Project 60940 (Section 42 test: 1.90248 -> 5.20480)
   */
  public static toggleFixture60940(enabled?: boolean) {
    const newState = enabled !== undefined ? enabled : !BhoomiRashiCollector.isSimulatingUpdateFor60940();
    BhoomiRashiCollector.setSimulateUpdateFor60940(newState);
    return {
      success: true,
      simulationActive: newState,
      message: newState
        ? 'Simulation ENABLED: Next sync for Project 60940 will report land_acquired_till_now updated from 1.90248 to 5.20480 (STATUS = UPDATED).'
        : 'Simulation DISABLED: Project 60940 returns initial baseline state.'
    };
  }

  /**
   * PUT /api/datahub/config
   */
  public static updateConfig(intervalMinutes: number) {
    return DataHubScheduler.setIntervalMinutes(intervalMinutes);
  }

  /**
   * GET /api/datahub/export
   */
  public static exportData(format: 'csv' | 'json' = 'csv') {
    const projects = this.getProjects();
    if (format === 'json') {
      return JSON.stringify(projects, null, 2);
    }
    const headers = [
      'Source',
      'Source Project ID',
      'Project Name',
      'Project Number',
      'State',
      'District',
      'Land Required (Ha)',
      'Land Acquired Till Now (Ha)',
      'Source Status',
      'Data Status',
      'Last Checked At',
      'Source URL'
    ];
    const rows = projects.map(p => [
      `"${p.source}"`,
      `"${p.source_project_id}"`,
      `"${(p.project_name || '').replace(/"/g, '""')}"`,
      `"${p.project_number || ''}"`,
      `"${p.state || ''}"`,
      `"${p.district || ''}"`,
      p.land_required,
      p.land_acquired_till_now,
      `"${p.source_status}"`,
      `"${p.data_status}"`,
      `"${p.last_checked_at || ''}"`,
      `"${p.source_url}"`
    ]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }
}
