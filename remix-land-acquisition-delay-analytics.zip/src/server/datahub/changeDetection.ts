/**
 * Deterministic Change Detection Engine
 * Phase 1 Data Hub: Canonical Hashing & Field-Level Diffing
 * Smart India Hackathon 2026 - SIH26017
 */

import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';
import {
  NormalizedProjectPayload,
  SourceProjectRecord,
  ProjectCurrentRecord,
  SyncChangeRecord
} from './types.ts';
import { saveProjectCurrentInDb } from './database.ts';

export type ChangeClassification = 'NEW' | 'UPDATED' | 'UNCHANGED' | 'ERROR';

export interface ChangeDetectionResult {
  classification: ChangeClassification;
  sourceProjectId: string;
  previousHash?: string;
  newHash: string;
  fieldChanges: Omit<SyncChangeRecord, 'id' | 'sync_run_id'>[];
  snapshotJson: string;
}

export class ChangeDetectionEngine {
  /**
   * Generates a deterministic canonical JSON string and SHA-256 hash.
   * Keys are recursively sorted, numbers and strings are normalized.
   */
  public static generateCanonicalHash(payload: NormalizedProjectPayload): {
    canonicalJson: string;
    hash: string;
  } {
    // Pick the deterministic comparison fields
    const canonicalObj = {
      sourceProjectId: String(payload.sourceProjectId).trim(),
      projectName: String(payload.projectName || '').trim(),
      projectNumber: String(payload.projectNumber || '').trim(),
      state: String(payload.state || '').trim(),
      district: String(payload.district || '').trim(),
      implementingAgency: String(payload.implementingAgency || '').trim(),
      highwayNumber: String(payload.highwayNumber || '').trim(),
      landRequired: Number(Number(payload.landRequired || 0).toFixed(4)),
      landAvailable: Number(Number(payload.landAvailable || 0).toFixed(4)),
      landToBeAcquired: Number(Number(payload.landToBeAcquired || 0).toFixed(4)),
      landAcquiredTillNow: Number(Number(payload.landAcquiredTillNow || 0).toFixed(4)),
      sanctionNumber: String(payload.sanctionNumber || '').trim(),
      sanctionDate: String(payload.sanctionDate || '').trim(),
      sanctionAmount: Number(Number(payload.sanctionAmount || 0).toFixed(2)),
      notifications3aCount: payload.notifications3a?.length || 0,
      notifications3ACount: payload.notifications3A?.length || 0,
      notifications3dCount: payload.notifications3d?.length || 0,
      notifications3aSummary: (payload.notifications3a || []).map(n => `${n.notification_number || ''}:${n.publish_date || ''}:${n.status || ''}`).sort().join('|'),
      notifications3ASummary: (payload.notifications3A || []).map(n => `${n.notification_number || ''}:${n.publish_date || ''}:${n.status || ''}`).sort().join('|'),
      notifications3dSummary: (payload.notifications3d || []).map(n => `${n.notification_number || ''}:${n.publish_date || ''}:${n.status || ''}`).sort().join('|'),
      sanctionsCount: payload.sanctions?.length || 0,
      consentPurchasesCount: payload.consentPurchases?.length || 0
    };

    // Sorted JSON stringification
    const sortedKeys = Object.keys(canonicalObj).sort();
    const sortedObj: Record<string, any> = {};
    for (const key of sortedKeys) {
      sortedObj[key] = (canonicalObj as any)[key];
    }

    const canonicalJson = JSON.stringify(sortedObj);
    const hash = createHash('sha256').update(canonicalJson).digest('hex').substring(0, 32);

    return { canonicalJson, hash };
  }

  /**
   * Evaluates incoming payload against existing database records.
   * Classifies as NEW, UPDATED, or UNCHANGED.
   * Generates field-level diffs when changes are detected.
   */
  public static evaluateChange(
    db: DatabaseSync,
    payload: NormalizedProjectPayload,
    syncRunId: string
  ): ChangeDetectionResult {
    const { canonicalJson, hash: newHash } = this.generateCanonicalHash(payload);
    const projectId = payload.sourceProjectId;

    // Check if project exists in registry
    const sourceProject = db.prepare('SELECT * FROM dh_source_projects WHERE source_project_id = ?').get(projectId) as unknown as (SourceProjectRecord | undefined);
    const currentRecord = db.prepare('SELECT * FROM dh_project_current WHERE source_project_id = ?').get(projectId) as unknown as (ProjectCurrentRecord | undefined);

    if (!sourceProject || !currentRecord) {
      // NEW PROJECT
      return {
        classification: 'NEW',
        sourceProjectId: projectId,
        newHash,
        fieldChanges: [],
        snapshotJson: canonicalJson
      };
    }

    const previousHash = sourceProject.current_hash || '';

    if (previousHash === newHash) {
      // UNCHANGED
      return {
        classification: 'UNCHANGED',
        sourceProjectId: projectId,
        previousHash,
        newHash,
        fieldChanges: [],
        snapshotJson: canonicalJson
      };
    }

    // UPDATED - Compare field-by-field to identify specific differences
    const fieldChanges: Omit<SyncChangeRecord, 'id' | 'sync_run_id'>[] = [];
    const now = new Date().toISOString();

    const checkDiff = (fieldName: string, oldVal: any, newVal: any) => {
      const oldStr = oldVal !== undefined && oldVal !== null ? String(oldVal) : '';
      const newStr = newVal !== undefined && newVal !== null ? String(newVal) : '';
      if (oldStr !== newStr) {
        fieldChanges.push({
          source_project_id: projectId,
          field_name: fieldName,
          old_value: oldStr,
          new_value: newStr,
          detected_at: now
        });
      }
    };

    // Compare core statutory fields
    checkDiff('land_acquired_till_now', currentRecord.land_acquired_till_now, payload.landAcquiredTillNow);
    checkDiff('land_to_be_acquired', currentRecord.land_to_be_acquired, payload.landToBeAcquired);
    checkDiff('land_required', currentRecord.land_required, payload.landRequired);
    checkDiff('land_available', currentRecord.land_available, payload.landAvailable);
    checkDiff('project_name', currentRecord.project_name, payload.projectName);
    checkDiff('state', currentRecord.state, payload.state);
    checkDiff('district', currentRecord.district, payload.district);
    checkDiff('sanction_amount', currentRecord.sanction_amount, payload.sanctionAmount);
    checkDiff('sanction_number', currentRecord.sanction_number, payload.sanctionNumber);
    checkDiff('highway_number', currentRecord.highway_number, payload.highwayNumber);

    // If hash differed but individual fields checked above had no diff (e.g. notifications count changed)
    if (fieldChanges.length === 0) {
      fieldChanges.push({
        source_project_id: projectId,
        field_name: 'statutory_notifications',
        old_value: 'Previous notifications snapshot',
        new_value: 'Updated notifications published',
        detected_at: now
      });
    }

    return {
      classification: 'UPDATED',
      sourceProjectId: projectId,
      previousHash,
      newHash,
      fieldChanges,
      snapshotJson: canonicalJson
    };
  }

  /**
   * Applies the evaluated change into database within transactional safety
   */
  public static applyChange(
    db: DatabaseSync,
    evalResult: ChangeDetectionResult,
    payload: NormalizedProjectPayload,
    syncRunId: string,
    discoveryMethod: 'AUTO_DISCOVERED' | 'MANUALLY_REGISTERED' | 'IMPORTED' | 'DEMO' = 'MANUALLY_REGISTERED'
  ) {
    const now = new Date().toISOString();
    const projectId = evalResult.sourceProjectId;

    db.exec('BEGIN TRANSACTION;');
    try {
      if (evalResult.classification === 'NEW') {
        // 1. Insert into dh_source_projects
        const id = `bhoomirashi_${projectId}`;
        const url = `https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=${projectId}`;

        db.prepare(`
          INSERT INTO dh_source_projects (
            id, source_name, source_project_id, project_number, project_name,
            source_url, discovery_method, first_seen_at, last_checked_at,
            last_changed_at, current_hash, source_status, data_status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(source_project_id) DO UPDATE SET
            last_checked_at = excluded.last_checked_at,
            last_changed_at = excluded.last_changed_at,
            current_hash = excluded.current_hash,
            data_status = 'SYNCHRONIZED',
            updated_at = excluded.updated_at
        `).run(
          id,
          'BhoomiRashi',
          projectId,
          payload.projectNumber || null,
          payload.projectName,
          url,
          discoveryMethod,
          now,
          now,
          now,
          evalResult.newHash,
          'AVAILABLE',
          'SYNCHRONIZED',
          now,
          now
        );

        // 2. Save current normalized data
        saveProjectCurrentInDb(db, payload, evalResult.newHash);

        // 3. Save initial history snapshot
        const histId = `HIST_${projectId}_${Date.now()}`;
        db.prepare(`
          INSERT INTO dh_project_history (
            id, source_project_id, snapshot_hash, snapshot_json, captured_at, change_type
          ) VALUES (?, ?, ?, ?, ?, ?)
        `).run(
          histId,
          projectId,
          evalResult.newHash,
          evalResult.snapshotJson,
          now,
          'INITIAL'
        );

      } else if (evalResult.classification === 'UPDATED') {
        // 1. Save new snapshot to dh_project_history
        const histId = `HIST_${projectId}_${Date.now()}`;
        db.prepare(`
          INSERT INTO dh_project_history (
            id, source_project_id, snapshot_hash, snapshot_json, captured_at, change_type
          ) VALUES (?, ?, ?, ?, ?, ?)
        `).run(
          histId,
          projectId,
          evalResult.newHash,
          evalResult.snapshotJson,
          now,
          'UPDATED'
        );

        // 2. Record field-level changes in dh_sync_changes
        const insertChange = db.prepare(`
          INSERT INTO dh_sync_changes (
            id, sync_run_id, source_project_id, field_name, old_value, new_value, detected_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `);

        for (const ch of evalResult.fieldChanges) {
          const changeId = `CH_${projectId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
          insertChange.run(
            changeId,
            syncRunId,
            projectId,
            ch.field_name,
            ch.old_value || null,
            ch.new_value || null,
            ch.detected_at
          );
        }

        // 3. Update current record
        saveProjectCurrentInDb(db, payload, evalResult.newHash);

        // 4. Update source_projects registry
        db.prepare(`
          UPDATE dh_source_projects
          SET
            current_hash = ?,
            last_checked_at = ?,
            last_changed_at = ?,
            data_status = 'RECENTLY_UPDATED',
            project_name = ?,
            updated_at = ?
          WHERE source_project_id = ?
        `).run(
          evalResult.newHash,
          now,
          now,
          payload.projectName,
          now,
          projectId
        );

      } else if (evalResult.classification === 'UNCHANGED') {
        // Just update last_checked_at
        db.prepare(`
          UPDATE dh_source_projects
          SET
            last_checked_at = ?,
            data_status = 'UNCHANGED',
            updated_at = ?
          WHERE source_project_id = ?
        `).run(now, now, projectId);
      }

      db.exec('COMMIT;');
    } catch (err) {
      try {
        db.exec('ROLLBACK;');
      } catch {}
      throw err;
    }
  }
}
