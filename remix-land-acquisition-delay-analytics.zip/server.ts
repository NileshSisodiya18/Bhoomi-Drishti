import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import * as api from './src/server/apiRouter.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for JSON and URL encoded payloads (supports CSV/JSON imports up to 10MB)
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // CORS & Security Headers
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    if (req.method === 'OPTIONS') {
      res.status(200).end();
      return;
    }
    next();
  });

  // Health and Info Endpoints
  app.get('/api/health', (_req, res) => {
    res.status(200).json({ status: 'ok', service: 'BhoomiDrishti Intelligence' });
  });

  app.get('/api/info', (_req, res) => {
    res.status(200).json({
      system: 'BhoomiDrishti Land Acquisition Risk Intelligence Platform',
      version: '2.5.0',
      description: 'Predictive Analytics System for Early Detection of Land Acquisition Delays (SIH26017) - Government of India',
      capabilities: ['BhoomiRashi Adapter', 'LACRRIS Adapter', 'Official File Ingestion', 'Dynamic ML Risk Scoring', 'Server-Side Pagination']
    });
  });

  // Dashboard Summary
  app.get('/api/dashboard/summary', (_req, res) => {
    try {
      const summary = api.getDashboardSummary();
      res.status(200).json(summary);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch dashboard summary' });
    }
  });

  // Paginated and Filtered Projects
  app.get('/api/projects', (req, res) => {
    try {
      const search = req.query.search ? String(req.query.search) : undefined;
      const risk = req.query.risk ? String(req.query.risk) : undefined;
      const state = req.query.state ? String(req.query.state) : undefined;
      const district = req.query.district ? String(req.query.district) : undefined;
      const stage = req.query.stage ? String(req.query.stage) : undefined;
      const sortBy = req.query.sortBy ? String(req.query.sortBy) : undefined;
      const page = req.query.page ? parseInt(String(req.query.page), 10) : 1;
      const pageSize = req.query.pageSize ? parseInt(String(req.query.pageSize), 10) : 100;

      const result = api.getProjects({ search, risk, state, district, stage, sortBy, page, pageSize });
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to query projects' });
    }
  });

  // Single Project Details
  app.get('/api/projects/:id', (req, res) => {
    try {
      const project = api.getProjectById(req.params.id);
      if (!project) {
        res.status(404).json({ error: 'Project not found' });
        return;
      }
      res.status(200).json(project);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch project' });
    }
  });

  // Project Change History (Audit Trail)
  app.get('/api/projects/:id/history', (req, res) => {
    try {
      const history = api.getProjectHistory(req.params.id);
      res.status(200).json(history);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch project history' });
    }
  });

  // Alerts
  app.get('/api/alerts', (req, res) => {
    try {
      const status = req.query.status ? String(req.query.status) : undefined;
      const alerts = api.getAlerts(status);
      res.status(200).json(alerts);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch alerts' });
    }
  });

  app.post('/api/alerts/:id/acknowledge', (req, res) => {
    try {
      const updated = api.acknowledgeAlert(req.params.id);
      if (!updated) {
        res.status(404).json({ error: 'Alert not found' });
        return;
      }
      res.status(200).json({ success: true, alert: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to acknowledge alert' });
    }
  });

  // Risk Map lightweight data
  app.get('/api/risk-map', (_req, res) => {
    try {
      const mapData = api.getRiskMapData();
      res.status(200).json(mapData);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch map data' });
    }
  });

  // What-If Scenario Calculation
  app.post('/api/scenarios/what-if', (req, res) => {
    try {
      const result = api.runWhatIfScenario(req.body);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'What-if calculation failed' });
    }
  });

  // System and Source Status
  app.get('/api/system/status', (_req, res) => {
    try {
      const status = api.getSystemStatus();
      res.status(200).json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch system status' });
    }
  });

  app.get('/api/system/source-status', async (_req, res) => {
    try {
      const sources = await api.getSourcesStatus();
      res.status(200).json(sources);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch source status' });
    }
  });

  app.get('/api/sources/status', async (_req, res) => {
    try {
      const sources = await api.getSourcesStatus();
      res.status(200).json(sources);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch source status' });
    }
  });

  // Data Sources Management
  app.get('/api/data-sources', (_req, res) => {
    try {
      const sources = api.getDataSources();
      res.status(200).json(sources);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch data sources' });
    }
  });

  app.get('/api/data-sources/:id', (req, res) => {
    try {
      const source = api.getDataSourceById(req.params.id);
      if (!source) {
        res.status(404).json({ error: 'Data source not found' });
        return;
      }
      res.status(200).json(source);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch data source' });
    }
  });

  app.put('/api/data-sources/:id', (req, res) => {
    try {
      const updated = api.updateDataSourceConfig(req.params.id, req.body);
      if (!updated) {
        res.status(404).json({ error: 'Data source not found' });
        return;
      }
      res.status(200).json({ success: true, dataSource: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to update data source' });
    }
  });

  app.post('/api/data-sources/:id/test', async (req, res) => {
    try {
      const result = await api.testDataSourceConnection(req.params.id);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to test connection' });
    }
  });

  // Project Update Endpoint (with validation, ML recalculation, and audit trail)
  app.put('/api/projects/:id', (req, res) => {
    try {
      const userId = req.headers['x-user-id'] ? String(req.headers['x-user-id']) : 'admin';
      const result = api.updateProject(req.params.id, req.body, userId);
      if (!result.success) {
        res.status(400).json({ error: result.error || 'Failed to update project' });
        return;
      }
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error updating project' });
    }
  });

  // File Inspection Endpoint (pre-upload column mapping preview)
  app.post('/api/data/inspect', (req, res) => {
    try {
      const { content, fileType, fileName } = req.body || {};
      if (!content || !fileType) {
        res.status(400).json({ error: 'Missing file content or fileType (must be csv, xlsx, xls, or json)' });
        return;
      }
      const inspection = api.inspectFile(content, fileType, fileName);
      res.status(200).json(inspection);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to inspect file structure' });
    }
  });

  // File Ingestion with Column Mapping Endpoint
  app.post('/api/data/import-mapped', async (req, res) => {
    try {
      const { content, fileType, columnMapping, fileName } = req.body || {};
      if (!content || !fileType) {
        res.status(400).json({ error: 'Missing content or fileType' });
        return;
      }
      const summary = await api.importDataWithMapping(content, fileType, columnMapping, fileName || 'upload');
      res.status(200).json({
        message: 'Data import completed',
        summary
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Mapped file import failed' });
    }
  });

  // Validation Errors Log
  app.get('/api/validation-errors', (req, res) => {
    try {
      const syncId = req.query.syncId ? String(req.query.syncId) : undefined;
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 50;
      const errors = api.getValidationErrors(syncId, limit);
      res.status(200).json(errors);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch validation errors' });
    }
  });

  // Audit Logs
  app.get('/api/audit-logs', (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 50;
      const logs = api.getAuditLogs(limit);
      res.status(200).json(logs);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch audit logs' });
    }
  });

  // Database Overview
  app.get('/api/database/overview', (_req, res) => {
    try {
      const overview = api.getDatabaseOverview();
      res.status(200).json(overview);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch database overview' });
    }
  });

  // Data Export (CSV or JSON)
  app.get('/api/export', (req, res) => {
    try {
      const type = (req.query.type || 'all') as 'all' | 'high_risk' | 'alerts' | 'audit_logs';
      const format = (req.query.format || 'json') as 'csv' | 'json';
      const data = api.exportData(type, format);

      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="bhoomidrishti_${type}_export.csv"`);
        res.status(200).send(data);
      } else {
        res.status(200).json(data);
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to export data' });
    }
  });

  // Data Mode Toggle (DEMO vs LIVE_SYNCHRONIZED)
  app.post('/api/system/data-mode', (req, res) => {
    try {
      const mode = req.body?.mode;
      if (!mode || (mode !== 'DEMO' && mode !== 'LIVE_SYNCHRONIZED')) {
        res.status(400).json({ error: "Invalid mode. Must be 'DEMO' or 'LIVE_SYNCHRONIZED'" });
        return;
      }
      const result = api.setDataMode(mode);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to update data mode' });
    }
  });

  // Data Synchronization Endpoint
  app.post('/api/sync', async (req, res) => {
    try {
      const source = (req.body?.source || 'BhoomiRashi') as any;
      const summary = await api.triggerSync(source);
      res.status(200).json({
        message: `Synchronization with ${source} completed`,
        summary
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Synchronization failed' });
    }
  });

  // Official File Ingestion Endpoint (CSV / XLSX / JSON)
  app.post('/api/data/import', async (req, res) => {
    try {
      const { content, fileType, fileName } = req.body || {};
      if (!content || !fileType) {
        res.status(400).json({ error: 'Missing content or fileType (must be csv, xlsx, or json)' });
        return;
      }
      const summary = await api.importData(content, fileType, fileName || 'upload');
      res.status(200).json({
        message: 'Official data import completed',
        summary
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'File import failed' });
    }
  });

  // Sync History
  app.get('/api/sync/history', (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 10;
      const history = api.getSyncHistory(limit);
      res.status(200).json(history);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch sync history' });
    }
  });

  // Model Info
  app.get('/api/model/info', (_req, res) => {
    res.status(200).json(api.getModelInfo());
  });

  // ============================================================
  // PHASE 1: DATA HUB / DATA SYNCHRONIZATION REST API ENDPOINTS
  // ============================================================

  // Initialize Data Hub periodic scheduler
  api.DataHubScheduler.init();

  // 1. GET /api/datahub/projects (Current synchronized projects)
  app.get('/api/datahub/projects', (_req, res) => {
    try {
      const projects = api.DataHubApi.getProjects();
      res.status(200).json(projects);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch Data Hub projects' });
    }
  });

  // 2. GET /api/datahub/projects/:sourceProjectId (Full project detail)
  app.get('/api/datahub/projects/:sourceProjectId', (req, res) => {
    try {
      const project = api.DataHubApi.getProjectById(req.params.sourceProjectId);
      if (!project) {
        res.status(404).json({ error: `Project '${req.params.sourceProjectId}' not found in Data Hub` });
        return;
      }
      res.status(200).json(project);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch Data Hub project' });
    }
  });

  // 3. GET /api/datahub/projects/:sourceProjectId/history (Historical snapshots & field diffs)
  app.get('/api/datahub/projects/:sourceProjectId/history', (req, res) => {
    try {
      const history = api.DataHubApi.getProjectHistory(req.params.sourceProjectId);
      res.status(200).json(history);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch project history' });
    }
  });

  // 4. GET /api/datahub/changes (Recent field-level changes across projects)
  app.get('/api/datahub/changes', (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 30;
      const changes = api.DataHubApi.getRecentChanges(limit);
      res.status(200).json(changes);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch recent changes' });
    }
  });

  // 5. GET /api/datahub/sync-status and /api/datahub/overview
  app.get(['/api/datahub/sync-status', '/api/datahub/overview'], (_req, res) => {
    try {
      const status = api.DataHubApi.getSyncStatus();
      res.status(200).json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch sync status' });
    }
  });

  // 6. GET /api/datahub/sync-runs (Audit log of synchronization runs)
  app.get('/api/datahub/sync-runs', (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 15;
      const runs = api.DataHubApi.getSyncRuns(limit);
      res.status(200).json(runs);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch sync runs' });
    }
  });

  // 7. POST /api/datahub/sync (Trigger manual "Check Now")
  app.post('/api/datahub/sync', async (_req, res) => {
    try {
      const run = await api.DataHubApi.triggerSync();
      res.status(200).json({
        message: 'Synchronization run completed',
        run
      });
    } catch (err: any) {
      console.error('[DataHub Sync Error]', err);
      res.status(500).json({ error: err.message || 'Synchronization run failed', stack: err.stack });
    }
  });

  // 8. POST /api/datahub/projects/register (Register a new public project ID)
  app.post('/api/datahub/projects/register', async (req, res) => {
    try {
      const { projectId, projectName, discoveryMethod } = req.body || {};
      if (!projectId) {
        res.status(400).json({ error: 'Project ID is required' });
        return;
      }
      const result = await api.DataHubApi.registerProject(projectId, projectName, discoveryMethod);
      res.status(result.isNew ? 201 : 200).json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to register project' });
    }
  });

  // 9. POST /api/datahub/projects/import (Bulk import project IDs)
  app.post('/api/datahub/projects/import', async (req, res) => {
    try {
      const { content, format } = req.body || {};
      if (!content) {
        res.status(400).json({ error: 'Missing content for project ID import' });
        return;
      }
      const result = await api.DataHubApi.importProjectIds(content, format || 'csv');
      res.status(200).json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to import project IDs' });
    }
  });

  // 10. GET /api/datahub/source-status (Source configuration & status)
  app.get('/api/datahub/source-status', (_req, res) => {
    try {
      const status = api.DataHubApi.getSourceStatus();
      res.status(200).json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch source status' });
    }
  });

  // 11. POST /api/datahub/source/test (Test public source connectivity)
  app.post('/api/datahub/source/test', async (req, res) => {
    try {
      const { projectId } = req.body || {};
      const result = await api.DataHubApi.testSource(projectId);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Source test failed' });
    }
  });

  // 12. POST /api/datahub/test-fixture/toggle-60940 (Simulate Project 60940 change per Section 42)
  app.post('/api/datahub/test-fixture/toggle-60940', (req, res) => {
    try {
      const enabled = req.body?.enabled;
      const result = api.DataHubApi.toggleFixture60940(enabled);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to toggle test fixture' });
    }
  });

  // 13. PUT /api/datahub/config (Update periodic interval)
  app.put('/api/datahub/config', (req, res) => {
    try {
      const interval = parseInt(String(req.body?.intervalMinutes), 10);
      if (isNaN(interval) || interval <= 0) {
        res.status(400).json({ error: 'Valid intervalMinutes is required' });
        return;
      }
      const result = api.DataHubApi.updateConfig(interval);
      res.status(200).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to update config' });
    }
  });

  // 14. GET /api/datahub/export (Export Data Hub records)
  app.get('/api/datahub/export', (req, res) => {
    try {
      const format = (req.query.format as any) === 'json' ? 'json' : 'csv';
      const data = api.DataHubApi.exportData(format);
      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="bhoomirashi_datahub_export.csv"');
        res.status(200).send(data);
      } else {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).send(data);
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to export Data Hub data' });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[BhumiDrishti Server] Running on http://0.0.0.0:${PORT} (env: ${process.env.NODE_ENV || 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('[BhumiDrishti Server] Failed to start:', err);
});
