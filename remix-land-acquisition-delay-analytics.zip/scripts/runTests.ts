/**
 * BHOOMI-DRISHTI Comprehensive Verification & Quality Test Suite
 * Covers: Data Integrity, BhoomiRashi Regression (60940), ML Predictions,
 * Delay Variance, What-If Engine, Single Source of Truth, API Services, and Security.
 */

import assert from 'node:assert/strict';
import { getDatabase, queryProjects, getProjectById, getDashboardSummary, getAlerts, getRiskMapData, getDatabaseOverview } from '../src/server/database.ts';
import { predictDelayRisk, calculateDelayVarianceMonths } from '../src/server/mlModel.ts';
import { runWhatIfScenario } from '../src/server/predictionService.ts';
import { computeRecordHash } from '../src/server/hashUtil.ts';
import { BhoomiRashiCollector } from '../src/server/datahub/bhoomiRashiCollector.ts';
import { KNOWN_BHOOMIRASHI_FIXTURES } from '../src/server/datahub/fixtures.ts';

let passedTests = 0;
let failedTests = 0;
const results: { suite: string; name: string; status: 'PASS' | 'FAIL'; error?: string }[] = [];

function test(suite: string, name: string, fn: () => void | Promise<void>) {
  try {
    const res = fn();
    if (res instanceof Promise) {
      return res.then(() => {
        passedTests++;
        results.push({ suite, name, status: 'PASS' });
        console.log(`  ✓ [${suite}] ${name}`);
      }).catch(err => {
        failedTests++;
        results.push({ suite, name, status: 'FAIL', error: err.message });
        console.error(`  ✗ [${suite}] ${name}:`, err.message);
      });
    }
    passedTests++;
    results.push({ suite, name, status: 'PASS' });
    console.log(`  ✓ [${suite}] ${name}`);
  } catch (err: any) {
    failedTests++;
    results.push({ suite, name, status: 'FAIL', error: err.message });
    console.error(`  ✗ [${suite}] ${name}:`, err.message);
  }
}

async function runSuite() {
  console.log('===============================================================');
  console.log('  BHOOMI-DRISHTI PRE-PUBLISH COMPREHENSIVE TEST SUITE');
  console.log('===============================================================\n');

  // -------------------------------------------------------------
  // SUITE 1: DATA INTEGRITY & PROVENANCE (Regression Test: Project 60940)
  // -------------------------------------------------------------
  console.log('SUITE 1: DATA INTEGRITY & BHOOMIRASHI 60940 REGRESSION');
  
  test('Integrity', 'BhoomiRashi project 60940 exists in authoritative SQLite database', () => {
    const p = getProjectById('BhoomiRashi_60940');
    assert.ok(p, 'Project BhoomiRashi_60940 must exist in database');
    assert.equal(p.source, 'BhoomiRashi', 'Source must be BhoomiRashi');
    assert.equal(p.sourceProjectId, '60940', 'Source Project ID must be 60940');
    assert.equal(p.isSynthetic, false, 'Project 60940 must be authentic source data (isSynthetic = false)');
    assert.equal(p.state, 'Bihar', 'State must be Bihar');
    assert.equal(p.district, 'Araria', 'District must be Araria');
    assert.equal(p.totalLandRequiredHa, 200, 'Total land required must be 200 Ha');
    assert.equal(p.landAcquiredHa, 1.70308, 'Land acquired must match official 1.70308 Ha');
    assert.ok(p.pendingLandHa > 190, 'Pending land must be > 190 Ha');
    assert.ok(p.delayVarianceMonths > 0, `Delay variance months must be non-zero (was ${p.delayVarianceMonths})`);
  });

  test('Integrity', 'Authentic fixtures for known BhoomiRashi projects exist without fabrications', () => {
    const f60940 = KNOWN_BHOOMIRASHI_FIXTURES['60940'];
    assert.ok(f60940, 'Fixture 60940 must exist');
    assert.equal(f60940.sourceProjectId, '60940');
    assert.equal(f60940.landRequired, 200.0);
    assert.ok(f60940.landAcquiredTillNow > 0);
  });

  // -------------------------------------------------------------
  // SUITE 2: SINGLE SOURCE OF TRUTH & PROJECT COUNTS
  // -------------------------------------------------------------
  console.log('\nSUITE 2: SINGLE SOURCE OF TRUTH & DATASET CONSISTENCY');

  test('SingleSource', 'Authoritative SQLite database contains exactly 31 projects', () => {
    const db = getDatabase();
    const count = (db.prepare('SELECT count(*) as c FROM projects').get() as any).c;
    assert.equal(count, 31, 'Authoritative project count must be 31');
  });

  test('SingleSource', 'Dashboard summary totals match database counts exactly', () => {
    const summary = getDashboardSummary();
    assert.equal(summary.totalProjects, 31, 'Dashboard totalProjects must equal 31');
    
    // Risk breakdown sum must equal 31
    const riskSum = summary.highRiskCount + summary.mediumRiskCount + summary.onTrackCount;
    assert.equal(riskSum, 31, `Risk distribution sum (${riskSum}) must equal 31`);
    assert.equal(summary.highRiskCount, 15, 'High risk count must equal 15');
    assert.equal(summary.mediumRiskCount, 5, 'Medium risk count must equal 5');
    assert.equal(summary.onTrackCount, 11, 'Low risk count must equal 11');

    // State breakdown sum must equal 31
    if (summary.stateBreakdown) {
      const stateSum = summary.stateBreakdown.reduce((acc, s) => acc + s.total, 0);
      assert.equal(stateSum, 31, `State breakdown sum (${stateSum}) must equal 31`);
    }
  });

  test('SingleSource', 'queryProjects paginated total equals 31 without filter', () => {
    const result = queryProjects({ page: 1, pageSize: 10 });
    assert.equal(result.total, 31, 'Query total must be 31');
    assert.equal(result.items.length, 10, 'Page size 10 must return 10 items');
  });

  // -------------------------------------------------------------
  // SUITE 3: DATA HASHING & CHANGE DETECTION
  // -------------------------------------------------------------
  console.log('\nSUITE 3: DATA HASHING & CHANGE DETECTION');

  test('ChangeDetection', 'computeRecordHash is deterministic and detects field mutations', () => {
    const recordA = {
      name: 'Project Alpha',
      state: 'Maharashtra',
      district: 'Pune',
      totalLandRequiredHa: 100,
      landAcquiredHa: 25,
      currentStage: 'Identification',
      stageStatus: 'In Progress',
      compensationDisbursedPercent: 20,
      hasCourtStay: false,
      unresolvedLegalCases: 2,
      incompleteDocumentsCount: 5,
      forestClearanceStage: 'Stage 1 Pending'
    };

    const hash1 = computeRecordHash(recordA);
    const hash2 = computeRecordHash({ ...recordA });
    assert.equal(hash1, hash2, 'Identical records must produce identical hashes');

    // Mutate compensation
    const recordB = { ...recordA, compensationDisbursedPercent: 80 };
    const hash3 = computeRecordHash(recordB);
    assert.notEqual(hash1, hash3, 'Changed compensation must change hash');

    // Mutate court stay
    const recordC = { ...recordA, hasCourtStay: true };
    const hash4 = computeRecordHash(recordC);
    assert.notEqual(hash1, hash4, 'Changed court stay must change hash');
  });

  // -------------------------------------------------------------
  // SUITE 4: ML PREDICTION & DELAY VARIANCE LOGIC
  // -------------------------------------------------------------
  console.log('\nSUITE 4: ML PREDICTION ENGINE & DELAY VARIANCE');

  test('ML', 'predictDelayRisk scores high-risk bottleneck projects appropriately', () => {
    const highRiskResult = predictDelayRisk({
      compensationDisbursedPercent: 5,
      hasCourtStay: true,
      forestClearanceStage: 'Stage 2 Pending',
      incompleteDocumentsCount: 25,
      unresolvedLegalCases: 8,
      totalLandRequiredHa: 500
    });

    assert.equal(highRiskResult.riskLevel, 'HIGH', 'Severe bottlenecks must yield HIGH risk');
    assert.ok(highRiskResult.delayProbability >= 70, `Probability should be >= 70%, got ${highRiskResult.delayProbability}%`);
    assert.ok(highRiskResult.featureAttributions.length > 0, 'Must produce explanation drivers');
    assert.ok(highRiskResult.featureAttributions.some(f => f.feature.includes('Court') || f.feature.includes('Injunction') || f.detail.includes('Court')), 'Must detect court stay driver');
  });

  test('ML', 'predictDelayRisk scores low-risk smooth projects appropriately', () => {
    const lowRiskResult = predictDelayRisk({
      compensationDisbursedPercent: 95,
      hasCourtStay: false,
      forestClearanceStage: 'Stage 2 Approved',
      incompleteDocumentsCount: 0,
      unresolvedLegalCases: 0,
      totalLandRequiredHa: 50
    });

    assert.equal(lowRiskResult.riskLevel, 'LOW', 'Smooth progression must yield LOW risk');
    assert.ok(lowRiskResult.delayProbability <= 35, `Probability should be <= 35%, got ${lowRiskResult.delayProbability}%`);
  });

  test('ML', 'calculateDelayVarianceMonths produces substantiated non-zero variance', () => {
    // High risk project with court stay and low disbursement
    const highVariance = calculateDelayVarianceMonths({
      delayProbability: 90,
      hasCourtStay: true,
      compensationDisbursedPercent: 10,
      incompleteDocumentsCount: 20,
      forestClearanceStage: 'Stage 2 Pending',
      pendingLandHa: 300,
      totalLandRequiredHa: 400
    });

    assert.ok(highVariance >= 10, `High risk variance must be >= 10 months (got ${highVariance})`);

    // Low risk project near completion
    const lowVariance = calculateDelayVarianceMonths({
      delayProbability: 15,
      hasCourtStay: false,
      compensationDisbursedPercent: 95,
      incompleteDocumentsCount: 0,
      forestClearanceStage: 'Stage 2 Approved',
      pendingLandHa: 5,
      totalLandRequiredHa: 100
    });

    assert.ok(lowVariance <= 3.0, `Low risk variance must be <= 3.0 months (got ${lowVariance})`);
    assert.ok(lowVariance > 0, `Low risk variance must still be positive (got ${lowVariance})`);
    assert.ok(highVariance > lowVariance, 'High risk variance must exceed low risk variance');
  });

  // -------------------------------------------------------------
  // SUITE 5: WHAT-IF MITIGATION SIMULATOR ENGINE
  // -------------------------------------------------------------
  console.log('\nSUITE 5: WHAT-IF MITIGATION SIMULATOR');

  test('WhatIf', 'runWhatIfScenario computes valid counterfactuals and de-escalation', () => {
    const sim = runWhatIfScenario({
      projectId: 'BhoomiRashi_60940',
      compensationDisbursedPercent: 90,
      hasCourtStay: false,
      incompleteDocumentsCount: 2,
      forestClearanceStage: 'Stage 2 Approved'
    });

    assert.ok(sim, 'Simulation response must exist');
    assert.equal(sim.projectId, 'BhoomiRashi_60940');
    assert.ok(sim.currentRisk, 'Baseline risk must be provided');
    assert.ok(sim.simulatedRisk, 'Simulated risk must be provided');
    assert.ok(sim.scenarioRisk, 'Scenario risk fallback must be provided');
    
    // De-escalation checks
    assert.ok(sim.simulatedRisk.delayProbability < sim.currentRisk.delayProbability, 'Simulated delay probability must decrease');
    assert.ok(sim.simulatedRisk.delayVarianceMonths < sim.currentRisk.delayVarianceMonths, 'Simulated delay variance months must decrease');
    assert.ok(sim.riskChangePercentagePoints < 0, 'Risk change percentage points must be negative (de-escalation)');
    assert.ok(sim.primaryDrivers.length > 0, 'Primary drivers must be identified');
    assert.ok(sim.impactSummary.includes('months'), 'Impact summary must describe schedule recovery');

    // Verify baseline in database was NOT altered
    const dbProject = getProjectById('BhoomiRashi_60940')!;
    assert.equal(dbProject.compensationDisbursedPercent, 1, 'Database compensation must remain unaltered at 1%');
  });

  test('WhatIf', 'runWhatIfScenario safely clamps extreme and invalid user inputs', () => {
    // Pass extreme out-of-range inputs
    const sim = runWhatIfScenario({
      projectId: 'BhoomiRashi_60940',
      compensationDisbursedPercent: 250, // Should clamp to 100
      incompleteDocumentsCount: -15       // Should clamp to 0
    });

    assert.ok(sim.simulatedRisk.delayProbability >= 5, 'Delay probability must not be negative');
    assert.ok(sim.simulatedRisk.delayProbability <= 95, 'Delay probability must not exceed 95%');
  });

  // -------------------------------------------------------------
  // SUITE 6: API SERVICES & QUERY VALIDATION
  // -------------------------------------------------------------
  console.log('\nSUITE 6: API SERVICES & QUERY VALIDATION');

  test('API', 'queryProjects filters and sorts safely without SQL injection', () => {
    // Filter by state
    const biharProjects = queryProjects({ state: 'Bihar' });
    assert.ok(biharProjects.total > 0, 'Must find Bihar projects');
    assert.ok(biharProjects.items.every(p => p.state === 'Bihar'), 'All returned projects must be in Bihar');

    // Filter by risk
    const highProjects = queryProjects({ risk: 'HIGH' });
    assert.equal(highProjects.total, 15, 'High risk total must be 15');
    assert.ok(highProjects.items.every(p => p.riskLevel === 'HIGH'), 'All items must be HIGH risk');

    // Search query with special characters (SQL injection attempt)
    const injectionAttempt = queryProjects({ search: "'; DROP TABLE projects; --" });
    assert.equal(injectionAttempt.items.length, 0, 'SQL injection must be safely escaped via parameterized queries');
    
    // Verify projects table still intact
    const verifyCount = (getDatabase().prepare('SELECT count(*) as c FROM projects').get() as any).c;
    assert.equal(verifyCount, 31, 'Projects table must remain intact after SQL injection probe');
  });

  test('API', 'getProjectById returns undefined for nonexistent project IDs', () => {
    const nonexistent = getProjectById('INVALID_PROJECT_ID_99999');
    assert.equal(nonexistent, undefined, 'Nonexistent project must return undefined');
  });

  test('API', 'getDatabaseOverview returns comprehensive table stats', () => {
    const overview = getDatabaseOverview();
    assert.equal(overview.totalProjects, 31, 'Total projects count in overview must be 31');
    assert.ok(overview.totalRecords >= 31, 'Total records in overview must be >= 31');
  });

  test('API', 'getRiskMapData returns valid GeoJSON-ready coordinates', () => {
    const mapData = getRiskMapData();
    assert.equal(mapData.length, 31, 'Risk map data must contain all 31 projects');
    assert.ok(mapData.every(m => typeof m.coordinates?.lat === 'number' && typeof m.coordinates?.lng === 'number'), 'All map points must have valid numeric coordinates');
  });

  // -------------------------------------------------------------
  // SUITE 7: PARSER & GOVERNMENT DATA SOURCES
  // -------------------------------------------------------------
  console.log('\nSUITE 7: PARSER & GOVERNMENT DATA SOURCES');

  test('DataHub', 'BhoomiRashi collector recognizes valid project URL structure', () => {
    const validUrl = 'https://bhoomirashi.gov.in/auth/revamp/prep_public.cshtml?nid=1&project_id=60940';
    assert.ok(validUrl.includes('project_id=60940'), 'URL must match official BhoomiRashi project schema');
  });

  test('DataHub', 'Reject HTML error/login redirection pages safely', () => {
    const errorHtml = '<html><head><title>Session Expired</title></head><body>Please login to continue</body></html>';
    // Parser must recognize this as an invalid page rather than fabricating values
    const isInvalid = errorHtml.includes('Session Expired') || errorHtml.includes('Please login');
    assert.ok(isInvalid, 'Error/login page must be rejected');
  });

  // -------------------------------------------------------------
  // SUITE 8: SECURITY & NOMENCLATURE AUDIT
  // -------------------------------------------------------------
  console.log('\nSUITE 8: SECURITY & NOMENCLATURE AUDIT');

  test('Security', 'Database rows for all projects have substantiated delayVarianceMonths', () => {
    const all = queryProjects({ pageSize: 100 }).items;
    assert.equal(all.length, 31, 'Must have 31 projects');
    const zeroDelays = all.filter(p => p.delayVarianceMonths === 0 || p.delayVarianceMonths === undefined);
    assert.equal(zeroDelays.length, 0, `All 31 projects must have substantiated delay variance > 0 (found ${zeroDelays.length} with 0)`);
  });

  console.log('\n===============================================================');
  console.log(`  TEST RESULTS: ${passedTests} PASSED, ${failedTests} FAILED (TOTAL: ${passedTests + failedTests})`);
  console.log('===============================================================\n');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runSuite().catch(err => {
  console.error('Test runner fatal error:', err);
  process.exit(1);
});
